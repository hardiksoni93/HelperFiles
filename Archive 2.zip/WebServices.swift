		//
//  APIManager.swift
//  ISO
//
//  Created by AON on 23/01/17.
//  Copyright (c) 2015 ISO Ltd All rights reserved.
//
import Foundation
import AFNetworking
import CoreLocation
import ReachabilitySwift
import Toast_Swift
import SVProgressHUD

// we need a custom serializer for AFNetworking to be able to get at response data after an error (particularly for registration errors)
class TJJSONResponseSerializer: AFJSONResponseSerializer {
    
    
    
}

enum APIResult : NSInteger
{
    case APISuccess = 0,APIFail,APIError
}

public class APIManager {
    
    
    
    //service complition block
    typealias ServiceComplitionBlock = ([String : AnyObject]? ,APIResult)  -> Void
    
    typealias ServiceComplitionBlockArray = (AnyObject? ,APIResult)  -> Void

    // static properties get lazy evaluation and dispatch_once_t for free
    struct Static {
        static let instance = APIManager()
    }
    
    // this is the Swift way to do singletons
    class var apiManager: APIManager {
        return Static.instance
    }
    
    // NB: include trailing slashes in HT-Tracker endpoint strings!
    public class APIConstants {
        
        // URL construction
        
        
        static let loginEndpoint : String = "authenticate/login"
        static let signupEndpoint : String = "/public/api/v1/signup"
        
        static let createGroup : String = "/public/api/v1/group/create"
        static let getGrouplist : String = "/public/api/v1/group/list"
        
        static let testGetURL : String = "Values/InternalServerError"
        static let testGetURL2 : String = "Values/InternalServerError"


    }
    // needed for all AFNetworking requests
    let manager            =  AFHTTPSessionManager()
    
    
    // needed for session token persistence
    let userDefaults       = UserDefaults.standard
    
    // we get a session token on login from Jottr
    
    init()
    {
        
    }
   
    //MARK: - POST methods -
   
    func postNewDatadicFromUrl(url : String, dic : NSDictionary , block: @escaping ServiceComplitionBlock)
    {
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        
        manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
        
        manager.post(baseUrl + url, parameters: dic, progress: { (progress) in
        }
            , success: {(sessionDatatask , responseObject) in
                
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as! [String : AnyObject]
                    print ("responseDict====\(responseDict)")
                    
                    let responseHeader = sessionDatatask.response as! HTTPURLResponse
                    
                    if (responseHeader.statusCode ==  200) {
                        
                        
                        block(responseDict , APIResult.APISuccess)
                        
                        //    block(responseDict , APIResult.APIError)
                        
                    }
                    else {
                        block(responseDict , APIResult.APIError)
                    }
                    // use jsonObject here
                } catch {
                    
                    DispatchQueue.main.async {
                    print("json error: \(error)")
                    appDel?.loader.stopAnimatingGIF()
                appDel?.loader.isHidden = true
                    }
                }
                
        }, failure: {(sessionDatatask , error) in
            DispatchQueue.main.async {
            appDel?.loader.stopAnimatingGIF()
            appDel?.loader.isHidden = true
            let testObj : [String : AnyObject] = ["fail" : "Api" as AnyObject]
            block(testObj , APIResult.APIError)
            print("fail")
            }
        })
    }
    func postReviseTaskDatadicFromUrl(url : String, dic : NSDictionary , block: @escaping ServiceComplitionBlockArray)
    {
        
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        
        manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
        
        manager.post(baseUrl + url, parameters: dic, progress: { (progress) in
        }
            , success: {(sessionDatatask , responseObject) in
                
                do {
                    
                    let responseHeader = sessionDatatask.response as! HTTPURLResponse
                    print(responseHeader.statusCode)
                    let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    
//                    let responseHeader = sessionDatatask.response as! HTTPURLResponse
                    
                    if (responseHeader.statusCode ==  200) {
                        
                        block(responseDict as AnyObject , APIResult.APISuccess)
                        
                    }
                    else {
                        block(responseDict as AnyObject , APIResult.APIError)
                    }
                    
                    
                    // use jsonObject here
                } catch {
                    
                    DispatchQueue.main.async {
                    print("json error: \(error)")
                    CommonFunctions().stopAnimate()
                    }
                }
                
        }, failure: {(sessionDatatask , error) in
            DispatchQueue.main.async {
                let responseHeader = sessionDatatask?.response as! HTTPURLResponse
                print(responseHeader.statusCode)
                
                appDel?.loader.stopAnimatingGIF()
                appDel?.loader.isHidden = true
                let testObj : [String : AnyObject] = ["fail" : "Api" as AnyObject]
                block(testObj as AnyObject , APIResult.APIError)
                print("fail")
            }
        })
    }
    
    
    func postReviseTaskFromUrl(url : String, dic : NSDictionary , block: @escaping ServiceComplitionBlockArray)
    {
        let jsonData = try? JSONSerialization.data(withJSONObject: dic)
        
        // create post request
        let url = URL(string: baseUrl + url)!
        var request = URLRequest(url: url)
        request.setValue(appDel?.userObj.SessionId, forHTTPHeaderField:"SessionId")
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        request.httpMethod = "POST"
        
        // insert json data to the request
        request.httpBody = jsonData
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                CommonFunctions().stopAnimate()
                CommonFunctions().stopAnimateLoader2()
                let code = (error! as NSError).code
                if code == internetErrorCode {
                    DispatchQueue.main.async {
                        appDel?.window?.makeToast(msgNoInternet)
                    }
                }
                if (error?.localizedDescription.contains("302"))! {
                    DispatchQueue.main.async {
                        appDel?.sessionOUT()
                        
                    }
                }
                return
            }
            
            let responseHeader = response as! HTTPURLResponse
            
            if (responseHeader.statusCode ==  200) {
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (data as NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    block(responseDict as AnyObject , APIResult.APISuccess)
                }
                catch {
                    DispatchQueue.main.async {
                        print("json error: \(error.localizedDescription)")
                        CommonFunctions().stopAnimate()
                        CommonFunctions().stopAnimateLoader2()
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                }
            }
            else if (responseHeader.statusCode ==  400) {
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (data as NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    block(responseDict as AnyObject , APIResult.APIError)
                } catch {
                    DispatchQueue.main.async {
                        print("json error: \(error.localizedDescription)")
                        CommonFunctions().stopAnimate()
                        CommonFunctions().stopAnimateLoader2()
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    CommonFunctions().stopAnimateLoader2()
                    if (responseHeader.statusCode ==  302) {
                        appDel?.sessionOUT()
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                }
            }
        }
        
        task.resume()
    }
    
    func getReviseTaskFromUrl(url : String, dic : NSDictionary , type : String, block: @escaping ServiceComplitionBlockArray)
    {
        _ = try? JSONSerialization.data(withJSONObject: dic)
        
        // create post request
        let url = URL(string: baseUrl + url)!
        var request = URLRequest(url: url)
        request.setValue(appDel?.userObj.SessionId, forHTTPHeaderField:"SessionId")
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        request.httpMethod = type
        
        //request.httpBody = jsonData
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                let code = (error! as NSError).code
                if code == internetErrorCode {
                    DispatchQueue.main.async {
                        appDel?.window?.makeToast(msgNoInternet)
                    }
                }
                else if (error?.localizedDescription.contains("302"))! {
                    DispatchQueue.main.async {
                        appDel?.sessionOUT()
                        
                    }
                }
                return
            }
            
            let responseHeader = response as! HTTPURLResponse
            
            if (responseHeader.statusCode ==  200) {
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (data as NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    block(responseDict as AnyObject , APIResult.APISuccess)
                }
                catch {
                    DispatchQueue.main.async {
                        CommonFunctions().stopAnimate()
                        block(nil, APIResult.APISuccess)
                    }
                }
            }
            else if (responseHeader.statusCode ==  400) {
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (data as NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    block(responseDict as AnyObject , APIResult.APIError)
                } catch {
                    DispatchQueue.main.async {
                        print("json error: \(error.localizedDescription)")
                        CommonFunctions().stopAnimate()
                        appDel?.window?.makeToast(msgSomethingWrong)
                        block(nil, APIResult.APIError)
                    }
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    if (responseHeader.statusCode ==  302) {
                        appDel?.sessionOUT()
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                }
            }
        }
        
        task.resume()
    }
    
    
    //MARK: POST AND GET DATA
    
    func PostDataAndGetData(url : String, dic : NSDictionary , block: @escaping ServiceComplitionBlockArray) {
        let jsonData = try? JSONSerialization.data(withJSONObject: dic)
        
        // create post request
        let url = URL(string: baseUrl + url)!
        var request = URLRequest(url: url)
        
        request.setValue(appDel?.userObj.SessionId, forHTTPHeaderField:"SessionId")
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        request.httpMethod = "POST"
        
        // insert json data to the request
        request.httpBody = jsonData
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                CommonFunctions().stopAnimate()
                let code = (error! as NSError).code
                if code == internetErrorCode {
                    DispatchQueue.main.async {
                        appDel?.window?.makeToast(msgNoInternet)
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: NotificationNoInternet), object: nil)
                    }
                }
                if (error?.localizedDescription.contains("302"))! {
                    DispatchQueue.main.async {
                        appDel?.sessionOUT()
                        
                    }
                }
                print(error?.localizedDescription ?? "No data")
                return
            }
            
            let responseHeader = response as! HTTPURLResponse
            
            if (responseHeader.statusCode ==  200) {
                
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (data as NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    block(responseDict as AnyObject , APIResult.APISuccess)
                } catch {
                    block(false as AnyObject , APIResult.APISuccess)
                }
                
            }
            else if (responseHeader.statusCode ==  400) {
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (data as NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    block(responseDict as AnyObject , APIResult.APIError)
                } catch {
                    DispatchQueue.main.async {
                        print("json error: \(error.localizedDescription)")
                        block(false as AnyObject , APIResult.APIError)
                    }
                }
            }
            else if (responseHeader.statusCode == 401) {
                print("json error: \(error!.localizedDescription)")
                block(nil, APIResult.APIError)
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if (responseHeader.statusCode ==  302) {
                        appDel?.sessionOUT()
                    }
                    else if (responseHeader.statusCode ==  500) {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                }
            }
        }
        
        task.resume()
    }
    
    //MARK: postDataWithBlankResponseOrErrorMsg
    func postDataWithBlankResponseOrErrorMsgFromUrl(url : String, dic : NSDictionary , block: @escaping ServiceComplitionBlockArray)
    {
        let jsonData = try? JSONSerialization.data(withJSONObject: dic)
        print(jsonData?.description as Any)
        // create post request
        let url = URL(string: baseUrl + url)!
        var request = URLRequest(url: url)
        request.setValue(appDel?.userObj.SessionId, forHTTPHeaderField:"SessionId")
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        request.httpMethod = "POST"
        
        // insert json data to the request
        request.httpBody = jsonData
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                CommonFunctions().stopAnimateLoader2()
                CommonFunctions().stopAnimate()
                let code = (error! as NSError).code
                if code == internetErrorCode {
                    DispatchQueue.main.async {
                        appDel?.window?.makeToast(msgNoInternet)
                        block(nil , APIResult.APIError)
                    }
                }
                else if (error?.localizedDescription.contains("302"))! {
                    DispatchQueue.main.async {
                        appDel?.sessionOUT()
                        
                    }
                }
                DispatchQueue.main.async {
                    block(nil , APIResult.APIError)
                }
                return
            }
            
            let responseHeader = response as! HTTPURLResponse
            
            if (responseHeader.statusCode ==  200) {
                block(nil , APIResult.APISuccess)
            }
            else if (responseHeader.statusCode ==  400) {
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (data as NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    block(responseDict as AnyObject , APIResult.APIError)
                } catch {
                    DispatchQueue.main.async {
                        block(nil , APIResult.APIError)
                    }
                }
            }
            else {
                DispatchQueue.main.async {
                    block(nil , APIResult.APIError)
                }
            }
        }
        
        task.resume()
    }
    
    func postCreateTaskDatadicFromUrl(url : String, dic : [String : AnyObject] , block: @escaping ServiceComplitionBlockArray)
    {
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        
        if let strSession : String = appDel?.userObj.SessionId
        {
            if strSession.count < 5 {
                appDel?.window?.makeToast("Invalid credentials")
                return
            }
        }
        
        let myUrl : String = baseUrl + url
        manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
        manager.requestSerializer.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")

        manager.post(myUrl, parameters: dic, progress: { (progress) in
        }
            , success: {(sessionDatatask , responseObject) in
                
                do {
                    
                    let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    
                    let responseHeader = sessionDatatask.response as! HTTPURLResponse
                    DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    }
                    if (responseHeader.statusCode ==  200) {
                        
                        block(responseDict , APIResult.APISuccess)
                        
                        //    block(responseDict , APIResult.APIError)
                        
                    }
                    else {
                        block("exeption" as AnyObject , APIResult.APIError)
                    }

                    // use jsonObject here
                } catch {
                    
                    DispatchQueue.main.async {
                    print("json error: \(error)")
                    CommonFunctions().stopAnimate()
                    }
                }
                
        }, failure: {(sessionDatatask , error) in
            DispatchQueue.main.async {
                appDel?.loader.stopAnimatingGIF()
                appDel?.loader.isHidden = true
            }
            print("fail")
            block("fail" as AnyObject , APIResult.APIError)
        })
    }
    
    func PutDatadicFromUrl(url : String, dic : [String : AnyObject] , block: @escaping ServiceComplitionBlockArray)
    {
        let jsonData = try? JSONSerialization.data(withJSONObject: dic)
        print(jsonData?.description as Any)
        // create post request
        let url = URL(string: baseUrl + url)!
        var request = URLRequest(url: url)
        request.setValue(appDel?.userObj.SessionId, forHTTPHeaderField:"SessionId")
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        request.httpMethod = "PUT"
        
        // insert json data to the request
        request.httpBody = jsonData
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                CommonFunctions().stopAnimateLoader2()
                CommonFunctions().stopAnimate()
                let code = (error! as NSError).code
                if code == internetErrorCode {
                    DispatchQueue.main.async {
                        appDel?.window?.makeToast(msgNoInternet)
                        block(nil , APIResult.APIError)
                    }
                }
                else if (error?.localizedDescription.contains("302"))! {
                   DispatchQueue.main.async {
                        appDel?.sessionOUT()
                        
                    }
                }
                DispatchQueue.main.async {
                    block(nil , APIResult.APIError)
                }
                return
            }
            
            let responseHeader = response as! HTTPURLResponse
            
            if (responseHeader.statusCode ==  200) {
                block(nil , APIResult.APISuccess)
            }
            else if (responseHeader.statusCode ==  400) {
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (data as NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    block(responseDict as AnyObject , APIResult.APIError)
                } catch {
                    DispatchQueue.main.async {
                        block(nil , APIResult.APIError)
                    }
                }
            }
            else {
                DispatchQueue.main.async {
                    block(nil , APIResult.APIError)
                }
            }
        }
        
        task.resume()
    }

    
    func postArrayDatadicFromUrl(url : String, dic : [String : AnyObject] , block: @escaping ServiceComplitionBlockArray)
    {
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        if let strSession : String = appDel?.userObj.SessionId
        {
            if strSession.count < 5 {
                appDel?.window?.makeToast("Invalid credentials")
                CommonFunctions().stopAnimate()
                return
            }
        }
        
        let myUrl : String = baseUrl + url
        manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
        
        manager.post(myUrl, parameters: dic, progress: { (progress) in
        }
            , success: {(sessionDatatask , responseObject) in
                let responseHeader = sessionDatatask.response as! HTTPURLResponse
                print(responseHeader.statusCode)
                do {
                    
                    let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    
                    let responseHeader = sessionDatatask.response as! HTTPURLResponse
                    
                    if (responseHeader.statusCode ==  200) {
                        
                        
                        block(responseDict as AnyObject , APIResult.APISuccess)
                        
                        //    block(responseDict , APIResult.APIError)
                        
                    }
                    else {
                        block(responseDict as AnyObject , APIResult.APIError)
                    }
                    
                    
                    // use jsonObject here
                } catch {
                    
                    
                    print("json error: \(error)")
                    block(error as AnyObject , APIResult.APIError)
                }
                
        }, failure: {(sessionDatatask , error) in
            let code = (error as NSError).code
            if code == internetErrorCode {
                DispatchQueue.main.async {
                    appDel?.window?.makeToast(msgNoInternet)
                }
            }
            else if code == sessionTimeOutCode {
                DispatchQueue.main.async {
                    appDel?.sessionOUT()
                }
            }
            print(error)
            block(error as AnyObject , APIResult.APIError)
        })
    }

    
    func postDatadicFromUrl(url : String, dic : [String : AnyObject] , block: @escaping ServiceComplitionBlock)
    {
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        manager.completionQueue = DispatchQueue.global(qos: .background)
        if let strSession : String = appDel?.userObj.SessionId
        {
            if strSession.count < 5 {
                appDel?.window?.makeToast("Invalid credentials")
                CommonFunctions().stopAnimate()
                return
            }
        }
        
        let myUrl : String = baseUrl + url
        print(myUrl)
        manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
       
        manager.post(myUrl, parameters: dic, progress: { (progress) in
        }
            , success: {(sessionDatatask , responseObject) in
                let responseHeader = sessionDatatask.response as! HTTPURLResponse
                print(responseHeader.statusCode)
                do {
                    DispatchQueue.main.async {
                        CommonFunctions().stopAnimate()
                    }
                    let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as! [String : AnyObject]
                    print ("responseDict====\(responseDict)")
                    
                    let responseHeader = sessionDatatask.response as! HTTPURLResponse
                    print(responseHeader.statusCode)
                    if (responseHeader.statusCode ==  200) {
                        
                       
                            block(responseDict , APIResult.APISuccess)
                        
                        //    block(responseDict , APIResult.APIError)
                        
                    }
                    else {
                        block(responseDict , APIResult.APIError)
                    }
                    // use jsonObject here
                } catch {
                    
                    print("json error: \(error)")
                    block(["error":error as AnyObject] , APIResult.APIError)
                    DispatchQueue.main.async {
                        CommonFunctions().stopAnimate()
                    }
                }
                
        }, failure: {(sessionDatatask , error) in
            DispatchQueue.main.async {
                CommonFunctions().stopAnimate()
                if error.localizedDescription.contains("302") {
                    DispatchQueue.main.async {
                        appDel?.sessionOUT()
                    }
                }
            }
            print("fail")
            block(["error":error as AnyObject] , APIResult.APIError)
        })
        
    }
    //MARK: DELETE ECM DOCUMENT
    func postDataDicWithBlankResponceFromUrl(url : String, dic : [String : AnyObject] , block: @escaping ServiceComplitionBlock)
    {
        
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        if let strSession : String = appDel?.userObj.SessionId
        {
            if strSession.count < 5 {
                appDel?.window?.makeToast("Invalid credentials")
                CommonFunctions().stopAnimate()
                return
            }
        }
        
        let myUrl : String = baseUrl + url
        
        manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
        
        manager.post(myUrl, parameters: dic, progress: { (progress) in
        }
            , success: {(sessionDatatask , responseObject) in
                let responseHeader = sessionDatatask.response as! HTTPURLResponse
                print(responseHeader.statusCode)
            
                
                if (responseHeader.statusCode ==  200) {
                    
                    
                    block(nil , APIResult.APISuccess)
                    
                }
                else {
                    block(nil , APIResult.APIError)
                }
                
        }, failure: {(sessionDatatask , error) in
           
            print("fail")
            block(["error":error as AnyObject] , APIResult.APIError)
        })
        
    }
    func postDataForApprovalFromUrl(url : String, dic : [String : AnyObject] , block: @escaping ServiceComplitionBlock)
    {
        CommonFunctions().animate()
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        if let strSession : String = appDel?.userObj.SessionId
        {
            if strSession.count < 5 {
                appDel?.window?.makeToast("Invalid credentials")
                CommonFunctions().stopAnimate()
                return
            }
        }
        
        let myUrl : String = baseUrl + url
        manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
        
        manager.post(myUrl, parameters: dic, progress: { (progress) in
        }
            , success: {(sessionDatatask , responseObject) in
                let responseHeader = sessionDatatask.response as! HTTPURLResponse
                print(responseHeader.statusCode)
                
                if (responseHeader.statusCode ==  200) {
                        
                    block(nil , APIResult.APISuccess)
                    
                }
                else {
                    block(nil , APIResult.APIError)
                }
                
        }, failure: {(sessionDatatask , error) in
            
            block(["error":error as AnyObject] , APIResult.APIError)
        })
        
    }
    
    func Login(url : String, headerValue : String , dic : [String : AnyObject] , block: @escaping ServiceComplitionBlock)
    {
        
        CommonFunctions().animate()
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        
        manager.requestSerializer.setValue(ClientSecret , forHTTPHeaderField: "ClientSecret")
        manager.requestSerializer.setValue(headerValue , forHTTPHeaderField: "Authorization")
        let myUrl : String = baseUrl + url

        manager.post(myUrl, parameters: dic, progress: { (progress) in
        }
            , success: {(sessionDatatask , responseObject) in
                
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as! [String : AnyObject]
                    print ("responseDict====\(responseDict)")
                    
                    let responseHeader = sessionDatatask.response as! HTTPURLResponse
                    DispatchQueue.main.async {
                        CommonFunctions().stopAnimate()
                    }
                    if (responseHeader.statusCode ==  200) {
                        block(responseDict , APIResult.APISuccess)
                        //    block(responseDict , APIResult.APIError)
                    }
                    else {
                        block(responseDict , APIResult.APIError)
                    }
                 
                    // use jsonObject here
                } catch {
                    
                    print("json error: \(error)")
                    DispatchQueue.main.async {
                        CommonFunctions().stopAnimate()
                    }
                }
                
        }, failure: {(sessionDatatask , error) in
            DispatchQueue.main.async {
                appDel?.window?.makeToast("Authentication failed")
                appDel?.loader.stopAnimatingGIF()
                appDel?.loader.isHidden = true
            }
            print("fail")
            
        })
    }
    
    
    
    
    //MARK: LOGIN WITH TOUCH ID
    
    func PostDataAndGetDataLogin(headerValue : String, dic : NSDictionary , block: @escaping ServiceComplitionBlockArray) {
        let jsonData = try? JSONSerialization.data(withJSONObject: dic)
        
        // create post request
        let url = URL(string: baseUrl + loginUrl)!
        var request = URLRequest(url: url)
        
        request.setValue(headerValue, forHTTPHeaderField: "Authorization")
        request.setValue(ClientSecret, forHTTPHeaderField: "ClientSecret")
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        request.httpMethod = "POST"
        
        // insert json data to the request
        request.httpBody = jsonData
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                CommonFunctions().stopAnimate()
                let code = (error! as NSError).code
                if code == internetErrorCode {
                    DispatchQueue.main.async {
                        appDel?.window?.makeToast(msgNoInternet)
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: NotificationNoInternet), object: nil)
                    }
                }
                if (error?.localizedDescription.contains("302"))! {
                    DispatchQueue.main.async {
                        appDel?.sessionOUT()
                    }
                }
                print(error?.localizedDescription ?? "No data")
                return
            }
            
            let responseHeader = response as! HTTPURLResponse
            
            if (responseHeader.statusCode ==  200) {
                
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (data as NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    block(responseDict as AnyObject , APIResult.APISuccess)
                } catch {
                    block(false as AnyObject , APIResult.APISuccess)
                }
                
            }
            else if (responseHeader.statusCode ==  400) {
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (data as NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    block(responseDict as AnyObject , APIResult.APIError)
                } catch {
                    DispatchQueue.main.async {
                        print("json error: \(error.localizedDescription)")
                        block(false as AnyObject , APIResult.APIError)
                    }
                }
            }
            else if (responseHeader.statusCode == 401) {
                print("json error: \(error!.localizedDescription)")
                block(nil, APIResult.APIError)
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if (responseHeader.statusCode ==  302) {
                       appDel?.sessionOUT()
                    }
                    else if (responseHeader.statusCode ==  500) {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                }
            }
        }
        
        task.resume()
    }
    
    func postDatadicFromUrlForBase64(url : String, dic : [String : AnyObject] , block: @escaping ServiceComplitionBlock)
    {
        manager.requestSerializer = AFJSONRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        
        if let str : String = UserDefaults.standard.object(forKey: userSession) as? String{
            print(str)
            
            manager.requestSerializer.setValue(str, forHTTPHeaderField: "session-token")
            
        }
        
        manager.post(url, parameters: dic, progress: { (progress) in
        }
            , success: {(sessionDatatask , responseObject) in
                
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as! [String : AnyObject]
                    print ("responseDict====\(responseDict)")
                    
                    let responseHeader = sessionDatatask.response as! HTTPURLResponse
                    
                    if (responseHeader.statusCode ==  200) {
                        
                        if responseDict["status"] as! Int == 1
                        {
                            block(responseDict , APIResult.APISuccess)
                        }
                        else
                        {
                            block(responseDict , APIResult.APIError)
                        }
                    }
                    else {
                        block(responseDict , APIResult.APIError)
                    }
                    // use jsonObject here
                } catch {
                    
                    DispatchQueue.main.async {
                    print("json error: \(error)")
                    appDel?.loader.stopAnimatingGIF()
                appDel?.loader.isHidden = true
                    }
                }
                
        }, failure: {(sessionDatatask , error) in
            DispatchQueue.main.async {
            appDel?.loader.stopAnimatingGIF()
                appDel?.loader.isHidden = true
            }
            print("fail")
            
        })
    }
    
    
    func uploadDataWithMultipart(url : String, dic : [String : AnyObject] , multipartImageData : Data? , block: @escaping ServiceComplitionBlockArray)
    {
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        
        let myUrl : String = baseUrl + url

        if let strSession : String = appDel?.userObj.SessionId
        {
            if strSession.count < 5 {
                appDel?.window?.makeToast("Invalid credentials")
                return
            }
        }
        manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
        manager.post(myUrl, parameters: dic, constructingBodyWith: { (multipartData) in
            
            if (multipartImageData != nil) {
                    multipartData.appendPart(withFileData: multipartImageData! as Data, name: "file_upload", fileName: "icon.jpg", mimeType: "image/jpeg")
            }
            
        }, progress: {(progress) in }, success: {(sessionDatatask , responseObject) in
            
            do {
                let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as! [String : AnyObject]
                print ("responseDict====\(responseDict)")
                
                let responseHeader = sessionDatatask.response as! HTTPURLResponse
                
                if (responseHeader.statusCode ==  200) {
                    
                    if (responseDict["FileName"] != nil)
                    {
                        block(responseDict as AnyObject? , APIResult.APISuccess)
                    }
                    else
                    {
                        block(responseDict as AnyObject? , APIResult.APIError)
                    }
                }
                else {
                    block(responseDict as AnyObject? , APIResult.APIError)
                }
                // use jsonObject here
            } catch {
                
                DispatchQueue.main.async {
                print("json error: \(error)")
                appDel?.loader.stopAnimatingGIF()
                appDel?.loader.isHidden = true
                }
            }
            
        }, failure: {(sessionDatatask , error) in
            DispatchQueue.main.async {
            appDel?.loader.stopAnimatingGIF()
                appDel?.loader.isHidden = true
            print("fail:\(error.localizedDescription)")
            }
            
        })
    }
    
    
    func getDatadicFromUrl(url : String, dic : [String : AnyObject] , block: @escaping ServiceComplitionBlockArray)
    {
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        if let strSession : String = appDel?.userObj.SessionId
        {
            if strSession.count < 5 {
                appDel?.window?.makeToast("Invalid credentials")
                CommonFunctions().stopAnimate()
                return
            }
        }
        
        let myUrl : String = baseUrl + url
        manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
        
        manager.get(myUrl, parameters: dic, progress: { (progress) in
        }
            , success: {(sessionDatatask , responseObject) in
                
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    
                    let responseHeader = sessionDatatask.response as! HTTPURLResponse
                    
                    if (responseHeader.statusCode ==  200) {
                        
                        block(responseDict as AnyObject? , APIResult.APISuccess)
                        
                        //    block(responseDict , APIResult.APIError)
                        
                    }
                    else {
                        block(responseDict as AnyObject? , APIResult.APIError)
                    }
                    // use jsonObject here
                } catch {
                    print("json error: \(error.localizedDescription)")
                    block([:] as AnyObject? , APIResult.APIError)
                }
                
        }, failure: {(sessionDatatask , error) in
            print("json error: \(error.localizedDescription)")
            let code = (error as NSError).code
            if code == internetErrorCode {
                DispatchQueue.main.async {
                    appDel?.window?.makeToast(msgNoInternet)
                }
                return
            }
            else if (error.localizedDescription.contains("302")) {
                DispatchQueue.main.async {
                    appDel?.sessionOUT()
                }
                return
            }
            block([:] as AnyObject? , APIResult.APIError)
        })
    }
    
    
    func getDatadicFromUrlWithoutProgress(url : String, dic : [String : AnyObject] , block: @escaping ServiceComplitionBlockArray)
    {
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        manager.completionQueue = DispatchQueue.global(qos: .background)
        
        if let strSession : String = appDel?.userObj.SessionId
        {
            if strSession.count < 5 {
                appDel?.window?.makeToast("Invalid credentials")
                CommonFunctions().stopAnimate()
                return
            }
        }
        
        let myUrl : String = baseUrl + url
        manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
        manager.get(myUrl, parameters: dic, progress: { (progress) in
        }
            , success: {(sessionDatatask , responseObject) in
                
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    
                    let responseHeader = sessionDatatask.response as! HTTPURLResponse
                    
                    if (responseHeader.statusCode ==  200) {
                        
                        block(responseDict as AnyObject? , APIResult.APISuccess)
                        
                    }
                    else {
                        block(responseDict as AnyObject? , APIResult.APIError)
                    }
                    
                } catch {
                    print("json error: \(error)")
                    CommonFunctions().stopAnimate()
                    block([:] as AnyObject? , APIResult.APIError)
                }
                
        }, failure: {(sessionDatatask , error) in
            DispatchQueue.main.async {
                print("json error: \(error)")
                CommonFunctions().stopAnimate()
                let code = (error as NSError).code
                if code == internetErrorCode {
                    appDel?.window?.makeToast(msgNoInternet)
                    return
                }
                else if (error.localizedDescription.contains("302")) {
                    DispatchQueue.main.async {
                        appDel?.sessionOUT()
                    }
                    return
                }
                block([:] as AnyObject? , APIResult.APIError)
            }
        })
    }
    
    
    func DeleteDatadicFromUrlWithoutProgress(url : String, dic : [String : AnyObject] , block: @escaping ServiceComplitionBlockArray)
    {
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.requestSerializer.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")

        manager.responseSerializer = AFHTTPResponseSerializer()
        if let strSession : String = appDel?.userObj.SessionId
        {
            if strSession.count < 5 {
                appDel?.window?.makeToast("Invalid credentials")
                CommonFunctions().stopAnimate()
                return
            }
        }
        
        let myUrl : String = baseUrl + url
        manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
        manager.delete(myUrl, parameters: dic, success: {(sessionDatatask , responseObject) in
            
            do {
//                let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as AnyObject
//                print ("responseDict====\(responseDict)")
                
                let responseHeader = sessionDatatask.response as! HTTPURLResponse
                
                if (responseHeader.statusCode ==  200) {
                    
                    block(responseObject as AnyObject? , APIResult.APISuccess)
                    
                    //    block(responseDict , APIResult.APIError)
                    
                }
                else {
                    block(responseObject as AnyObject? , APIResult.APIError)
                }
                
                
                // use jsonObject here
            } catch {
                
                DispatchQueue.main.async {
                    print("json error: \(error)")
                    block(NSDictionary() as AnyObject? , APIResult.APISuccess)
                }
            }
            
        }, failure: {(sessionDatatask , error) in
            
            DispatchQueue.main.async {
                print(error)
                let testObj : [String : AnyObject] = ["fail" : "Api" as AnyObject]
                block(testObj as AnyObject? , APIResult.APIError)
                print("fail")
            }
        })
    }
    
    //MARK: ECM Document Upload
    
    func uploadDocumentDataWithMultipart(isFront : Bool,frontfileExtension : String,frontmimeType : String,backfileExtension : String,backmimeType : String ,url : String, documentName : String ,dic : [String : AnyObject] , frontImageData : Data? ,backImageData : Data?, block: @escaping ServiceComplitionBlockArray)
    {
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        
        let myUrl : String = baseUrl + url
        
        if let strSession : String = appDel?.userObj.SessionId
        {
            if strSession.count < 5 {
                appDel?.window?.makeToast("Invalid credentials")
                return
            }
        }
        
        manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
        manager.post(myUrl, parameters: dic, constructingBodyWith: { (multipartData) in
            
            if (frontImageData != nil) {
                multipartData.appendPart(withFileData: frontImageData! as Data, name: "File1", fileName: documentName + ((isFront == true) ? "_front." : ".") + frontfileExtension, mimeType: frontmimeType)
            }
            if (backImageData != nil) {
                multipartData.appendPart(withFileData: backImageData! as Data, name: "File2", fileName: documentName + "_back." + backfileExtension, mimeType: backmimeType)
            }
            
        }, progress: {(progress) in }, success: {(sessionDatatask , responseObject) in
            
            let responseHeader = sessionDatatask.response as! HTTPURLResponse
            if (responseHeader.statusCode ==  200) {
                block([:] as AnyObject? , APIResult.APISuccess)
            }
            else{
                block([:] as AnyObject? , APIResult.APIError)

            }
            
            
        }, failure: {(sessionDatatask , error) in
            DispatchQueue.main.async {
            appDel?.loader.stopAnimatingGIF()
            appDel?.loader.isHidden = true
            print("fail:\(error.localizedDescription)")
            block([:] as AnyObject? , APIResult.APIError)
            }
        })
        
    }

    
}
