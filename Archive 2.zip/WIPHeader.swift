//
//  WIPHeader.swift
//  WorkInProgress
//
//  Created by AON on 04/12/16.
//  Copyright © 2016 FlowRocket, LLC. All rights reserved.
//

import Foundation
import UIKit

var appDel = UIApplication.shared.delegate as? AppDelegate
var IsIpad = (UIDevice.current.userInterfaceIdiom == .pad)
var iphoneX = false

let spinner = UIActivityIndicatorView()

let GlobalbackgroundImage : UIImage = #imageLiteral(resourceName: "InsightBG")
var userSession = "sessionOfUser"
var kSelectedFolders = "SelectedFolders"
var kRefreshRecentDoc = "RefreshRecentDoc"
var kOpenUnAssignedTasks = "kOpenUnAssignedTasks"
var kOpenTicketsDetails = "kOpenTicketsDetails"
var kDocumentBackToRoot = "kDocumentBackToRoot"

var typeMobilePhone = 1
//var typeWorkPhone = 2

var typeEmail = 4
var typeWebSite = 5
var typeAddress = 7

var theme_color = UIColor(red: 0.1647058824, green: 0.6470588235, blue: 0.2470588235, alpha: 0.8)
var theme_selected_color = UIColor.color("#2AA53F")
var segmentOrange = UIColor(red: 0.9333333333, green: 0.5450980392, blue: 0.07058823529, alpha: 1.0)
var theme_green_color = UIColor.color("#2AA53F")
var theme_orange_color = UIColor.color("#F66417")
var timesheet_orange = UIColor.color("#deb887")
var theme_blue_color = UIColor.color("#3b5999")
var blueTime_color = UIColor.color("#3E9DD4")
var username_color = UIColor.color("#850824")
var PPT_theme_color = UIColor(red: 0.768627451, green: 0.1843137255, blue: 0.1098039216, alpha: 0.8)

var Blue_theme_color = UIColor(red: 0.2117647059, green: 0.3294117647, blue: 0.662745098, alpha: 0.8)
var Pdf_theme_color = UIColor(red: 0.8078431373, green: 0.2078431373, blue: 0.2039215686, alpha: 0.8)
var Folder_theme_color = UIColor(red: 0.8470588235, green: 0.7411764706, blue: 0.4823529412, alpha: 0.8)

//MARK:MSG
var msgTaskActiveSuccess = "Task active successfully"
var msgTaskStopSuccess = "Task stop successfully"
var msgTaskActiveCanNotBeDelete = "Stop the task before delete the task"
var msgTaskActiveCanNotBeClose = "Stop the task before close the task"
var msgInvalidUsernameOrPassword = "Invalid username or password."
var msgSomethingWrong = "Something went wrong, please try later."
var msgTodoCompleted = "To-Do Closed Successfully."
var msgTodoReOpened = "To-Do Reopened Successfully."
var msgFileNotFound = "This file has been deleted or moved to a different location."
var msgUnauthorised = "You are Unauthorized to perform this action."
var msgRistricted = "You cannot perform any action over here."
var msgTaskDeleteSuccess = "Task deleted successfully"
var msgTodoDeleteSuccess = "To-Do deleted successfully"
var msgTaskCloseSuccess = "Task completed successfully"
var msgTicketDeleteSuccess = "Ticket deleted successfully"
var msgDeleteTask = "You are not authorized to Delete Task"
var msgDeleteTicket = "You are not authorized to Delete Ticket"
var msgCloseTask = "You are not authorized to complete Task"
var msgApiError = "There was an error in fetching data!"
var msgTaskNotDeleted = "Task can not be deleted"
var msgTodoNotDeleted = "To-Do can not be deleted"
var msgTicketNotDeleted = "Ticket can not be deleted"
var msgNoRecordFound = "No Records Found"
var msgNoFolderPermission = "Folder does not exist or you don’t have permission to access the folder"
var msgNoInternet = "You are not connected to internet!"
var msgThemeApply = "Theme will be apply once you logout. Do you want to logout ?"
var msgTaskDescriptionEditedSuccess = "Task description edited successfully."
var msgInvalidEnterPriceUrl = "Please enter a valid enterprise url for login"
var fileFormateNotSupport = "File format not supported."
var alertTitle = "FlowRocket"
var internetErrorCode = -1009
var sessionTimeOutCode = 302
var tempHTML = "<html><body><font size='4'> added file(s) All Companies Comparision Sheet.xlsx to folder SalesMkt Docs</p></font></body></html>"
//MARK: Notification Name
var NotificationTask  = "NotificationTask"
var NotificationContactFetch  = "NotificationContactFetch"
var NotificationActiveTask  = "NotificationActiveTask"
var NotificationActiveTaskProgress  = "NotificationActiveTaskProgress"
var NotificationInsightCount  = "InsightCount"
var NotificationcontactFetched  = "contactfetch"
var NotificationFail  = "NotificationFail"
var NotificationContectFail  = "NotificationContectFail"
var NotificationCurrentTaskFail = "NotificationCurrentTaskFail"
var NotificationNoInternet = "NotificationNoInternet"
//MARK: Base Service URL
var baseUrl = ""

var userImage = ""

var sharebyme = 44
var sharewithme = 45

var dateSyncOfGetContacts = "dateSyncOfGetContacts"

var userData = "userData"
var userDataPreference = "userDataPreference"

var sessionToken = "sessionToken"

var EnterPriseURL = "EnterPriseURL"

var loginUserName = "loginUserName"
var loginPassword = "loginPassword"

var forgotUserName = "forgotUserName"

var theme = "SelectedTheme"
var themeBorder = "SelectedThemeBorder"

var gothamMedium = "Gotham-Medium"
var gothamBook = "Gotham-Book"

let menuItem1 = "Work on it!"
let menuItem2 = "Revised Dt.-Hrs./Complete"
let menuItem3 = "Create Follow-up"
let menuItem4 = "Add Progress"
let menuItem5 = "Add Note"
let menuItem6 = "Attach Document"
let menuItem7 = "Add Roadblock"
let menuItem8 = "Add Subtask"
let menuItem9 = "Add Bug"


let uploadOption1 = "Camera"
let uploadOption2 = "Document"
let uploadOption3 = "Link from FlowRocket Documents"
let uploadOption4 = "Photo & Video Library"
var TaskActionMenu : [String] = [menuItem1,menuItem2,menuItem3,menuItem4,menuItem5,menuItem6,menuItem7,menuItem8,menuItem9]

var globalMenu : [String] = []
var priorityArray : [String] = ["1","2","3","4","5","6","7","8","9"]

let colors = ["#598baf","#4b5320","#007fcc","#b1560f","#774503","#e6bd17","#b7855b","#3f704d","#4cbb17","#de73ff","#800404","#88807b","#008ecc","#fc6600","#01796f","#FF69B4","#0d507b","#ec5578","#0b5a40","#18ab89","#34E381","#39CCCC","#997950","#59b961","#483624"]

let themeName = ["Air Force","Army","Blue","Bronze","Brown","Gold","Golden Rod","Hunder","Kelly","Lollopop","Maroon","Mink","Olympic","Orange","Pine","Pink","Prussian","Punch","Sarcramento","Sea Green","Spring Green","Teal","Tortilla","WIP Green","Wood"]


var TagSelectNotification = "TagSelectNotification"

var selectedOptionKey = "SelectedOption"
var selectedOptionKeyECM = "ECM"
var selectedOptionKeyTask = "Task"
var selectedOptionKeyTaskExist = "TaskExist"
var selectedOptionKeyTicket = "Ticket"
var selectedOptionKeyTicketExist = "TicketExist"
var selectedOptionKeyActivity = "Activity"
var selectedOptionKeyActivityExist = "ActivityExist"
var selectedOptionKeyLeads = "Leads"
var selectedOptionKeyExistingLeads = "selectedOptionKeyExistingLeads"
var selectedOptionKeyOpportunity = "Opportunity"
var selectedOptionKeyexistingOpportunity = "existingOpportunity"
var selectedOptionKeyCreateToDo = "createTodo"
var selectedOptionKeyToDoExist = "existTodo"

//MARK: Menu Tag
var tagMenuProgressEntry = 1
var tagMenuAddress = 2
var tagMenu360Insight = 3
var tagMenuECM = 4
var tagMenuMore = 5
var tagMenuCalender = 6
var tagMenuWIPFeeds = 7
var tagMenuReminders = 8
var tagMenuSetings = 9
var tagMenuLogout = 10
var tagRequestOff = 11
var tagGlobalSearch = 12

var keyMenuArray = "keyMenuArray"

//MARK: ADDRESSBOOK TYPE
var AddressBookTypeOne = "Business"
var AddressBookTypeTwo = "Prospect"

//MARK: Address Attributes
var typeAdditional = "Additional"
var typeAfterHrSupp = "After Hr. Supp."
var typeAnniversary = "Anniversary"
var typeBirthday = "Birthday"
var typeBusiness = "Business"
var typeCheckMailing = "Check Mailing"
var typeCustSvc = "Cust. Svc."
var typeEmail1 = "Email1"
var typeEmail2 = "Email2"
var typeEmail3 = "Email3"
var typeFacebook = "Facebook"
var typeTwitter = "Twitter"
var typeYoutube = "Youtube"
var typePinterest = "Pinterest"
var typeLinkedin = "Linkedin"

var typeFax = "Fax"
var typeHome = "Home"
var typeHomePhone = "Home Phone"
var typeIntrest = "Interest"
var typeJobTitle = "Job Title"
var typeMedUWFax = "Med. UW Fax"
var typeMedUWSupp = "Med. UW Supp."
var typeMobile = "Mobile"
var typeOtherFax = "Other Fax"
var typeOtherPhone = "Other Phone"
var typeOvernight = "Overnight"
var typePager = "Pager"
var typePhone2 = "Phone2"
var typePObox = "PO Box"
var typePrivateFax = "Private Fax"
var typeShipping = "Shipping"
var typeSpouseBirthday = "Spouse’s Birthday"
var typeStateIncorporated = "State Incorporated "
var typeSuffix = "Suffix"
var typeTaxID = "Tax ID"
var typeURL = "URL"
var typeWeddingAnniversary = "Wedding Anniversary"
var typeWorkPhone = "Work Phone"
