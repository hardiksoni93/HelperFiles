//
//  CommonFunctions.swift
//  WorkInProgress
//
//  Created by AONMac on 30/03/18.
//  Copyright © 2018 Arpit Shah. All rights reserved.
//

import Foundation
import UIKit
import ZAlertView
import MWPhotoBrowser
import JTSImageViewController
import AVKit
import AVFoundation
import ObjectMapper
import SKPhotoBrowser
import AFNetworking

var vC : UIViewController = UIViewController()

public class CommonFunctions {
    
    required init() {
        if let colorcode : String = UserDefaults.standard.object(forKey: themeBorder) as? String{
            ZAlertView.positiveColor = UIColor.color(colorcode)
        }
    }
    let documentInteractionController = UIDocumentInteractionController()
    
    var selectedPhotoPath = URL(string: "")
    
    let yourAttributes : [String : Any] = [convertFromNSAttributedStringKey(NSAttributedString.Key.foregroundColor): UIColor.white, convertFromNSAttributedStringKey(NSAttributedString.Key.font): UIFont.init(name: "Gotham-Medium", size: 18)!]
    
    let yourOtherAttributes : [String : Any] = [convertFromNSAttributedStringKey(NSAttributedString.Key.foregroundColor): UIColor.white, convertFromNSAttributedStringKey(NSAttributedString.Key.font): UIFont.init(name: "Gotham-Medium", size: 8)!]
    
    //MARK: PLUS BUTTON MENU
    func addMenus(){
        globalMenu.removeAll()
        if appDel?.userObj.CanCreateTimesheet == true{
            globalMenu.append("ProgressEntry")
        }
        if appDel?.userObj.CanCreateProject == true{
            globalMenu.append("Work Item")
            globalMenu.append((appDel?.userObj.projectSingle_label)!)
        }
        if appDel?.userObj.CanCreatetActivity == true{
            globalMenu.append("Activity")
            globalMenu.append("Opportunity")
            globalMenu.append("Lead")
        }
        if appDel?.userObj.CanCreateTicket == true{
            globalMenu.append("Ticket")
        }
        
        globalMenu.append("Time-Off")
        globalMenu.append("To-Do")
        
        globalMenu = globalMenu.sorted()
    }
    
    //MARK: TOUCH LOGIN
    func apiRequestToLogin(encryptdata: String, finalKeyValueDict : [String:AnyObject], vc: UIViewController) {
        CommonFunctions().animate()
        let manager = APIManager.apiManager
        manager.PostDataAndGetDataLogin(headerValue: encryptdata, dic: finalKeyValueDict as NSDictionary) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let userDict : [String : AnyObject] = dataResponse as? [String : AnyObject] {
                        print(userDict as Any)
                        let userObj = User()
                        userObj.setAttributeInfo(json:userDict)
                        if userObj.SessionId.count > 10 {
                            userImage = userObj.IMAGE_NAME
                            UserDefaults.standard.set(userImage, forKey: "userImage")
                            let userBG = NSKeyedArchiver.archivedData(withRootObject: userDict as Any)
                            UserDefaults.standard.set(userBG, forKey: userData)
                            
                            UserDefaults.standard.set(userObj.SessionId, forKey: sessionToken)
                            if (appDel?.userPreferenceObj.iSSESSIONEXPIRED)! {
                                let userdft = UserDefaults(suiteName: "group.com.workInProgress")
                                if appDel?.selectedOption != nil {
                                    userdft?.set(appDel?.selectedOption, forKey: selectedOptionKey)
                                    appDel?.docURL = appDel?.sharedUrl
                                    let key = appDel?.docURL?.absoluteString.components(separatedBy: "=").last
                                    appDel?.docDic = userdft?.object(forKey: key!) as? NSDictionary
                                }
                            }
                            appDel?.userPreferenceObj = UserPreferences(userid: userObj.USERID, contactname: userObj.CONTACT_FIRSTNAME, contactlastname: userObj.CONTACT_LASTNAME, username: (appDel?.userPreferenceObj.uSERNAME)!, password: (appDel?.userPreferenceObj.pASSWORD)!, sessionid: userObj.SessionId, instance: baseUrl.replacingOccurrences(of: "/api/", with: ""), imagename: userObj.IMAGE_NAME, issessionexpired: (appDel?.userPreferenceObj.iSSESSIONEXPIRED)!, isrememberme: (appDel?.userPreferenceObj.iSREMEMBER)!, istouchid: (appDel?.userPreferenceObj.iSTOUCHIDON)!)
                            
                            let encoder = JSONEncoder()
                            if let encoded = try? encoder.encode(appDel?.userPreferenceObj) {
                                let defaults = UserDefaults.standard
                                defaults.set(encoded, forKey: userDataPreference)
                            }
                            
                            appDel?.userObj = userObj
                            //appDel?.getServerContacts()
                            appDel?.userID = 0
                            appDel?.selectedDate = ""
                            CommonFunctions().addMenus()
                            
                            UserDefaults.standard.set((appDel?.userPreferenceObj.uSERNAME)!, forKey: loginUserName)
                            UserDefaults.standard.set((appDel?.userPreferenceObj.pASSWORD)!, forKey: loginPassword)

                            if appDel?.docURL?.absoluteString == nil {
                                appDel?.setDefaultTabBarNew()
                            }
                            else if appDel?.emailSharedDocURL?.absoluteString != nil {
                                appDel?.selectedIndex = 3
                                appDel?.setDefaultTabBarNew()
                            }
                            else {
                                let userdft = UserDefaults(suiteName: "group.com.workInProgress")
                                if let option : String = userdft?.object(forKey: selectedOptionKey) as? String {
                                    if option == selectedOptionKeyTask {
                                        DispatchQueue.main.async {
                                            appDel?.selectedIndex = 0
                                            appDel?.setDefaultTabBarNew()
                                            var curentVC = UIViewController()
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                                if let topVC = UIApplication.getTopViewController() {
                                                    curentVC = topVC
                                                    let importVC : CreateTaskNewVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateTaskNewVC") as? CreateTaskNewVC)!
                                                    importVC.docURL = appDel?.docURL
                                                    importVC.allProject = false
                                                    importVC.isFromShareScreen = true
                                                    importVC.selectedUserID = (appDel?.userObj.USERID)!
                                                    curentVC.navigationController?.pushViewController(importVC, animated: true)
                                                }
                                            })
                                        }
                                    }
                                    else if option == selectedOptionKeyTaskExist {
                                        DispatchQueue.main.async {
                                            appDel?.selectedIndex = 3
                                            appDel?.setDefaultTabBarNew()
                                            var curentVC = UIViewController()
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                                if let topVC = UIApplication.getTopViewController() {
                                                    curentVC = topVC
                                                    let importVC : AttachToExistingVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "AttachToExistingVC") as? AttachToExistingVC)!
                                                    importVC.docURL = appDel?.docURL
                                                    importVC.isFromECM = false
                                                    curentVC.navigationController?.pushViewController(importVC, animated: true)
                                                }
                                            })
                                        }
                                    }
                                    else if option == selectedOptionKeyActivityExist {
                                        DispatchQueue.main.async {
                                            appDel?.selectedIndex = 3
                                            appDel?.setDefaultTabBarNew()
                                            var curentVC = UIViewController()
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                                if let topVC = UIApplication.getTopViewController() {
                                                    curentVC = topVC
                                                    let importVC : AttachToExistingActivityVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "AttachToExistingActivityVC") as? AttachToExistingActivityVC)!
                                                    importVC.docURL = appDel?.docURL
                                                    importVC.isFromECM = false
                                                    curentVC.navigationController?.pushViewController(importVC, animated: true)
                                                }
                                            })
                                        }
                                    }
                                    else if option == selectedOptionKeyExistingLeads {
                                        DispatchQueue.main.async {
                                            appDel?.selectedIndex = 3
                                            appDel?.setDefaultTabBarNew()
                                            var curentVC = UIViewController()
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                                if let topVC = UIApplication.getTopViewController() {
                                                    curentVC = topVC
                                                    let importVC : ExistingLeadVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ExistingLeadVC") as? ExistingLeadVC)!
                                                    importVC.docURL = appDel?.docURL
                                                    curentVC.navigationController?.pushViewController(importVC, animated: true)
                                                }
                                            })
                                        }
                                    }
                                    else if option == selectedOptionKeyexistingOpportunity {
                                        DispatchQueue.main.async {
                                            appDel?.selectedIndex = 3
                                            appDel?.setDefaultTabBarNew()
                                            var curentVC = UIViewController()
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                                if let topVC = UIApplication.getTopViewController() {
                                                    curentVC = topVC
                                                    let importVC : ExistingOpportunityVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ExistingOpportunityVC") as? ExistingOpportunityVC)!
                                                    importVC.docURL = appDel?.docURL
                                                    curentVC.navigationController?.pushViewController(importVC, animated: true)
                                                }
                                            })
                                        }
                                    }
                                    else if option == selectedOptionKeyTicket {
                                        DispatchQueue.main.async {
                                            appDel?.selectedIndex = 0
                                            appDel?.setDefaultTabBarNew()
                                            var curentVC = UIViewController()
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                                if let topVC = UIApplication.getTopViewController() {
                                                    curentVC = topVC
                                                    let importVC : CreateTicketVC = (appDel?.WIPNewStoryBoard.instantiateViewController(withIdentifier: "CreateTicketVC") as? CreateTicketVC)!
                                                    importVC.docURL = appDel?.docURL
                                                    curentVC.navigationController?.pushViewController(importVC, animated: true)
                                                }
                                            })
                                        }
                                    }
                                    else if option == selectedOptionKeyTicketExist {
                                        DispatchQueue.main.async {
                                            appDel?.selectedIndex = 3
                                            appDel?.setDefaultTabBarNew()
                                            var curentVC = UIViewController()
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                                if let topVC = UIApplication.getTopViewController() {
                                                    curentVC = topVC
                                                    let importVC : ExistingTicketVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ExistingTicketVC") as? ExistingTicketVC)!
                                                    importVC.docURL = appDel?.docURL
                                                    importVC.isFromECM = false
                                                    curentVC.navigationController?.pushViewController(importVC, animated: true)
                                                }
                                            })
                                        }
                                    }
                                    else if option == selectedOptionKeyToDoExist {
                                        DispatchQueue.main.async {
                                            appDel?.selectedIndex = 3
                                            appDel?.setDefaultTabBarNew()
                                            var curentVC = UIViewController()
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                                if let topVC = UIApplication.getTopViewController() {
                                                    curentVC = topVC
                                                    let importVC : ExistingTodoVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ExistingTodoVC") as? ExistingTodoVC)!
                                                    importVC.docURL = appDel?.docURL
                                                    importVC.isFromECM = false
                                                    curentVC.navigationController?.pushViewController(importVC, animated: true)
                                                }
                                            })
                                        }
                                    }
                                    else if option == selectedOptionKeyECM {
                                        appDel?.selectedIndex = 3
                                        appDel?.setDefaultTabBarNew()
                                        var curentVC = UIViewController()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                            if let topVC = UIApplication.getTopViewController() {
                                                curentVC = topVC
                                                let importVC : ImportExternalDocumentVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ImportExternalDocumentVC") as? ImportExternalDocumentVC)!
                                                importVC.docURL = appDel?.docURL
                                                curentVC.navigationController?.pushViewController(importVC, animated: true)
                                            }
                                        })
                                    }
                                    else if option == selectedOptionKeyCreateToDo {
                                        DispatchQueue.main.async {
                                            appDel?.selectedIndex = 0
                                            appDel?.setDefaultTabBarNew()
                                            var curentVC = UIViewController()
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                                if let topVC = UIApplication.getTopViewController() {
                                                    curentVC = topVC
                                                    let importVC : CreateToDoVC = (appDel?.todoStoryBoard.instantiateViewController(withIdentifier: "CreateToDoVC") as? CreateToDoVC)!
                                                    importVC.docURL = appDel?.docURL
                                                    curentVC.navigationController?.pushViewController(importVC, animated: true)
                                                }
                                            })
                                        }
                                    }
                                    else if option == selectedOptionKeyActivity {
                                        DispatchQueue.main.async {
                                            appDel?.selectedIndex = 0
                                            appDel?.setDefaultTabBarNew()
                                            var curentVC = UIViewController()
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                                if let topVC = UIApplication.getTopViewController() {
                                                    curentVC = topVC
                                                    let importVC : CreateActivityVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateActivityVC") as? CreateActivityVC)!
                                                    importVC.docURL = appDel?.docURL
                                                    curentVC.navigationController?.pushViewController(importVC, animated: true)
                                                }
                                            })
                                        }
                                    }
                                }
                                else {
                                    appDel?.selectedIndex = 3
                                    appDel?.setDefaultTabBarNew()
                                    var curentVC = UIViewController()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                        if let topVC = UIApplication.getTopViewController() {
                                            curentVC = topVC
                                            let importVC : ImportExternalDocumentVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ImportExternalDocumentVC") as? ImportExternalDocumentVC)!
                                            importVC.docURL = appDel?.docURL
                                            curentVC.navigationController?.pushViewController(importVC, animated: true)
                                        }
                                    })
                                }
                            }
                        }
                    }
                    else if (dataResponse as? Bool) != nil
                    {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else if (dataResponse as? Bool) != nil
                    {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    else {
                        appDel?.window?.makeToast(msgInvalidUsernameOrPassword)
                        self.openloginscreen(loginvc: vc)
                    }
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast(msgSomethingWrong)
                }
            }
        }
    }
    
    func openloginscreen(loginvc: UIViewController) {
        let loginVc = appDel?.mainStoryBoard.instantiateViewController(withIdentifier: "WIPLoginVC") as? WIPLoginVC
        loginVc?.isFromDifferentUser = false
        loginvc.navigationController?.pushViewController(loginVc!, animated: true)
    }
    
    func changeHourMinFormat(hours: Double) -> String {
        var hrs = ""
        var indication = ""
        var pointValue = hours.truncatingRemainder(dividingBy: 1).roundTo(places: 2) * 60
        pointValue = pointValue.roundTo(places: 2)
        var min = Int(pointValue.rounded())
        if min < 0 {
            min = abs(min)
            indication = "-"
        }
        var mainHrs = Int(hours)
        if mainHrs < 0 {
           mainHrs = abs(mainHrs)
            indication = "-"
        }
        let strPointValue = String(format: "%02d", min)//String(describing: (min))
        let strMainHrs = String(format: "%02d", mainHrs)//String(describing: (mainHrs))
        hrs = indication + strMainHrs + ":" + strPointValue
        return hrs
    }
    
    //MARK: GET CURRENT DATE
    func getCurrentDate() -> String {
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        var resultDate : String = String()
        resultDate = formatter.string(from: date)
        return resultDate
    }
    
    //MARK: GET CURRENT DATE
    func getCurrentDateTime() -> String {
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH-mm-ss"
        var resultDate : String = String()
        resultDate = formatter.string(from: date)
        return resultDate
    }
    
    
    func checkIsCurrentprogress() -> Bool {
        if appDel?.selectedDate == CommonFunctions().getCurrentDate() {
            return true
        }
        else if (appDel?.progressListUrl.contains("Today"))! {
            appDel?.selectedDate = CommonFunctions().getCurrentDate()
            return true
        }
        return false
    }
    
    //MARK: LOADER
    func animate() {
        DispatchQueue.main.async {
            appDel?.loader.isHidden = false
            appDel?.loader.frame = CGRect(x: 0.0, y: 0.0, width: 64.0, height: 64.0)
            appDel?.loader.center = CGPoint(x: (appDel?.window?.frame.width)!/2.0, y: (appDel?.window?.frame.height)!/2.0)
            appDel?.loader.clipsToBounds = true
            appDel?.window?.addSubview((appDel?.loader)!)
            appDel?.loader.animate(withGIFNamed: (appDel?.currentGIFName)!)
        }
    }
    
    func animateLoader2() {
        DispatchQueue.main.async {
            appDel?.loader.prepareForReuse()
            appDel?.loader2.isHidden = false
            appDel?.loader2.frame = CGRect(x: 0.0, y: 0.0, width: 64.0, height: 64.0)
            appDel?.loader2.center = CGPoint(x: (appDel?.window?.frame.width)!/2.0, y: (appDel?.window?.frame.height)!/2.0)
            appDel?.loader2.clipsToBounds = true
            appDel?.window?.addSubview((appDel?.loader2)!)
            appDel?.loader2.animate(withGIFNamed: (appDel?.currentGIFName)!)
        }
    }
    
    func stopAnimate() {
        DispatchQueue.main.async {
            appDel?.loader.stopAnimatingGIF()
            appDel?.loader.isHidden = true
            appDel?.loader.prepareForReuse()
        }
    }
    
    func stopAnimateLoader2() {
        DispatchQueue.main.async {
            appDel?.loader2.stopAnimatingGIF()
            appDel?.loader2.isHidden = true
            appDel?.loader2.prepareForReuse()
        }
    }
    
    func addDashedBorder(myview: UIView) {
        //Create a CAShapeLayer
        let shapeLayer = CAShapeLayer()
        shapeLayer.strokeColor = theme_selected_color?.cgColor
        shapeLayer.lineWidth = 2
        // passing an array with the values [2,3] sets a dash pattern that alternates between a 2-user-space-unit-long painted segment and a 3-user-space-unit-long unpainted segment
        shapeLayer.lineDashPattern = [2]
        
        let path = CGMutablePath()
        path.addLines(between: [CGPoint(x: 0, y: myview.frame.height),CGPoint(x: myview.frame.width, y: myview.frame.height)])
        shapeLayer.path = path
        myview.layer.addSublayer(shapeLayer)
    }
    
    func setDashUnderline(title1:String, title2: String,fontName1:String,
                          fontSize1:Int,
                          fontColor1:UIColor) -> NSMutableAttributedString {
        
        let yourAttributes : [NSAttributedString.Key : Any] = [NSAttributedString.Key.foregroundColor: fontColor1, NSAttributedString.Key.font: UIFont.init(name: fontName1, size: CGFloat(fontSize1))!]
        
        let yourOtherAttributes : [NSAttributedString.Key : Any] = [NSAttributedString.Key(rawValue: NSAttributedString.Key.underlineStyle.rawValue): NSUnderlineStyle.single.rawValue]
        
        let partOne = NSMutableAttributedString(string: title1, attributes: yourAttributes)
        
        let partTwo = NSMutableAttributedString(string: title2, attributes: yourOtherAttributes)
        
        let combination = NSMutableAttributedString()
        
        combination.append(partOne)
        combination.append(partTwo)
        
        return combination
    }
    
    func LoadProgressList(day : Int, dateLabel : UIButton) -> Bool{
        let formatter = DateFormatter()
        if day == 0 {
            appDel?.selectedDate = getCurrentDate()
            
            formatter.dateFormat = "yyyy-MM-dd"
            let date = formatter.date(from: (appDel?.selectedDate)!)
            
            formatter.dateFormat = "EEE, MMM dd, yyyy"
            dateLabel.setTitle(formatter.string(from: date!), for: .normal)
            
            appDel?.progressListUrl = "pms/progressentry/WorkProgress/\(String(describing: (appDel?.userID)!))/" + (appDel?.selectedDate)!
            return true
        }
        else {
            formatter.dateFormat = "yyyy-MM-dd"
            let date = formatter.date(from: (appDel?.selectedDate)!)
            if date != nil {
                let newDate = date?.add(days: day)
                formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                
                let newStringdate = formatter.string(from: newDate!)
                let newDateString = formatter.date(from: newStringdate)
                
                formatter.dateFormat = "EEE, MMM dd, yyyy"
                dateLabel.setTitle(formatter.string(from: newDateString!), for: .normal)
                
                formatter.dateFormat = "yyyy-MM-dd"
                appDel?.selectedDate = formatter.string(from: newDateString!)
                
                appDel?.progressListUrl = "pms/progressentry/WorkProgress/\(String(describing: (appDel?.userID)!))/" + (appDel?.selectedDate)!
                return true
            }
            else {
                return false
            }
        }
    }
    
    
    //MARK: SET TOP LEVEL FOLDER ICON
    func setFolderIcon(folderID:Int,imageView: UIImageView) {
        switch folderID {
        case 2:
            imageView.image = #imageLiteral(resourceName: "starred")
            imageView.contentMode = .center
        case 19:
            imageView.image = UIImage.fontAwesomeIcon(name: .fileO, textColor: theme_selected_color!, size: CGSize(width: 30, height: 30))
            imageView.contentMode = .center
        case 20:
            imageView.image = UIImage.fontAwesomeIcon(name: .share, textColor: theme_selected_color!, size: CGSize(width: 30, height: 30))
            imageView.contentMode = .center
        case 6:
            imageView.image = UIImage.fontAwesomeIcon(name: .buildingO, textColor: theme_selected_color!, size: CGSize(width: 30, height: 30))
            imageView.contentMode = .center
        case 5:
            imageView.image = UIImage.fontAwesomeIcon(name: .user, textColor: theme_selected_color!, size: CGSize(width: 30, height: 30))
            imageView.contentMode = .center
        case 8:
            imageView.image = UIImage.fontAwesomeIcon(name: .file, textColor: theme_selected_color!, size: CGSize(width: 30, height: 30))
            imageView.contentMode = .center
        case 7:
            imageView.image = UIImage.fontAwesomeIcon(name: .tasks, textColor: theme_selected_color!, size: CGSize(width: 30, height: 30))
            imageView.contentMode = .center
        case 3:
            imageView.image = UIImage.fontAwesomeIcon(name: .lightbulbO, textColor: theme_selected_color!, size: CGSize(width: 30, height: 30))
            imageView.contentMode = .center
        case 18:
            imageView.image = UIImage.fontAwesomeIcon(name: .money, textColor: theme_selected_color!, size: CGSize(width: 30, height: 30))
            imageView.contentMode = .center
        case 21:
            imageView.image = UIImage.fontAwesomeIcon(name: .folderOpenO, textColor: theme_selected_color!, size: CGSize(width: 30, height: 30))
            imageView.contentMode = .center
        case 24:
            imageView.image = #imageLiteral(resourceName: "033-invoice-icon (3)")
            imageView.tintColor = theme_selected_color
            imageView.contentMode = .redraw
        
        case 25:
            imageView.image = UIImage.fontAwesomeIcon(name: .cogs, textColor: theme_selected_color!, size: CGSize(width: 30, height: 30))
            imageView.contentMode = .center
        default:
            imageView.image = #imageLiteral(resourceName: "FolderIcon")
            imageView.contentMode = .scaleAspectFit
        }
    }
    
    //MARK: SET FILEICONS
    func setFileIcon(fileName:String,imageView:UIImageView) {
        if (fileName.contains(".pdf")) {
            imageView.image = UIImage.fontAwesomeIcon(name: .filePdfO, textColor: Pdf_theme_color, size: CGSize(width: 30, height: 30))
        }
        else if (fileName.contains(".xls")) || (fileName.contains(".xlsx")) || (fileName.contains(".xlr")) {
            imageView.image = UIImage.fontAwesomeIcon(name: .fileExcelO, textColor: theme_color, size: CGSize(width: 30, height: 30))
        }
        else if (fileName.contains(".png")) || (fileName.contains(".PNG")) || (fileName.contains(".jpg")) || (fileName.contains(".jpeg")) || (fileName.contains(".bmp")) || (fileName.contains(".gif")) || (fileName.contains(".psd")) || (fileName.contains(".svg")) || (fileName.contains(".ico"))  || (fileName.contains(".heic")) {
            imageView.image = UIImage.fontAwesomeIcon(name: .filePictureO, textColor: Blue_theme_color, size: CGSize(width: 30, height: 30))
        }
        else if (fileName.contains(".pptx")) || (fileName.contains(".ppt")) || (fileName.contains(".pps")) {
            imageView.image = UIImage.fontAwesomeIcon(name: .filePowerpointO, textColor: PPT_theme_color, size: CGSize(width: 30, height: 30))
        }
        else if (fileName.contains(".doc")) || (fileName.contains(".docx")) || (fileName.contains(".dot")) || (fileName.contains(".dox")) || (fileName.contains(".dotm")) || (fileName.contains(".dotx"))  {
            imageView.image = UIImage.fontAwesomeIcon(name: .fileWordO, textColor: Blue_theme_color, size: CGSize(width: 30, height: 30))
        }
        else if (fileName.contains(".eml")) || (fileName.contains(".msg")) {
            imageView.image = UIImage.fontAwesomeIcon(name: .envelope, textColor: Blue_theme_color, size: CGSize(width: 30, height: 30))
        }
        else if (fileName.contains(".zip")) || (fileName.contains(".rar")) {
            imageView.image = UIImage.fontAwesomeIcon(name: .fileArchiveO, textColor: UIColor.black, size: CGSize(width: 30, height: 30))
        }
        else if (fileName.contains(".mp4")) || (fileName.contains(".mkv")) || (fileName.contains(".m4a")) || (fileName.contains(".flv")) || (fileName.contains(".3gp")) || (fileName.contains(".avi")) || (fileName.contains(".mpeg")) || (fileName.contains(".m4v")) || (fileName.contains(".ocg")) || (fileName.contains(".mov")) {
            imageView.image = UIImage.fontAwesomeIcon(name: .fileVideoO, textColor: UIColor.black, size: CGSize(width: 30, height: 30))
        }
        else if (fileName.contains(".mp3")) || (fileName.contains(".aac")) || (fileName.contains(".caf")) || (fileName.contains(".oga")) || (fileName.contains(".amr")){
            imageView.image = UIImage.fontAwesomeIcon(name: .fileAudioO, textColor: UIColor.black, size: CGSize(width: 30, height: 30))
        }
        else
        {
            imageView.image = UIImage.fontAwesomeIcon(name: .fileTextO, textColor: theme_color, size: CGSize(width: 30, height: 30))
        }
    }
    
    
    //MARK: Download file
    func downloadFile(fileid: Int, filename: String,sysfilename:String, vc: UIViewController){
        //vC = vc
        CommonFunctions().animate()
        let params = ["DocIds": [fileid] ,"DeviceToken" : appDel?.deviceUDID as Any] as [String : Any]
        
        // Create destination URL
        let fileManager = FileManager.default
        let paths = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("WIP_OTG")
        
        if !fileManager.fileExists(atPath: paths){
            try! fileManager.createDirectory(atPath: paths, withIntermediateDirectories: true, attributes: nil)
        }
        let documentDirectoryPath : String = paths//NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first
        
        // create the custom folder path
        //let imagesDirectoryPath = URL(string: documentDirectoryPath)?.appendingPathComponent(sysfilename.replacingOccurrences(of: " ", with: ""))
        let imagesDirectoryPath = URL(fileURLWithPath: documentDirectoryPath).appendingPathComponent(sysfilename.replacingOccurrences(of: " ", with: ""))
        
        if !fileManager.fileExists(atPath: (imagesDirectoryPath.path)) {
            print("Go to download")
            
            let destinationFileUrl = URL(fileURLWithPath: (imagesDirectoryPath.path))
            let fileURL = URL(string: baseUrl + "ecm/documents/download")
            let jsonData = try? JSONSerialization.data(withJSONObject: params)
            
            let sessionConfig = URLSessionConfiguration.default
            let session = URLSession(configuration: sessionConfig)
            var request = URLRequest(url: fileURL!)
            request.httpMethod = "POST"
            request.httpBody = jsonData
            request.addValue((appDel?.userObj.SessionId)!, forHTTPHeaderField:"SessionId")
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let task = session.downloadTask(with: request) { (tempLocalUrl, response, error) in
                if let tempLocalUrl = tempLocalUrl, error == nil {
                    // Successt
                    let statusCode = (response as? HTTPURLResponse)?.statusCode
                    print("Successfully downloaded. Status code: \(String(describing: statusCode))")
                    if statusCode == 200 {
                        do {
                            try FileManager.default.copyItem(at: tempLocalUrl, to: destinationFileUrl)
                            DispatchQueue.main.async {
                                CommonFunctions().stopAnimate()
                                self.checkFileFormat(filename: filename, sysfilename: sysfilename.lowercased(), destinationFileUrl: destinationFileUrl, vc: vc)
                            }
                        } catch (let writeError) {
                            DispatchQueue.main.async {
                                appDel?.window?.makeToast(msgSomethingWrong)
                                return
                            }
                            print("Error creating a file \(String(describing: destinationFileUrl)) : \(writeError)")
                        }
                    }
                    else if statusCode == 400 {
                        DispatchQueue.main.async {
                            CommonFunctions().stopAnimate()
                            appDel?.window?.makeToast(msgFileNotFound)
                        }
                        return
                    }
                    else if statusCode == internetErrorCode {
                        DispatchQueue.main.async {
                            CommonFunctions().stopAnimate()
                            appDel?.window?.makeToast(msgNoInternet)
                            return
                        }
                    }
                    else if statusCode == sessionTimeOutCode {
                        DispatchQueue.main.async {
                            appDel?.sessionOUT()
                            return
                        }
                    }
                    else {
                        DispatchQueue.main.async {
                            CommonFunctions().stopAnimate()
                            appDel?.window?.makeToast("File could not be downlaod. Please try later.")
                            print("Error took place while downloading a file. Error description: %@", error?.localizedDescription as Any)
                            return
                        }
                    }
                    
                } else {
                    DispatchQueue.main.async {
                        CommonFunctions().stopAnimate()
                        appDel?.window?.makeToast("File could not be downlaod. Please try later.")
                        print("Error took place while downloading a file. Error description: %@", error?.localizedDescription as Any)
                        return
                    }
                }
            }
            task.resume()
        }
        else {
            CommonFunctions().stopAnimate()
            let destinationFileUrl = URL(fileURLWithPath: (imagesDirectoryPath.path))
            self.checkFileFormat(filename: filename, sysfilename: sysfilename.lowercased(), destinationFileUrl: destinationFileUrl, vc: vc)
        }
    }
    
    //MARK: CHECK FILE FORMATE
    func checkFileFormat(filename: String, sysfilename: String, destinationFileUrl: URL, vc: UIViewController) {
        if (sysfilename.contains(".png")) || (sysfilename.contains(".PNG")) || (sysfilename.contains(".JPG")) || (sysfilename.contains(".JPEG")) || (sysfilename.contains(".jpg")) || (sysfilename.contains(".jpeg")) || (sysfilename.contains(".BMP")) || (sysfilename.contains(".gif")) || (sysfilename.contains(".psd")) || (sysfilename.contains(".tiff")) || (sysfilename.contains(".BMP")) || (sysfilename.contains(".ico")){
            //self.openImageFromPreview(imgURL: destinationFileUrl, vc: vc)
            let docVC : DocumentWebViewVC = (appDel?.ECMStoryBoard.instantiateViewController(withIdentifier: "DocumentWebViewVC") as? DocumentWebViewVC)!
            docVC.destinationFileUrl = destinationFileUrl
            docVC.strHeader = filename.uppercased()
            vc.navigationController?.pushViewController(docVC, animated: true)
            return
        }
        else if (sysfilename.contains(".webm")) || (sysfilename.contains(".mpg")) || (sysfilename.contains(".mp2")) || (sysfilename.contains(".mpeg")) || (sysfilename.contains(".mpe")) || (sysfilename.contains(".mpv")) || (sysfilename.contains(".ocg")) || (sysfilename.contains(".mp4")) || (sysfilename.contains(".m4v")) ||
            (sysfilename.contains(".mkv")) || (sysfilename.contains(".mov")) || (sysfilename.contains(".m4a")) || (sysfilename.contains(".caf")) || (sysfilename.contains(".oga")) || (sysfilename.contains(".flv")) || (sysfilename.contains(".3gp")) || (sysfilename.contains(".mp3")) || (sysfilename.contains(".aac")) || (sysfilename.contains(".amr")) || (sysfilename.contains(".avi")) || sysfilename.contains(".MP3") || (sysfilename.contains(".AAC")) || (sysfilename.contains(".MP4")) || (sysfilename.contains(".M4V")) || (sysfilename.contains(".MOV")) || (sysfilename.contains(".WAV")){
            
            if sysfilename.contains(".mp3") || (sysfilename.contains(".aac")) || (sysfilename.contains(".mp4")) || (sysfilename.contains(".m4v")) || (sysfilename.contains(".mov")) || (sysfilename.contains(".wav")) || sysfilename.contains(".MP3") || (sysfilename.contains(".AAC")) || (sysfilename.contains(".MP4")) || (sysfilename.contains(".M4V")) || (sysfilename.contains(".MOV")) || (sysfilename.contains(".WAV")){
                self.openVideoFromPreview(videoURL: destinationFileUrl, vc: vc)
            }
            else {
                appDel?.window?.makeToast(fileFormateNotSupport)
            }
        }
        else {
            //documentInteractionController.delegate = vC as? UIDocumentInteractionControllerDelegate
            //self.share(url: destinationFileUrl)
            
            let docVC : DocumentWebViewVC = (appDel?.ECMStoryBoard.instantiateViewController(withIdentifier: "DocumentWebViewVC") as? DocumentWebViewVC)!
            docVC.destinationFileUrl = destinationFileUrl
            docVC.strHeader = filename
            vc.navigationController?.pushViewController(docVC, animated: true)
            
        }
    }
    
    
    func share(url: URL) {
        documentInteractionController.url = url
        documentInteractionController.uti = url.typeIdentifier ?? "public.data, public.content"
        documentInteractionController.name = url.localizedName ?? url.lastPathComponent
        documentInteractionController.presentPreview(animated: true)
    }
    func openVideoFromPreview(videoURL : URL, vc: UIViewController){
        
        let player = AVPlayer(url: videoURL)
        
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        
        vc.present(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
        return
    }
    func openImageFromPreview(imgURL : URL, vc: UIViewController){
        selectedPhotoPath = imgURL
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "DocumentNotification"), object: imgURL.absoluteString)
    }
    
    func numberOfPhotos(in photoBrowser: MWPhotoBrowser!) -> UInt {
        return 1
    }
    func photoBrowser(_ photoBrowser: MWPhotoBrowser!, photoAt index: UInt) -> MWPhotoProtocol! {
        let photoObj = MWPhoto(url: selectedPhotoPath)
        return photoObj
    }
    func photoBrowser(_ photoBrowser: MWPhotoBrowser!, titleForPhotoAt index: UInt) -> String! {
        return "test"
    }
    
    
    //MARK: CREATE LEAD
    func attachDocumentsToLead(dic: NSDictionary, completion: @escaping (Bool) -> Void) {
        
        let manager = APIManager.apiManager
        manager.postDataWithBlankResponseOrErrorMsgFromUrl(url: "lead/attachdocuments", dic: dic) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion(true)
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                       appDel?.window?.makeToast(msgSomethingWrong)
                   }
                   CommonFunctions().stopAnimate()
                   completion(false)
               }
           }
       }
    }
    
    //MARK: CREATE PROJECT
    func attachDocumentsToProject(dic: NSDictionary, completion: @escaping (Bool) -> Void) {
        
        let manager = APIManager.apiManager
        manager.postDataWithBlankResponseOrErrorMsgFromUrl(url: "ecm/project/attachdocument", dic: dic) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion(true)
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                       appDel?.window?.makeToast(msgSomethingWrong)
                   }
                   CommonFunctions().stopAnimate()
                   completion(false)
               }
           }
       }
    }
    
    //MARK: CREATE TODO
    func ratingToLead(id:Int, dic: NSDictionary, completion: @escaping (Bool) -> Void) {
        
        let manager = APIManager.apiManager
        manager.postDataWithBlankResponseOrErrorMsgFromUrl(url: "lead/leadscore/\(String(id))", dic: dic) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion(true)
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                       appDel?.window?.makeToast(msgSomethingWrong)
                   }
                   CommonFunctions().stopAnimate()
                   completion(false)
               }
           }
       }
    }
    
    //MARK: UPLOAD ToDo DOCUMENT
       
    func uploadToDoDocument(docs: [DocumentUploadModel], completion: @escaping ([NSMutableDictionary]) -> Void) {
       CommonFunctions().animate()
        let parameters :[String:AnyObject] = [:]
        var uploadedDocArray = [NSMutableDictionary]()
        if docs.count >= 1 {
            for i in 0..<docs.count{
                let objDocument = docs[i]
                if i > 0{
                    RunLoop.current.run(until: Date.init(timeIntervalSinceNow: 2.0))
                }
                
                let manager =  AFHTTPSessionManager()
                
                manager.requestSerializer = AFHTTPRequestSerializer()
                manager.responseSerializer = AFHTTPResponseSerializer()
                
                let myUrl : String = baseUrl + "pms/task/document"
                if let strSession : String = appDel?.userObj.SessionId
                {
                    if strSession.count < 5 {
                        appDel?.window?.makeToast("Invalid credentials")
                        CommonFunctions().stopAnimate()
                        completion([])
                        return
                    }
                }
               
                manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
                manager.post(myUrl, parameters: parameters, constructingBodyWith: { (multipartData) in
                    
                    if (objDocument.dataOfDoc != nil) {
                        multipartData.appendPart(withFileData: objDocument.dataOfDoc as Data, name: objDocument.imageName, fileName: objDocument.imageName, mimeType: objDocument.mimeType)
                    }
                    
                }, progress: {(progress) in }, success: {(sessionDatatask , responseObject) in
                    let responseHeader = sessionDatatask.response as! HTTPURLResponse
                    print(responseHeader.statusCode)
                    
                    if (responseHeader.statusCode ==  200) {
                        
                        do {
                            let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as AnyObject
                            print ("responseDict====\(responseDict)")
                            if let arrayDic : NSArray = responseDict as? NSArray{
                                let nDict : NSMutableDictionary = (arrayDic[0] as! NSDictionary).mutableCopy() as! NSMutableDictionary
                                nDict.removeObject(forKey: "DocId")
                                uploadedDocArray.append(nDict)
                            }
                    
                            if uploadedDocArray.count == docs.count {
                                CommonFunctions().stopAnimate()
                                completion(uploadedDocArray)
                            }
                            // use jsonObject here
                        } catch {
                            
                            print("json error: \(error)")
                            DispatchQueue.main.async {
                                CommonFunctions().stopAnimate()
                                appDel?.window?.makeToast("Something went wrong")
                                completion([])
                            }
                        }
                    }
                    else{
                        DispatchQueue.main.async {
                            CommonFunctions().stopAnimate()
                            appDel?.window?.makeToast("Something went wrong")
                            completion([])
                        }
                    }
                    
                    
                }, failure: {(sessionDatatask , error) in
                    print("fail:\(error.localizedDescription)")
                    DispatchQueue.main.async {
                        CommonFunctions().stopAnimate()
                        appDel?.window?.makeToast("Something went wrong")
                        completion([])
                        
                    }
                    
                })
                
            }
        }
   }
   
    //MARK: CREATE TODO
    func attachDocumentsToToDo(dic: NSDictionary, completion: @escaping (Bool) -> Void) {
        
        let manager = APIManager.apiManager
        manager.postDataWithBlankResponseOrErrorMsgFromUrl(url: "todo", dic: dic) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    CommonFunctions().showAlert(msg: "To-Do created successfully")
                    completion(true)
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                       appDel?.window?.makeToast(msgSomethingWrong)
                   }
                   CommonFunctions().stopAnimate()
                   completion(false)
               }
           }
       }
    }
    
    //MARK: EDIT TODO
    func editToDo(todoID: Int, dic: [String:AnyObject], completion: @escaping (Bool) -> Void) {
       
       let manager = APIManager.apiManager
        manager.PutDatadicFromUrl(url: "todo/\(String(describing: todoID))", dic: dic) { (dataResponse, result) in
           
           if (result == APIResult.APISuccess) {
               DispatchQueue.main.async {
                   CommonFunctions().stopAnimate()
                   CommonFunctions().showAlert(msg: "To-Do edited successfully")
                   completion(true)
               }
           }
           else if (result == APIResult.APIError) {
               DispatchQueue.main.async {
                   if let resultDic : NSDictionary = dataResponse as? NSDictionary
                   {
                       CommonFunctions().showErrorMessage(resultDic: resultDic)
                   }
                   else {
                       appDel?.window?.makeToast(msgSomethingWrong)
                   }
                   CommonFunctions().stopAnimate()
                   completion(false)
               }
           }
       }
    }
    
    //MARK: ATTACH DOCUMENT TO EXISTING TODO
    func addDocumentsToToDo(dic: NSDictionary, completion: @escaping (Bool) -> Void) {
       CommonFunctions().animate()
       let manager = APIManager.apiManager
       manager.postDataWithBlankResponseOrErrorMsgFromUrl(url: "todo/todoDocuments", dic: dic) { (dataResponse, result) in
           
           if (result == APIResult.APISuccess) {
               DispatchQueue.main.async {
                   CommonFunctions().stopAnimate()
                   CommonFunctions().showAlert(msg: "Document upload successfully")
                   completion(true)
               }
           }
           else if (result == APIResult.APIError) {
               DispatchQueue.main.async {
                   if let resultDic : NSDictionary = dataResponse as? NSDictionary
                   {
                       CommonFunctions().showErrorMessage(resultDic: resultDic)
                   }
                   else {
                       appDel?.window?.makeToast(msgSomethingWrong)
                   }
                   CommonFunctions().stopAnimate()
                   completion(false)
               }
           }
       }
    }
    
    //MARK: UPLOAD TASK DOCUMENT
    
    func uploadTaskDocument(taskIds: [Int], docs: [DocumentUploadModel], completion: @escaping (Bool) -> Void) {
        CommonFunctions().animate()
        let parameters :[String:AnyObject] = [:]
        var uploadedDocArray = [NSMutableDictionary]()
        
        for i in 0..<docs.count{
            let objDocument = docs[i]
            if i > 0{
                RunLoop.current.run(until: Date.init(timeIntervalSinceNow: 2.0))
            }
            
            let manager =  AFHTTPSessionManager()
            
            manager.requestSerializer = AFHTTPRequestSerializer()
            manager.responseSerializer = AFHTTPResponseSerializer()
            
            let myUrl : String = baseUrl + "pms/task/document"
            if let strSession : String = appDel?.userObj.SessionId
            {
                if strSession.count < 5 {
                    appDel?.window?.makeToast("Invalid credentials")
                    CommonFunctions().stopAnimate()
                    completion(false)
                    return
                }
            }
           
            manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
            manager.post(myUrl, parameters: parameters, constructingBodyWith: { (multipartData) in
                
                if (objDocument.dataOfDoc != nil) {
                    multipartData.appendPart(withFileData: objDocument.dataOfDoc as Data, name: objDocument.imageName, fileName: objDocument.imageName + objDocument.strExtention, mimeType: objDocument.mimeType)
                }
                
            }, progress: {(progress) in }, success: {(sessionDatatask , responseObject) in
                let responseHeader = sessionDatatask.response as! HTTPURLResponse
                print(responseHeader.statusCode)
                
                if (responseHeader.statusCode ==  200) {
                    
                    do {
                        let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as AnyObject
                        print ("responseDict====\(responseDict)")
                        if let arrayDic : NSArray = responseDict as? NSArray{
                            let nDict : NSMutableDictionary = (arrayDic[0] as! NSDictionary).mutableCopy() as! NSMutableDictionary
                            nDict.removeObject(forKey: "DocId")
                            uploadedDocArray.append(nDict)
                        }
                
                        if i == docs.count - 1 {
                            self.attachDocumentsToTask(taskIds: taskIds, docs: uploadedDocArray) { (isCompleted) in
                                if isCompleted {
                                    completion(true)
                                }
                                else {
                                    completion(false)
                                }
                            }
                        }
                        // use jsonObject here
                    } catch {
                        
                        print("json error: \(error)")
                        DispatchQueue.main.async {
                            CommonFunctions().stopAnimate()
                            appDel?.window?.makeToast("Something went wrong")
                            completion(false)
                        }
                    }
                }
                else{
                    DispatchQueue.main.async {
                        CommonFunctions().stopAnimate()
                        appDel?.window?.makeToast("Something went wrong")
                        completion(false)
                    }
                }
                
                
            }, failure: {(sessionDatatask , error) in
                print("fail:\(error.localizedDescription)")
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast("Something went wrong")
                    completion(false)
                    
                }
                
            })
            
        }
    }
    
    //MARK: ATTACH DOCUMENT TO EXISTING TASK
    func attachDocumentsToTask(taskIds: [Int], docs: [NSMutableDictionary], completion: @escaping (Bool) -> Void) {
        
        let parameters : NSDictionary = ["TaskIds": taskIds as Any,"UploadedFiles" : docs as Any]
        
        let manager = APIManager.apiManager
        manager.postDataWithBlankResponseOrErrorMsgFromUrl(url: "pms/tasks/documents", dic: parameters as NSDictionary) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    CommonFunctions().showAlert(msg: "Documents attached successfully")
                    completion(true)
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    CommonFunctions().stopAnimate()
                    completion(false)
                }
            }
        }
    }
    
    
    //MARK: ATTACH ACTION TO TODO
    func attachAtionToTask(IDs: [Int], todoID: Int, actionID: Int, completion: @escaping (Bool) -> Void) {
        CommonFunctions().animate()
        let parameters : NSDictionary = ["ToDoId": todoID as Any,"EntityTypeId" : actionID as Any, "EntiyIds":IDs as Any]
        
        let manager = APIManager.apiManager
        manager.postDataWithBlankResponseOrErrorMsgFromUrl(url: "todo/todoEntity", dic: parameters as NSDictionary) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion(true)
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    CommonFunctions().stopAnimate()
                    completion(false)
                }
            }
        }
    }
    
    //MARK: check login
    func CheckIsLogin() -> Bool {
        var islogin = false
        if let sesionStr : String = UserDefaults.standard.object(forKey: sessionToken) as? String{
            if sesionStr.count > 10{
                if let nsdata = UserDefaults.standard.object(forKey: userData){
                    if let userDataInfo = NSKeyedUnarchiver.unarchiveObject(with: nsdata as! Data) as? [String : AnyObject]{
                        let userObjt = User()
                        userObjt.setAttributeInfo(json: userDataInfo)
                        appDel?.userObj = userObjt
                        if appDel?.userObj != nil {
                            islogin = true
                        }
                    }
                }
            }
        }
        return islogin
    }
    
    //MARK: SHOW ERROR MESSAGE DICTIONARY
    func showErrorMessage(resultDic: NSDictionary) {
        print(resultDic)
        if resultDic.count == 1 {
            if let msg = resultDic.object(forKey: "Message") {
                if let str : String = msg as? String {
                    appDel?.window?.makeToast(str)
                } else {
                    print("value is nil")
                }
            }
        }
        else {
            if let modelStateDic = resultDic.object(forKey: "ModelState") {
                if let modelStateDictionary : NSDictionary = modelStateDic as? NSDictionary {
                    for i in 0..<modelStateDictionary.allKeys.count {
                        let key : String = modelStateDictionary.allKeys[i] as! String
                        if let msg = modelStateDictionary.object(forKey: key) {
                            if let str : NSArray = msg as? NSArray {
                                appDel?.window?.makeToast(str[0] as? String)
                            } else {
                                print("value is nil")
                            }
                        }
                    }
                }
            }
        }
    }
    
    //MARK: ALERT BOX
    func showAlert(msg: String) {
        let dialog = ZAlertView(title: Bundle.main.displayName, message: msg, closeButtonText: "OK", closeButtonHandler: { (alertView) -> () in
            alertView.dismissAlertView()
        }
        )
        dialog.show()
        dialog.allowTouchOutsideToDismiss = false
    }
    
    //MARK: ALERT BOX
    func showAlertList(title:String, msg: String) {
        let dialog = ZAlertView(title: title, message: msg, closeButtonText: "OK", closeButtonHandler: { (alertView) -> () in
            alertView.dismissAlertView()
        }
        )
        dialog.show()
        dialog.allowTouchOutsideToDismiss = false
    }
    
    func showThemeAlert(msgTitle:String, msg: String, completion: @escaping (Bool) -> Void) {
        
        ZAlertView.positiveColor = UIColor(red:0.09, green:0.47, blue:0.24, alpha:1.0)
        let dialog = ZAlertView(title: msgTitle,
                                message: msg,
                                isOkButtonLeft: true,
                                okButtonText: "Yes",
                                cancelButtonText: "No",
                                okButtonHandler: { (alertView) -> () in
                                    alertView.dismissAlertView()
                                    completion(true)
                                },
                                cancelButtonHandler: { (alertView) -> () in
                                    alertView.dismissAlertView()
                                    completion(false)
                                }
        )
        dialog.show()
        dialog.allowTouchOutsideToDismiss = true
    }
    
    //MARK: SHOW DISPATCH MESSAGE
    func showDispatchMessage(msg: String) {
        DispatchQueue.main.async {
            appDel?.window?.makeToast(msg)
        }
    }
    
    //MARK: SET PREFERENCE
    func setPreference() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(appDel?.userPreferenceObj) {
            let defaults = UserDefaults.standard
            defaults.set(encoded, forKey: userDataPreference)
        }
    }
    
    //MARK: PARSE PREFERENCE
    func parsePreference() {
        let defaults = UserDefaults.standard
        if let savedPerson = defaults.object(forKey: userDataPreference) as? Data {
            let decoder = JSONDecoder()
            if let loadedPerson = try? decoder.decode(UserPreferences.self, from: savedPerson) {
                print(loadedPerson.cONTACTNAME)
                appDel?.userPreferenceObj = loadedPerson
                print(appDel?.userPreferenceObj.cONTACTNAME as Any)
            }
        }
    }
    
    //MARK: APPLY THEME
    func applyTheme(themeCode: String) {
        
        for i in 0..<colors.count {
            let themecolorcode = colors[i]
            if themecolorcode == themeCode {
                UserDefaults.standard.set(themeCode, forKey: theme)
                break
            }
        }
    }
    
    //MARK: LOGOUT
    func logoutMe() {
        ZAlertView.positiveColor = UIColor(red:0.09, green:0.47, blue:0.24, alpha:1.0)
        let dialog = ZAlertView(title: "Alert",
                                message: "Are you sure you want to logout?",
                                isOkButtonLeft: true,
                                okButtonText: "Yes",
                                cancelButtonText: "No",
                                okButtonHandler: { (alertView) -> () in
                                    alertView.dismissAlertView()
                                    appDel?.userPreferenceObj.iSSESSIONEXPIRED = false
                                    self.clearUserData()
                                    
        },
                                cancelButtonHandler: { (alertView) -> () in
                                    alertView.dismissAlertView()
        }
        )
        dialog.show()
        dialog.allowTouchOutsideToDismiss = true
    }
    
    func deleteDocumentDirectory(){
        let fileManager = FileManager.default
        let paths = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("WIP_OTG")
        
        if fileManager.fileExists(atPath: paths){
            try! fileManager.removeItem(atPath: paths)
        }else{
            print("Already dictionary created.")
        }
    }
    
    func clearWorkboardData() {
        appDel?.selectedTabIndex = -1
        appDel?.objWorkboard = Workboard(JSON: [:])
        appDel?.AllobjWorkboard = Workboard(JSON: [:])
        appDel?.allArrayIdleResources?.removeAll()
        appDel?.arrayUsersOnLeave?.removeAll()
        appDel?.AllarrayUsersOnLeave?.removeAll()
        appDel?.lastContentOffset = CGPoint(x: 0, y: 0)
    }
    
    func clearTaskboardData() {
        appDel?.progressListUrl = ""
        appDel?.selectedDate = ""
        appDel?.objActiveUser = nil
        appDel?.objActiveTask = MyTaskModel(JSON: [:])
        appDel?.objActiveUserTaskProgress = ProgressListModel(JSON: [:])
        appDel?.ALLObjActiveUserTaskProgress = ProgressListModel(JSON: [:])
        appDel?.userID = 0
    }
    
    func clearUserData() {
        var testURL = ""
        if let baseurl : String = UserDefaults.standard.object(forKey: EnterPriseURL) as? String{
            testURL = baseurl
        }
        var userName = ""
        if let userNameStr : String = UserDefaults.standard.object(forKey: loginUserName) as? String{
            userName = userNameStr
        }
        var Password = ""
        if let PasswordStr : String = UserDefaults.standard.object(forKey: loginPassword) as? String{
            Password = PasswordStr
        }
        
        var defaultTheme = ""
        var defaultThemeAllColor = ""
        if let selectedTheme : String = UserDefaults.standard.object(forKey: themeBorder) as? String {
            defaultTheme = selectedTheme
        }
        if let selectedTheme : String = UserDefaults.standard.object(forKey: theme) as? String {
            defaultThemeAllColor = selectedTheme
        }
        self.deleteDocumentDirectory()
        self.clearTaskboardData()
        self.clearWorkboardData()
        appDel?.taskIDArray.removeAllObjects()
        appDel?.selectedProjectId = 0
        UserDefaults.standard.set("", forKey: "timesheetDate")
        UserDefaults.standard.set(false, forKey: "fromResource")
        UserDefaults.standard.set(false, forKey: "FromRecentPE")
        UserDefaults.standard.set(false, forKey: "fromECM")
        UserDefaults.standard.set(false, forKey: "fromMyTask")
        UserDefaults.standard.set(nil, forKey: "DocArray")
        UserDefaults.standard.set(false, forKey: "FromTicket")
        UserDefaults.standard.set(nil, forKey: "timesheetWorkHrs")
        appDel?.summaryDic = nil
        appDel?.attachedPEDocument.removeAll()
        appDel?.selectedFolderName = ""
        appDel?.selectedFolderID = 0
        appDel?.docURL = URL(string: "")
        appDel?.selectedFolders.removeAll()
        UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
        UserDefaults.standard.synchronize()
        let shareExtension = UserDefaults.init(suiteName: "group.com.workInProgress.WIP")
        shareExtension?.removePersistentDomain(forName: "group.com.workInProgress.WIP")
        shareExtension?.synchronize()
        UserDefaults.standard.set(testURL, forKey: EnterPriseURL)
        
        if Password.count != 0 && userName.count != 0{
            UserDefaults.standard.set(userName, forKey: loginUserName)
            UserDefaults.standard.set(Password, forKey: loginPassword)
        }
        
        self.parsePreference()
        self.setPreference()
        
        if (appDel?.userPreferenceObj.iSSESSIONEXPIRED)! {
            appDel?.selectedThemeColorHex = ""
            UserDefaults.standard.set("", forKey: theme)
            UserDefaults.standard.set("", forKey: themeBorder)
            theme_selected_color = UIColor()
            self.openCredentialController()
        }
        else {
            appDel?.docDic = nil
            appDel?.selectedOption = nil
            appDel?.sharedUrl = nil
            self.openCredentialController()
            theme_selected_color = UIColor.color(defaultTheme)
            UserDefaults.standard.set(defaultThemeAllColor, forKey: theme)
            UserDefaults.standard.set(defaultTheme, forKey: themeBorder)
        }
    }
    
    func openCredentialController() {
        if (appDel?.userPreferenceObj.iSTOUCHIDON)! {
            let loginVc = appDel?.mainStoryBoard.instantiateViewController(withIdentifier: "LoginTouchVC") as? LoginTouchVC
            appDel?.window?.rootViewController = loginVc
            appDel?.window?.makeKeyAndVisible();
            return
        }
        else {
            let loginVc = appDel?.mainStoryBoard.instantiateViewController(withIdentifier: "WIPLoginVC") as? WIPLoginVC
            appDel?.window?.rootViewController = loginVc
            appDel?.window?.makeKeyAndVisible();
            return
        }
    }
    
    //MARK: EMAIL VALIDATION
    func validateEmail(enteredEmail:String) -> Bool {
        
        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        return emailPredicate.evaluate(with: enteredEmail)
        
    }
    
    //MARK: Header title with counts
    func getHeader(title:String,count:String) -> NSMutableAttributedString {
        
        let partOne = NSMutableAttributedString(string: title, attributes: convertToOptionalNSAttributedStringKeyDictionary(yourAttributes as [String : Any]))
        
        let partTwo = NSMutableAttributedString(string: " (" + count + ")", attributes: convertToOptionalNSAttributedStringKeyDictionary(yourOtherAttributes as [String : Any]))
        
        let combination = NSMutableAttributedString()
        
        combination.append(partOne)
        combination.append(partTwo)
        
        return combination
    }
    
    func setDashUnderline(title:String) -> NSMutableAttributedString {
        
        let attrs : [String: Any] = [convertFromNSAttributedStringKey(NSAttributedString.Key.underlineStyle): NSUnderlineStyle.patternDash.rawValue]
        let partOne = NSMutableAttributedString(string: title, attributes: convertToOptionalNSAttributedStringKeyDictionary(attrs))
        
        let combination = NSMutableAttributedString()
        combination.append(partOne)
        
        return combination
    }
    
    //MARK: SEARCHBAR TRANSPARENT
    func setSearchbar(searchbar : UISearchBar) {
        searchbar.placeholder = "Search Task.."
        searchbar.searchTextPositionAdjustment = UIOffset(horizontal: 5, vertical: 0)
        let textFieldInsideSearchBar = searchbar.value(forKey: "searchField") as? UITextField
        
        textFieldInsideSearchBar?.layer.sublayerTransform = CATransform3DMakeTranslation(4, 0, 0)
        textFieldInsideSearchBar?.borderStyle = .none
        textFieldInsideSearchBar?.borderColor = theme_selected_color!
        textFieldInsideSearchBar?.borderWidth = 0.50
        textFieldInsideSearchBar?.cornerRadius = 6
        textFieldInsideSearchBar?.layer.cornerRadius = 6
        textFieldInsideSearchBar?.layer.masksToBounds = true
        textFieldInsideSearchBar?.textColor = UIColor.black
        textFieldInsideSearchBar?.font = UIFont(name: "Gotham-Book", size: 12.0)
        textFieldInsideSearchBar?.backgroundColor = UIColor.white
    }
    
    //MARK: Header title with counts
    func getCustomHeader(title1:String,title2:String,fontName1:String,fontName2:String,fontSize1:Int,fontSize2:Int,fontColor1:UIColor,fontColor2:UIColor) -> NSMutableAttributedString {
        
        let yourAttributes : [String : Any] = [convertFromNSAttributedStringKey(NSAttributedString.Key.foregroundColor): fontColor1, convertFromNSAttributedStringKey(NSAttributedString.Key.font): UIFont.init(name: fontName1, size: CGFloat(fontSize1))!]
        
        let yourOtherAttributes : [String : Any] = [convertFromNSAttributedStringKey(NSAttributedString.Key.foregroundColor): fontColor2, convertFromNSAttributedStringKey(NSAttributedString.Key.font): UIFont.init(name: fontName2, size: CGFloat(fontSize2))!]
        
        let partOne = NSMutableAttributedString(string: title1, attributes: convertToOptionalNSAttributedStringKeyDictionary(yourAttributes as [String : Any]))
        
        let partTwo = NSMutableAttributedString(string: title2, attributes: convertToOptionalNSAttributedStringKeyDictionary(yourOtherAttributes as [String : Any]))
        
        let combination = NSMutableAttributedString()
        
        combination.append(partOne)
        combination.append(partTwo)
        
        return combination
    }
    
    
    func getcontactcount(addressbooktype: String, term: String, completion: @escaping (Bool,Int) -> Void) {
        let parameters :[String:AnyObject] = ["SearchTerm": term as AnyObject]
        let manager = APIManager.apiManager
        CommonFunctions().animate()
        manager.PostDataAndGetData(url: "addressbook/diarypage/\(addressbooktype)/counts", dic: parameters as NSDictionary) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultArray : NSArray = dataResponse as? NSArray {
                        if resultArray.count > 0 {
                            if let resultDic : NSDictionary = resultArray[0] as? NSDictionary
                            {
                                if let count = resultDic.object(forKey: "AddressBookCount") as? Int {
                                    completion(true,count)
                                }
                                else {
                                    completion(false,0)
                                }
                            }
                            else {
                                completion(false,0)
                            }
                        }
                        else {
                            completion(false,0)
                        }
                    }
                    else {
                        completion(false,0)
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast(msgSomethingWrong)
                }
            }
        }
    }
    
    //MARK: LEAD SALES ACCOUNT
    func getSalesAccountList(completion: @escaping ([LeadAccount]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "lead/leadAccount", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let tasks = Mapper<LeadAccount>().mapArray(JSONObject: taskArray) ?? []
                    
                    if tasks.count > 0 {
                        DispatchQueue.main.async {
                            completion(tasks)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: DEFAULT LEAD SALES ACCOUNT
    func getDefaultSalesAccount(completion: @escaping (Int) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "lead/defaultsalesaccount", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                if let taskdic : NSDictionary = dataResponse as? NSDictionary
                {
                    if let id = taskdic.object(forKey: "defaultSalesAccountId") as? Int {
                        completion(id)
                    }
                    else {
                        completion(0)
                    }
                }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion(0)
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion(0)
                }
            }
        }
    }
    
    //MARK: LEAD SALES ACCOUNT
    func getCompanyList(completion: @escaping ([ProjectTeam]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "lead/allcompanies/3", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let tasks = Mapper<ProjectTeam>().mapArray(JSONObject: taskArray) ?? []
                    
                    if tasks.count > 0 {
                        DispatchQueue.main.async {
                            completion(tasks)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: LEAD SALES ACCOUNT
    func getContactList(id:String, completion: @escaping ([ProjectTeam]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "lead/company/\(id)/contacts", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let tasks = Mapper<ProjectTeam>().mapArray(JSONObject: taskArray) ?? []
                    
                    if tasks.count > 0 {
                        DispatchQueue.main.async {
                            completion(tasks)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: LEAD SALES ACCOUNT
       func getLeadServiceList(id:String, completion: @escaping ([ProjectTeam]) -> Void) {
           CommonFunctions().animate()
           
           let parameters :[String:AnyObject] = [:]
           //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
           let manager = APIManager.apiManager
           manager.getDatadicFromUrl(url: "lead/leadProductService/\(id)", dic: parameters ) { (dataResponse, result) in
               if (result == APIResult.APISuccess) {
                   DispatchQueue.main.async {
                       CommonFunctions().stopAnimate()
                   }
                   if let taskArray : NSArray = dataResponse as? NSArray
                   {
                       let tasks = Mapper<ProjectTeam>().mapArray(JSONObject: taskArray) ?? []
                       
                       if tasks.count > 0 {
                           DispatchQueue.main.async {
                               completion(tasks)
                           }
                       }
                       else  {
                           DispatchQueue.main.async {
                               completion([])
                           }
                       }
                   }
               }
               else if (result == APIResult.APIError){
                   DispatchQueue.main.async {
                       CommonFunctions().stopAnimate()
                       completion([])
                   }
               }
               else {
                   DispatchQueue.main.async {
                       CommonFunctions().stopAnimate()
                       completion([])
                   }
               }
           }
       }
    
    //MARK: LEAD SALES ACCOUNT
    func getLeadOwnerList(completion: @escaping ([ProjectTeam]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "lead/leadOwner", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let tasks = Mapper<ProjectTeam>().mapArray(JSONObject: taskArray) ?? []
                    
                    if tasks.count > 0 {
                        DispatchQueue.main.async {
                            completion(tasks)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: GET TODO DATA
    func getActivityData(activityId: String, completion: @escaping (ActivityDataModel?) -> Void) {
        CommonFunctions().animate()
        let parameters :[String:AnyObject] = [:]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "360i/activity/\(activityId)", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultDic : [String : Any] = dataResponse as? [String : Any]
                    {
                        let todo = Mapper<ActivityDataModel>().map(JSON: resultDic)
                        completion(todo)
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion(nil)
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion(nil)
                }
            }
        }
    }
    
    //MARK: GET Opportunity activity
    func getOpportunityData(activityId: String, completion: @escaping ([OpenActivity]) -> Void) {
        CommonFunctions().animate()
        let parameters :[String:AnyObject] = [:]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "360i/opportunityActivities/\(activityId)", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let taskArray : NSArray = dataResponse as? NSArray
                    {
                        let tasks = Mapper<OpenActivity>().mapArray(JSONObject: taskArray) ?? []
                        
                        if tasks.count > 0 {
                            DispatchQueue.main.async {
                                completion(tasks)
                            }
                        }
                        else  {
                            DispatchQueue.main.async {
                                completion([])
                            }
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion([])
                }
            }
        }
    }
    
    //MARK: GET Opportunity leads
    func getOpportunityleadData(activityId: String, completion: @escaping ([LeadList]) -> Void) {
        CommonFunctions().animate()
        let parameters :[String:AnyObject] = [:]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "360i/opportunityLeads/\(activityId)", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let taskArray : NSArray = dataResponse as? NSArray
                    {
                        let tasks = Mapper<LeadList>().mapArray(JSONObject: taskArray) ?? []
                        
                        if tasks.count > 0 {
                            DispatchQueue.main.async {
                                completion(tasks)
                            }
                        }
                        else  {
                            DispatchQueue.main.async {
                                completion([])
                            }
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion([])
                }
            }
        }
    }
    
    //MARK: GET TODO DATA
    func getLeadData(activityId: String, completion: @escaping (LeadDetailModel?) -> Void){
        CommonFunctions().animate()
        let parameters :[String:AnyObject] = [:]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "360i/lead/\(activityId)", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultDic : [String : Any] = dataResponse as? [String : Any]
                    {
                        let todo = Mapper<LeadDetailModel>().map(JSON: resultDic)
                        completion(todo)
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion(nil)
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion(nil)
                }
            }
        }
    }
    
    //MARK: GET Opportunity Detail DATA
    func getOpportunityData(OpportunityId: String, completion: @escaping (OpportunityDetailModel?) -> Void){
        CommonFunctions().animate()
        let parameters :[String:AnyObject] = [:]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "360i/opportunity/\(OpportunityId)", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultDic : [String : Any] = dataResponse as? [String : Any]
                    {
                        let todo = Mapper<OpportunityDetailModel>().map(JSON: resultDic)
                        completion(todo)
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion(nil)
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion(nil)
                }
            }
        }
    }
    
    //MARK: GET TODO LIST DATA
    func getToDoListData(TypeId: String, Status: String, completion: @escaping (ToDoModel?) -> Void) {
        CommonFunctions().animate()
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "todo/myAndAllToDoList/\(TypeId)/\(Status)", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultDic : [String : Any] = dataResponse as? [String : Any]
                    {
                        let todo = Mapper<ToDoModel>().map(JSON: resultDic)
                        completion(todo)
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion(nil)
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion(nil)
                }
            }
        }
    }
    
    //MARK: GET TODO DATA
    func getToDoData(todoId: String, completion: @escaping (TodoDetailModel?) -> Void) {
        CommonFunctions().animate()
        let parameters :[String:AnyObject] = [:]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "todo/\(todoId)", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultDic : [String : Any] = dataResponse as? [String : Any]
                    {
                        let todo = Mapper<TodoDetailModel>().map(JSON: resultDic)
                        completion(todo)
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion(nil)
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    completion(nil)
                }
            }
        }
    }
    
    //MARK: TODO DOCUMENT LISTING
    func getTodoDocsList(todoID: Int,completion: @escaping ([ECMLinkedDoc]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "todo/todoDocuments/\(todoID)", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskdic : NSDictionary = dataResponse as? NSDictionary
                {
                    if let taskArray : NSArray = taskdic.object(forKey: "DTOECMToDoDocuments") as? NSArray
                    {
                        let docs = Mapper<ECMLinkedDoc>().mapArray(JSONObject: taskArray) ?? []
                        
                        if docs.count > 0 {
                            DispatchQueue.main.async {
                                completion(docs)
                            }
                        }
                        else  {
                            DispatchQueue.main.async {
                                completion([])
                            }
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: TODO TASKS LISTING
    func getTodoTasksList(todoID: Int,completion: @escaping ([QueueTaskModel]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "todo/todoTasks/\(String(describing: todoID))", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let tasks = Mapper<QueueTaskModel>().mapArray(JSONObject: taskArray) ?? []
                    
                    if tasks.count > 0 {
                        DispatchQueue.main.async {
                            completion(tasks)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: TODO ACTIVITY LISTING
    func getTodoActivityList(todoID: Int,completion: @escaping ([QueueTaskModel]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "todo/todoActivities/\(String(describing: todoID))", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let tasks = Mapper<QueueTaskModel>().mapArray(JSONObject: taskArray) ?? []
                    
                    if tasks.count > 0 {
                        DispatchQueue.main.async {
                            completion(tasks)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: TODO TICKETS LISTING
    func getTodoTicketsList(todoID: Int,completion: @escaping ([QueueTypeDetailModel]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "todo/todoTickets/\(String(describing: todoID))", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let tasks = Mapper<QueueTypeDetailModel>().mapArray(JSONObject: taskArray) ?? []
                    
                    if tasks.count > 0 {
                        DispatchQueue.main.async {
                            completion(tasks)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    
    //MARK: CONTACT/COMPANY FOR ACTIVITY
    func getCONTACTCOMPANYList(completion: @escaping ([ProjectTeam],[ProjectTeam]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "pms/task/group/true", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskdic : NSDictionary = dataResponse as? NSDictionary
                {   var teamArray = [ProjectTeam]()
                    var companyArray = [ProjectTeam]()
                    
                    if let taskArray : NSArray = taskdic.object(forKey: "COMPANY") as? NSArray
                    {
                        companyArray = Mapper<ProjectTeam>().mapArray(JSONObject: taskArray) ?? []
                        
                    }
                    if let taskArray : NSArray = taskdic.object(forKey: "CONTACTS") as? NSArray
                    {
                        teamArray = Mapper<ProjectTeam>().mapArray(JSONObject: taskArray) ?? []
                        
                    }
                    
                    DispatchQueue.main.async {
                        completion(companyArray,teamArray)
                    }
                    
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([],[])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([],[])
                }
            }
        }
    }
    
    //MARK: TODO DOCUMENT LISTING
    func getOpportunityDocsList(oppID: Int,completion: @escaping ([ECMDocumentModel]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "360i/opportunityDocuments/\(oppID)", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                
                    if let taskArray : NSArray = dataResponse as? NSArray
                    {
                        let tasks = Mapper<ECMDocumentModel>().mapArray(JSONObject: taskArray) ?? []
                        
                        if tasks.count > 0 {
                            DispatchQueue.main.async {
                                completion(tasks)
                            }
                        }
                        else  {
                            DispatchQueue.main.async {
                                completion([])
                            }
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: LEAD LISTING
    func getLeadsList(compID: Int,completion: @escaping ([LeadListModel]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "lead/company/\(String(describing: compID))/leads", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let tasks = Mapper<LeadListModel>().mapArray(JSONObject: taskArray) ?? []
                    
                    if tasks.count > 0 {
                        DispatchQueue.main.async {
                            completion(tasks)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: OPPORTUNITY LISTING
    func getOpportunityList(compID: Int,completion: @escaping ([OpportunityProject]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "pms/company/\(String(describing: compID))/opportunities", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let tasks = Mapper<OpportunityProject>().mapArray(JSONObject: taskArray) ?? []
                    
                    if tasks.count > 0 {
                        DispatchQueue.main.async {
                            completion(tasks)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: REASON TYPE LISTING
    func getReasonTypeList(completion: @escaping ([ReasonTypeModel]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "pms/reasontype", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let tasks = Mapper<ReasonTypeModel>().mapArray(JSONObject: taskArray) ?? []
                    
                    if tasks.count > 0 {
                        DispatchQueue.main.async {
                            completion(tasks)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: STATUS LISTING
    func getLeadStatusList(leadID: String, completion: @escaping ([LeadStatusModel]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "lead/status", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let tasks = Mapper<LeadStatusModel>().mapArray(JSONObject: taskArray) ?? []
                    
                    if tasks.count > 0 {
                        DispatchQueue.main.async {
                            completion(tasks)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: STATUS LISTING
    func getOpportunityList(type: String, order: String, completion: @escaping ([OpportunityList]) -> Void) {
           CommonFunctions().animate()
           
        let parameters :[String:AnyObject] = [:]
           //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "360i/opportunities/\(type)/\(order)", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let tasks = Mapper<OpportunityList>().mapArray(JSONObject: taskArray) ?? []
                       
                    if tasks.count > 0 {
                        DispatchQueue.main.async {
                            completion(tasks)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    
    //MARK: POST CONTACT
    func postNewConstact(contctSyncArr: [NSMutableDictionary],completion: @escaping (Bool) -> Void) {
        let parameters  : NSDictionary = ["Entries" : contctSyncArr]
        let manager = APIManager.apiManager
        manager.postDataWithBlankResponseOrErrorMsgFromUrl(url: "addressbook/diarypage/sync", dic: parameters as NSDictionary) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimateLoader2()
                    completion(true)
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimateLoader2()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    completion(false)
                }
            }
        }
    }
    
    
    //MARK: GET PAGE NUMBER
    func getPageNumber(pagesize: String, folderid: String, docid: String, completion: @escaping (String) -> Void) {
        let parameters :[String:AnyObject] = [:]
        let manager = APIManager.apiManager
        CommonFunctions().animate()
        manager.getReviseTaskFromUrl(url: "ecm/folder/\(folderid)/document/\(docid)/pagesize/\(pagesize)", dic: parameters as NSDictionary, type: "GET") { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        if let desc = resultDic.object(forKey: "PAGE_NO") as? Int {
                            completion(String(describing: (desc)))
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast(msgSomethingWrong)
                }
            }
        }
    }
    
    //MARK: GET TASK DESCRIPTION
    func getDescription(taskid: String, completion: @escaping (String) -> Void) {
        let parameters :[String:AnyObject] = [:]
        let manager = APIManager.apiManager
        CommonFunctions().animate()
        manager.getReviseTaskFromUrl(url: "pms/progressentry/task/\((taskid))/description", dic: parameters as NSDictionary, type: "GET") { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        if let desc = resultDic.object(forKey: "TaskDescription") as? String {
                            completion(desc)
                        }
                        else {
                            completion("")
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast(msgSomethingWrong)
                }
            }
        }
    }
    
    
    //MARK: POST TASK DESCRIPTION
    func postDescription(taskid: String, description: String, completion: @escaping (Bool) -> Void) {
        let parameters  : NSDictionary = ["TASK_DESCRIPTION": description as Any]
        let manager = APIManager.apiManager
        CommonFunctions().animate()
        manager.postDataWithBlankResponseOrErrorMsgFromUrl(url: "pms/progressentry/task/\((taskid))/description", dic: parameters as NSDictionary) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion(true)
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    completion(false)
                }
            }
        }
    }
    
    //MARK: PUT TODO STATUS CHANGE
    func changeTodoSatus(todoid: String, statusType: String, completion: @escaping (Bool) -> Void) {
        let parameters :[String:AnyObject] = [:]
        let manager = APIManager.apiManager
        CommonFunctions().animate()
        manager.PutDatadicFromUrl(url: "todo/\(statusType)/\(todoid)", dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion(true)
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    completion(false)
                }
            }
        }
    }
    
    func getCases(parameters : NSDictionary, completion: @escaping ([CaseSummaryModel]) -> Void) {
        CommonFunctions().animate()
        let manager = APIManager.apiManager
        manager.PostDataAndGetData(url: "search/cases", dic: parameters as NSDictionary) { (dataResponse, result) in

            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let casearray : NSArray = dataResponse as? NSArray {
                        let caseArray = Mapper<CaseSummaryModel>().mapArray(JSONObject: casearray) ?? []
                        completion(caseArray)
                    }
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimateLoader2()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    completion([])
                }
            }
        }
    }
    
    func projectValidation(parameters : NSDictionary, completion: @escaping (Bool,Bool) -> Void) {
        CommonFunctions().animate()
        let manager = APIManager.apiManager
        manager.PostDataAndGetData(url: "pms/task/validations/enddate/reduction", dic: parameters as NSDictionary) { (dataResponse, result) in

            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let casearray : Bool = dataResponse as? Bool {
                        completion(casearray, true)
                    }
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimateLoader2()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    completion(false, false)
                }
            }
        }
    }
    
    func sprintValidation(parameters : NSDictionary, completion: @escaping (NSDictionary) -> Void) {
        CommonFunctions().animate()
        let manager = APIManager.apiManager
        manager.PostDataAndGetData(url: "pms/task/validations/enddate/extension", dic: parameters as NSDictionary) { (dataResponse, result) in

            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let casearray : NSDictionary = dataResponse as? NSDictionary {
                        completion(casearray)
                    }
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimateLoader2()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    completion(NSDictionary())
                }
            }
        }
    }
    
    func extendProjectDate(parameters : NSDictionary, completion: @escaping (Bool) -> Void) {
        CommonFunctions().animate()
        let manager = APIManager.apiManager
        manager.PostDataAndGetData(url: "pms/task/revision/enddate", dic: parameters as NSDictionary) { (dataResponse, result) in

            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion(true)
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimateLoader2()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    completion(false)
                }
            }
        }
    }
    
    func linkDocumentsToFolder(parameters : NSDictionary, completion: @escaping (Bool) -> Void) {
        CommonFunctions().animate()
        let manager = APIManager.apiManager
        manager.PostDataAndGetData(url: "ecm/documents/link", dic: parameters as NSDictionary) { (dataResponse, result) in

            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion(true)
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimateLoader2()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    completion(false)
                }
            }
        }
    }
    
    //MARK: GET DOCUMENT LCOATION LINK
    func getLocation(parameters : NSDictionary, completion: @escaping (String) -> Void) {
        CommonFunctions().animate()
        let manager = APIManager.apiManager
        manager.PostDataAndGetData(url: "ecm/documents/sharelocationlink", dic: parameters as NSDictionary) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let location : String = dataResponse as? String {
                        let upadatedLocation = location.replacingOccurrences(of: "<br />", with: "\r\n")
                        completion(upadatedLocation)
                    }
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimateLoader2()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    completion("")
                }
            }
        }
    }
    
    
    //MARK: SHARE WITH ME LISTING
    func getShareWithMeLists(completion: @escaping ([DocsSharedWithMe]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "ecm/documents/share/sharedwithme", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let docs = Mapper<DocsSharedWithMe>().mapArray(JSONObject: taskArray) ?? []
                    
                    if docs.count > 0 {
                        DispatchQueue.main.async {
                            completion(docs)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: SHARED WITH ME
    func getSharedWithMe(shareid: String, completion: @escaping (SharedDocumentModel?) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "ecm/documents/share/sharedwithme/\(shareid)", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let docs = Mapper<SharedDocumentModel>().mapArray(JSONObject: taskArray) ?? []
                    
                    if docs.count > 0 {
                        DispatchQueue.main.async {
                            completion(docs[0])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
            }
        }
    }
    
    //MARK: SHRE BY ME LISTING
    func getShareByMeLists(completion: @escaping ([DocsSharedByMe]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "ecm/documents/share/sharedbyme", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let docs = Mapper<DocsSharedByMe>().mapArray(JSONObject: taskArray) ?? []
                    
                    if docs.count > 0 {
                        DispatchQueue.main.async {
                            completion(docs)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: GET SHARE BY ME HISTORY
    func getShareByMeHistoryLists(shreid: String, completion: @escaping ([ShareByMeHistory]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "ecm/documents/share/sharedbyme/\(shreid)/history", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let history = Mapper<ShareByMeHistory>().mapArray(JSONObject: taskArray) ?? []
                    
                    if history.count > 0 {
                        DispatchQueue.main.async {
                            completion(history)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: GET FOLLOW-UP TASK LIST
    func getFollowUpList(taskid: String, completion: @escaping ([MyTaskModel]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "pms/task/\(taskid)/followup", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let tasks = Mapper<MyTaskModel>().mapArray(JSONObject: taskArray) ?? []
                    
                    if tasks.count > 0 {
                        DispatchQueue.main.async {
                            completion(tasks)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: GENERATE USER NAME INITIAL
    func generateInitial(username: String) -> String {
        var newUserInitial : String = ""
        let array = username.components(separatedBy: " ")
       
        
        if array.count > 1 {
            newUserInitial = String(array[0].prefix(1))
            newUserInitial.append(contentsOf: String(array[array.count - 1].prefix(1)))
        }
        else {
            if array[0] == ""{
                newUserInitial = "?"
            } 
            else {
                newUserInitial = String(username.prefix(1))
            }
        }

        return newUserInitial
    }
    // MARK: SHARE DOCUMENT LINK
    var link = ""
    
    func PostDocIDsToSever(parameters : NSDictionary) -> String {
        let jsonData = try? JSONSerialization.data(withJSONObject: parameters)
        
        // create post request
        let url = URL(string: "\(baseUrl)ecm/documents/sharelink")!
        var request = URLRequest(url: url)
        request.setValue(appDel?.userObj.SessionId, forHTTPHeaderField:"SessionId")
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        request.httpMethod = "POST"
        
        // insert json data to the request
        request.httpBody = jsonData
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                return
            }
            if let result = try? JSONSerialization.jsonObject(with: data, options: []) as? String
            {
                print(result as Any)
                
                if (result != "") {
                    
                    self.link = result!
                
                }
            }
            else {
                print("no data")
                self.link = ""
            }    
        }
        
        task.resume()
        return link
    }
    
    //MARK: Delete DRAFT
    func deleteDraft(url:String, completion: @escaping (Bool) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        let manager = APIManager.apiManager
        manager.DeleteDatadicFromUrlWithoutProgress(url: url, dic: parameters) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion(true)
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast(msgUnauthorised)
                    completion(false)
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast(msgUnauthorised)
                    completion(false)
                }
            }
        }
    }
    
    
    //MARK: OPEN SHARED DOCUMENT FOLDER
    func getShareID(shareid : String, completion: @escaping (SearchFolderModel,Bool) -> Void) {
        CommonFunctions().animate()
        var parameters :[String:AnyObject] = [:]
        parameters = [:]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrlWithoutProgress(url: "ecm/documents/share/link/" + shareid, dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        let selectedFolderModel = SearchFolderModel(JSON: [:])
                        
                        selectedFolderModel?.iD = resultDic.object(forKey: "FOLDER_ID") as! Int
                        selectedFolderModel?.tITLE = resultDic.object(forKey: "TITLE") as! String
                        selectedFolderModel?.bREAD_CRUMB = resultDic.object(forKey: "BREAD_CRUMB") as! String
                        selectedFolderModel?.lOCATION = resultDic.object(forKey: "LOCATION") as! String
                        
                        completion(selectedFolderModel!,true)
                    }
                    else {
                        appDel?.window?.makeToast("File(s) not found!")
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute: {
                            completion(SearchFolderModel(JSON: [:])!,false)
                        })
                        
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast(msgNoFolderPermission)
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast(msgSomethingWrong)
                }
            }
        }
    }
    
    
    //MARK: OPEN FOLDER
    func OpenECMFromSharesScreen(folderID : Int, completion: @escaping (SearchFolderModel,Bool) -> Void) {
        CommonFunctions().animate()
        var parameters :[String:AnyObject] = [:]
        parameters = [:]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrlWithoutProgress(url: "ecm/folder/" + String(folderID) + "/breadcrumb", dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()

                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        let selectedFolderModel = SearchFolderModel(JSON: [:])
                        
                        selectedFolderModel?.iD = resultDic.object(forKey: "ID") as! Int
                        selectedFolderModel?.tITLE = resultDic.object(forKey: "TITLE") as! String
                        selectedFolderModel?.bREAD_CRUMB = resultDic.object(forKey: "BREAD_CRUMB") as! String
                        selectedFolderModel?.lOCATION = resultDic.object(forKey: "LOCATION") as! String
                        
                        completion(selectedFolderModel!,true)
                    }
                    else {
                        appDel?.window?.makeToast("File(s) not found!")
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute: {
                            completion(SearchFolderModel(JSON: [:])!,false)
                        })
                        
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast(msgNoFolderPermission)
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast(msgSomethingWrong)
                }
            }
        }
    }
    
    //MARK: OPEN FOLDER
    func OpenECMFromAttachmentCount(folderID : Int, sourceVC : UIViewController) {
        CommonFunctions().animate()
        var parameters :[String:AnyObject] = [:]
        parameters = [:]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrlWithoutProgress(url: "ecm/folder/" + String(folderID) + "/breadcrumb", dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        let selectedFolderModel = SearchFolderModel(JSON: [:])
                        
                        selectedFolderModel?.iD = resultDic.object(forKey: "ID") as! Int
                        selectedFolderModel?.tITLE = resultDic.object(forKey: "TITLE") as! String
                        selectedFolderModel?.bREAD_CRUMB = resultDic.object(forKey: "BREAD_CRUMB") as! String
                        selectedFolderModel?.lOCATION = resultDic.object(forKey: "LOCATION") as! String
                        
                        let switchToECM : ECMMainVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ECMMainVC") as? ECMMainVC)!
                        switchToECM.mainFolderID = String(folderID)
                        switchToECM.isFromSearch = true
                        switchToECM.selectedFolderModel = selectedFolderModel
                        switchToECM.setListType(home: true, starred: false, recent: false)
                        //sourceVC.navigationController?.pushViewController(switchToECM, animated: true)
                        let nav4 = UINavigationController()
                        nav4.title = "Documents"
                        nav4.tabBarItem.image = UIImage(named: "ECM")
                        nav4.navigationBar.isHidden = true
                        appDel?.mainNav4 = nav4
                        nav4.viewControllers = [switchToECM]
                        
                        appDel?.mainTabbar.selectedIndex = 3
                        appDel?.mainTabbar.viewControllers = [(appDel?.mainTabbar.viewControllers?[0])!,(appDel?.mainTabbar.viewControllers?[1])!,(appDel?.mainTabbar.viewControllers?[2])!,nav4,appDel?.mainTabbar.viewControllers?[4]] as? [UIViewController]
                        
                        appDel?.window!.rootViewController = appDel?.mainTabbar
                        appDel?.window?.makeKeyAndVisible();
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast(msgNoFolderPermission)
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast(msgSomethingWrong)
                }
            }
        }
    }
    
    
    func taskActionMenu(index: Int, task: MyTaskModel?, vc: UIViewController) {
        if TaskActionMenu[index] == menuItem1 {
            self.taskPLay(objTask: (task)!, vc: vc)
        }
        else if TaskActionMenu[index] == menuItem2 {
            CommonFunctions().getTaskDetailsfromTaskID(taskID: (task?.tASKID)!) { (taskdetailModel) in
                
                if taskdetailModel != nil {
                    if taskdetailModel?.TASK_STASTISTICS != nil {
                        if taskdetailModel?.TASK_STASTISTICS?.cANREVISEDHOURS?.boolValue == false{
                            appDel?.window?.makeToast("You do not have permission to revise this task.")
                            return
                        }
                        UserDefaults.standard.set(false, forKey: "ForReviseTaskHour")
                        let controller : ReviseTaskVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "ReviseTaskVC"))! as! ReviseTaskVC
                        controller.objTaskDetails = taskdetailModel
                        vc.navigationController?.pushViewController(controller, animated: true)
                    }
                }
                else{
                    print(msgSomethingWrong)
                    return
                }
            }
        }
        else if TaskActionMenu[index] == menuItem3 {
            CommonFunctions().getTaskDetailsfromTaskID(taskID: (task?.tASKID)!) { (taskdetailModel) in
                
                if taskdetailModel != nil {
                    if taskdetailModel?.TASK_STASTISTICS != nil {
                        let controller = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateTaskNewVC"))! as! CreateTaskNewVC
                        controller.selectedMembers.append((taskdetailModel?.TASK_STASTISTICS?.tASKPERSON)!)
                        controller.selectedContactIDs.append((taskdetailModel?.TASK_STASTISTICS?.TASK_CONTACT_ID)!)
                        controller.titleDescriptionStr = (taskdetailModel?.TASK_STASTISTICS?.tASKDESCRIPTION)!
                        controller.isFollowUp = true
                        let prj = ProjectModel(JSON: [:])
                        prj?.pROJECTID = (taskdetailModel?.TASK_STASTISTICS?.PROJECT_ID)!
                        prj?.pROJECTNAME = (taskdetailModel?.TASK_STASTISTICS?.pROJECTNAME)!
                        
                        let milestone = ProjectSprintModel(JSON: [:])
                        milestone?.sPRINTID = (taskdetailModel?.TASK_STASTISTICS?.SPRINT_ID)!
                        milestone?.sPRINTNAME = (taskdetailModel?.TASK_STASTISTICS?.sPRINTNAME)!
                        milestone?.DATE_MODIFIED = (taskdetailModel?.TASK_STASTISTICS?.sPRINTENDDATE)!
                        controller.allProject = true
                        controller.selectedProject = prj
                        controller.selectedSprint = milestone
                        controller.parentTaskID = (taskdetailModel?.TASK_STASTISTICS?.tASKID)!
                        vc.navigationController?.pushViewController(controller, animated: true)
                    }
                }
                else{
                    print(msgSomethingWrong)
                    return
                }
            }
        }
        else if TaskActionMenu[index] == menuItem4 {
            
        }
        else if TaskActionMenu[index] == menuItem5{
            
        }
        else if TaskActionMenu[index] == menuItem6 {
            let controller = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "AddDocumentToTaskVC"))! as! AddDocumentToTaskVC
            controller.taskId = (task?.tASKID)!
            vc.navigationController?.pushViewController(controller, animated: true)
        }
        else if TaskActionMenu[index] == menuItem7 {
            
        }
        else if TaskActionMenu[index] == menuItem8 {
            
        }
        else if TaskActionMenu[index] == menuItem9 {
            
        }
        else {
            print("Invalid selection!")
        }
    }
    
    //MARK: PLAY TASK
    func taskPLay(objTask : MyTaskModel, vc: UIViewController) {
        let parameters: NSDictionary = [
            "taskId" : objTask.tASKID as Any,
            "ContactId" : objTask.cONTACTID as Any,
            "currentTaskId" : objTask.tASKID as Any
            ]
        let manager = APIManager.apiManager
        CommonFunctions().animate()
        manager.postReviseTaskFromUrl(url: "pms/progressentry/Task/Play", dic: parameters as NSDictionary) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    vc.navigationController?.popViewController(animated: true)
                }
                
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                }
                
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    appDel?.window?.makeToast(msgSomethingWrong)
                }
            }
        }
    }
    
    //MARK: Get Task Details
    func getTaskDetailsfromTaskID(taskID : Int, completion: @escaping (TaskDetails?) -> Void) {
        CommonFunctions().animate()
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "pms/task/\(taskID)/statistics", dic: parameters ) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                     DispatchQueue.main.async {
                        CommonFunctions().stopAnimate()
                   // if resultNDic.count >= 1{
                        if let resultDic : [String : Any] = dataResponse as? [String : Any]
                        {
                            let objTaskDetails = Mapper<TaskDetails>().map(JSON: resultDic)
                            completion(objTaskDetails)
                        }
                        else{
                           completion(nil)
                        }
                    }
                }
            else {
                 DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion(nil)
                }
            }
       }
    }
    
    //MARK: Fetch Milstone
    func getMilstone(date : String,projectID : String, completion: @escaping ([ProjectSprintModel]) -> Void) {
        
        CommonFunctions().animate()
        
        var parameters :[String:AnyObject] = [:]
        parameters = [:]
        let manager = APIManager.apiManager
        
        manager.getDatadicFromUrlWithoutProgress(url: "pms/project/\(projectID)/sprints/\(date)", dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultArray : NSArray = dataResponse as? NSArray
                    {
                        let arraysprints = Mapper<ProjectSprintModel>().mapArray(JSONObject: resultArray) ?? []
                        if arraysprints.count > 0 {
                            completion(arraysprints)
                        }
                        else {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                
                DispatchQueue.main.async {
                    
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                
                DispatchQueue.main.async {
                    
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: WorkItemType
    func getWorkItemType(completion: @escaping ([TASKTYPE]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "pms/task/group/false", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskdic : NSDictionary = dataResponse as? NSDictionary
                {
                    
                    if let taskArray : NSArray = taskdic.object(forKey: "TASK_TYPE") as? NSArray
                    {
                        let typeArray = Mapper<TASKTYPE>().mapArray(JSONObject: taskArray) ?? []
                        DispatchQueue.main.async {
                            completion(typeArray)
                        }
                    }
                   
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: EPIC
    func getEpicList(projectId: String, completion: @escaping ([EpicListModel]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "pms/project/\(projectId)/epic", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let epicList = Mapper<EpicListModel>().mapArray(JSONObject: taskArray) ?? []
                    
                    if epicList.count > 0 {
                        DispatchQueue.main.async {
                            completion(epicList)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: FEATURE
    func getFeatureList(projectId: String, epicId: String, completion: @escaping ([FeatureListModel]) -> Void) {
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "pms/project/\(projectId)/feature/\(epicId)", dic: parameters ) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    let epicList = Mapper<FeatureListModel>().mapArray(JSONObject: taskArray) ?? []
                    
                    if epicList.count > 0 {
                        DispatchQueue.main.async {
                            completion(epicList)
                        }
                    }
                    else  {
                        DispatchQueue.main.async {
                            completion([])
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    completion([])
                }
            }
        }
    }
    
    //MARK: STORY
    func getUserStoryList(projectId: String, completion: @escaping ([TaskModel]) -> Void) {
        CommonFunctions().animate()
        let parameters :[String:AnyObject] = ["ProjectId": projectId as AnyObject]
        let manager = APIManager.apiManager
        manager.PostDataAndGetData(url: "pms/project/workitem/userstories", dic: parameters as NSDictionary) { (dataResponse, result) in

            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let casearray : NSArray = dataResponse as? NSArray {
                        let caseArray = Mapper<TaskModel>().mapArray(JSONObject: casearray) ?? []
                        completion(caseArray)
                    }
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimateLoader2()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    completion([])
                }
            }
        }
    }
    
    struct AppUtility {
        
        static func lockOrientation(_ orientation: UIInterfaceOrientationMask) {
            
            if let delegate = UIApplication.shared.delegate as? AppDelegate {
                delegate.restrictRotation = orientation
            }
        }
        
        /// OPTIONAL Added method to adjust lock and rotate to the desired orientation
        static func lockOrientation(_ orientation: UIInterfaceOrientationMask, andRotateTo rotateOrientation:UIInterfaceOrientation) {
            
            self.lockOrientation(orientation)
            
            UIDevice.current.setValue(rotateOrientation.rawValue, forKey: "orientation")
            UINavigationController.attemptRotationToDeviceOrientation()
        }
    }
}

func hexStringToUIColor (hex:String) -> UIColor {
    var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    
    if (cString.hasPrefix("#")) {
        cString.remove(at: cString.startIndex)
    }
    
    if ((cString.count) != 6) {
        return UIColor.gray
    }
    
    var rgbValue:UInt32 = 0
    Scanner(string: cString).scanHexInt32(&rgbValue)
    
    return UIColor(
        red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
        green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
        blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
        alpha: CGFloat(1.0)
    )
}

func isValidEmail(testStr:String) -> Bool {
    // print("validate calendar: \(testStr)")
    let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
    
    let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
    return emailTest.evaluate(with: testStr)
}

func isvalidPrefix(testStr: String) -> Bool {
    let validRegex = "^[a-zA-Z]+$"
    let prefix = NSPredicate(format:"SELF MATCHES %@", validRegex)
    return prefix.evaluate(with: testStr)
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromNSAttributedStringKey(_ input: NSAttributedString.Key) -> String {
	return input.rawValue
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToOptionalNSAttributedStringKeyDictionary(_ input: [String: Any]?) -> [NSAttributedString.Key: Any]? {
	guard let input = input else { return nil }
	return Dictionary(uniqueKeysWithValues: input.map { key, value in (NSAttributedString.Key(rawValue: key), value)})
}

extension URL {
    var typeIdentifier: String? {
        return (try? resourceValues(forKeys: [.typeIdentifierKey]))?.typeIdentifier
    }
    var localizedName: String? {
        return (try? resourceValues(forKeys: [.localizedNameKey]))?.localizedName
    }
}
