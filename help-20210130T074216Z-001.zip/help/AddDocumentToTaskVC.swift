//
//  AddDocumentToTaskVC.swift
//  WorkInProgress
//
//  Created by Mac Mini on 19/08/20.
//  Copyright © 2020 Arpit Shah. All rights reserved.
//

import UIKit
import ObjectMapper
import Alamofire
import AFNetworking
import OpalImagePicker
import BSImagePicker
import AssetsLibrary
import MWPhotoBrowser

class AddDocumentToTaskVC: UIViewController, UIImagePickerControllerDelegate,UINavigationControllerDelegate,OpalImagePickerControllerDelegate,UIDocumentPickerDelegate, UITableViewDataSource , UITableViewDelegate {

    @IBOutlet var tblTasks : UITableView!
    @IBOutlet var iPhoneXHeight: NSLayoutConstraint!
    
    @IBOutlet var lblHeader: UILabel!
    @IBOutlet weak var mainBGImg: UIImageView!
    
    typealias ServiceComplitionBlockArray = (AnyObject? ,APIResult)  -> Void
    
    var frontData : Data? = nil
    var frontExtension : String = ""
    var frontmimeType : String = ""
    var isUpload : Bool = false
    var uploadedDocArray = [NSMutableDictionary]()
    var selectedDocuments = [DocumentUploadModel]()
    var taskId : Int = 0
    var leadCompanyID : Int = 0
    var leadCompanyName : String = ""
    var isTicket : Bool = false
    var isFromLead : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if iphoneX == false {
            iPhoneXHeight.constant = 0
        }
        
        self.mainBGImg.image = GlobalbackgroundImage
        
        tblTasks.separatorStyle = .none
        
        self.lblHeader.attributedText = CommonFunctions().getHeader(title: "Selected document(s)", count: "0")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.lblHeader.attributedText = CommonFunctions().getHeader(title: "Selected document(s)", count: String(describing: selectedDocuments.count))
        tblTasks.reloadData()
    }
    
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onUpload(_ sender: Any) {
        
        if self.selectedDocuments.count > 0 {
            CommonFunctions().showThemeAlert(msgTitle: "Alert", msg: "Are you sure you want to upload ?") { (isSuccess) in
                if isSuccess {
                    self.uploadDocs()
                }
                else {
                    return
                }
            }
        }
        else {
            appDel?.window?.makeToast("You have no document to upload!")
        }
    }
    
    @IBAction func onAttachDocument(_ sender: Any) {
        self.uploadDocument()
    }
    
    //MARK: document uplaod
    
    func uploadDocument(){
        let imageController = UIImagePickerController()
        imageController.isEditing = false
        imageController.delegate = self
        
        let alert = UIAlertController(title: "", message: "Select Action", preferredStyle: .actionSheet)
        
        let linkButton = UIAlertAction(title: uploadOption3, style: .default) { (alert) in
            let selectMember = appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "LinkFromDocumentVC") as? LinkFromDocumentVC
            selectMember?.delegate = self
            selectMember?.modalPresentationStyle = .fullScreen
            self.present(selectMember!, animated: true, completion: nil)
            
        }
        
        
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera)){
            let cameraButton = UIAlertAction(title: uploadOption1, style: UIAlertAction.Style.default) { (alert)  in
                print("Take Photo")
                imageController.sourceType = UIImagePickerController.SourceType.camera
                self.present(imageController, animated: true, completion: nil)
            }
            alert.addAction(cameraButton)
        } else {
            print("Camera not available")
        }
        let libButton = UIAlertAction(title: uploadOption4, style: .default) { (alert) in
            self.openMultiplePhotoSelectionPicker()
        }
        let docButton = UIAlertAction(title: uploadOption2, style: .default) { (alert) in
            self.openDocumentPicker(tagDoc: 1)
        }
        let cancelButton = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel) { (alert) in
            print("Cancel Pressed")
        }
        
        
        if #available(iOS 11.0, *) {
            alert.addAction(docButton)
        }
        alert.addAction(linkButton)
        alert.addAction(libButton)
        
        if UI_USER_INTERFACE_IDIOM() ==  UIUserInterfaceIdiom.pad {
            alert.popoverPresentationController?.sourceView = self.view
            alert.popoverPresentationController?.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
            alert.popoverPresentationController?.permittedArrowDirections = []
        }
        alert.addAction(cancelButton)
        self.present(alert, animated: true, completion: {
            switch UIDevice.current.orientation {
            case .landscapeRight:
                alert.view.transform=CGAffineTransform(rotationAngle: CGFloat(-Double.pi / 2))
            case .landscapeLeft:
                alert.view.transform=CGAffineTransform(rotationAngle: CGFloat(Double.pi / 2))
            default:
                alert.view.transform=CGAffineTransform.identity
            }
        })
        
    }
    func openMultiplePhotoSelectionPicker(){
        //  imagePicker.imagePickerDelegate = self
        // present(imagePicker, animated: true, completion: nil)
        openMultipleDoc()
    }
    func openMultipleDoc(){
        let vc = BSImagePickerViewController()
        
        bs_presentImagePickerController(vc, animated: true,
                                        select: { (asset: PHAsset) -> Void in
                                            // User selected an asset.
                                            // Do something with it, start upload perhaps?
        }, deselect: { (asset: PHAsset) -> Void in
            // User deselected an assets.
            // Do something, cancel upload?
        }, cancel: { (assets: [PHAsset]) -> Void in
            // User cancelled. And this where the assets currently selected.
        }, finish: { (assets: [PHAsset]) -> Void in
            // User finished with these assets
            print(assets)
            DispatchQueue.main.async {
                self.openMultipleuploadVC(images: assets)
            }
        }, completion: nil)
    }
    
    func openDocumentPicker(tagDoc : Int){
           let documentPicker: UIDocumentPickerViewController = UIDocumentPickerViewController(documentTypes: ["public.data"], in: UIDocumentPickerMode.import)
           documentPicker.delegate = self
           documentPicker.view.tag = tagDoc
           documentPicker.modalPresentationStyle = UIModalPresentationStyle.fullScreen
           self.present(documentPicker, animated: true) {
           }
       }
       
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        
    }
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        let anotherMime = MimeType(url: urls[0]).value
        print(anotherMime)
        let nameArr = urls[0].absoluteString.components(separatedBy: "/")
        let strExtension = urls[0].pathExtension
        do {
            frontData = try Data(contentsOf: urls[0] as URL)
            frontExtension = strExtension
            frontmimeType = anotherMime
            let docObj = DocumentUploadModel()
            docObj.docID = 0
            docObj.imageName = nameArr.last!
            docObj.imageName = docObj.imageName.removingPercentEncoding!
            docObj.mimeType = anotherMime
            docObj.dataOfDoc = frontData
            docObj.strExtention = strExtension
            selectedDocuments.append(docObj)
            print(strExtension)
            print(nameArr)
            self.lblHeader.attributedText = CommonFunctions().getHeader(title: "Selected document(s)", count: String(describing: selectedDocuments.count))
            self.tblTasks.reloadData()
            
        } catch {
            print("Unable to load data: \(error)")
        }
    }
    
    func imagePicker(_ picker: OpalImagePickerController, didFinishPickingImages images: [UIImage]) {
        picker.dismiss(animated: true) {
            
        }
    }
    func imagePickerDidCancel(_ picker: OpalImagePickerController){
        picker.dismiss(animated: true) {
            
        }
    }
    func openMultipleuploadVC(images : [PHAsset]){
        var index : Int = 0
        for img in images {
            let requestOptions = PHImageRequestOptions()
            requestOptions.resizeMode = PHImageRequestOptionsResizeMode.exact
            requestOptions.deliveryMode = PHImageRequestOptionsDeliveryMode.highQualityFormat
            // this one is key
            requestOptions.isSynchronous = true
            index = index + 1
            let objImg = DocumentUploadModel()
            PHImageManager.default().requestImage(for: img , targetSize: PHImageManagerMaximumSize, contentMode: PHImageContentMode.default, options: requestOptions, resultHandler: { (pickedImage, info) in
                objImg.image = pickedImage // you can get image like this way
                objImg.dataOfDoc = pickedImage!.jpegData(compressionQuality: 0.5)!
            })
            objImg.strExtention = ".jpg"
            objImg.imageName = "IMG_\(index)_" + CommonFunctions().getCurrentDateTime() + objImg.strExtention
            objImg.docID = 0
            objImg.mimeType = "image/jpeg"
            selectedDocuments.append(objImg)
            self.lblHeader.attributedText = CommonFunctions().getHeader(title: "Selected document(s)", count: String(describing: selectedDocuments.count))
            self.tblTasks.reloadData()
        }
    }
    
    func uploadDocs() {
        CommonFunctions().animate()
        self.view.isUserInteractionEnabled = false
        
        let parameters :[String:AnyObject] = [:]
        if self.selectedDocuments.count >= 1{
            var tempArray = [DocumentUploadModel]()
            
            for j in 0..<self.selectedDocuments.count{
                let objDocument = self.selectedDocuments[j]
                if objDocument.docID == 0 {
                    tempArray.append(objDocument)
                }
            }
            if tempArray.count > 0 {
                for i in 0..<tempArray.count{
                    let objDocument = tempArray[i]
                    //objDocument.imageName = self.txtTaskTitle.text! + "_" + "\(i+1)"
                    if i > 0{
                        RunLoop.current.run(until: Date.init(timeIntervalSinceNow: 2.0))
                    }
                    if objDocument.docID == 0 {
                        self.uploadDocandCreateTask(count: i, dic: parameters, objDoc: objDocument, alldoc: tempArray, block: { (response, result) in
                            if (result == APIResult.APISuccess) {
                            
                            }
                            else if (result == APIResult.APIError){
                                DispatchQueue.main.async {
                                    CommonFunctions().stopAnimate()
                                }
                            }
                            else {
                            
                            }
                        })
                    }
                    else {
                        
                    }
                }
            }
            else {
                self.finalUpload()
            }
        }
        else{
            
        }
        
    }
    
    func uploadDocandCreateTask(count : Int ,dic : [String : AnyObject],objDoc : DocumentUploadModel, alldoc: [DocumentUploadModel], block: @escaping ServiceComplitionBlockArray){
        
        let manager =  AFHTTPSessionManager()
        
        manager.requestSerializer = AFHTTPRequestSerializer()
        manager.responseSerializer = AFHTTPResponseSerializer()
        
        let myUrl : String = baseUrl + "pms/task/document"
        if let strSession : String = appDel?.userObj.SessionId
        {
            if strSession.count < 5 {
                appDel?.window?.makeToast("Invalid credentials")
                CommonFunctions().stopAnimate()
                return
            }
        }
        manager.requestSerializer.setValue(appDel?.userObj.SessionId, forHTTPHeaderField: "SessionId")
        manager.post(myUrl, parameters: dic, constructingBodyWith: { (multipartData) in
            
            if (objDoc.dataOfDoc != nil) {
                multipartData.appendPart(withFileData: objDoc.dataOfDoc as Data, name: objDoc.imageName, fileName: objDoc.imageName, mimeType: objDoc.mimeType)
            }
            
        }, progress: {(progress) in }, success: {(sessionDatatask , responseObject) in
            let responseHeader = sessionDatatask.response as! HTTPURLResponse
            
            if (responseHeader.statusCode ==  200) {
                
                do {
                    let responseDict = try JSONSerialization.jsonObject(with: (responseObject as! NSData) as Data, options: .allowFragments) as AnyObject
                    print ("responseDict====\(responseDict)")
                    if let arrayDic : NSArray = responseDict as? NSArray{
                        let nDict : NSMutableDictionary = (arrayDic[0] as! NSDictionary).mutableCopy() as! NSMutableDictionary
                        nDict.removeObject(forKey: "DocId")
                        self.uploadedDocArray.append(nDict)
                    }
                    let responseHeader = sessionDatatask.response as! HTTPURLResponse
                    print(responseHeader.statusCode)
                    
                    if self.uploadedDocArray.count == alldoc.count {
                        
                        self.finalUpload()
                        
                    }
                    // use jsonObject here
                } catch {
                    
                    
                    print("json error: \(error)")
                    DispatchQueue.main.async {
                        CommonFunctions().stopAnimate()
                        appDel?.window?.makeToast(msgSomethingWrong)
                        block([:] as AnyObject? , APIResult.APISuccess)
                    }
                }
            }
            else{
                DispatchQueue.main.async {
                    appDel?.window?.makeToast(msgSomethingWrong)
                    block([:] as AnyObject? , APIResult.APIError)
                }
            }
            
            
        }, failure: {(sessionDatatask , error) in
            DispatchQueue.main.async {
                CommonFunctions().stopAnimate()
                appDel?.window?.makeToast(msgSomethingWrong)
                print("fail:\(error.localizedDescription)")
            }
        })
    }
    
    func finalUpload() {
        for obj in selectedDocuments {
            if obj.docID != 0 {
                let DocDict : NSMutableDictionary = NSMutableDictionary()
                DocDict.setValue(obj.systemFileName, forKey: "SystemFileName")
                DocDict.setValue(obj.imageName, forKey: "OrignalFileName")
                DocDict.setValue(obj.docID, forKey: "DocId")
                uploadedDocArray.append(DocDict)
            }
        }
        CommonFunctions().animate()
        if isTicket {
            var parameters :[String:AnyObject] = [:]
            parameters = ["UploadedFiles": uploadedDocArray as AnyObject, "Tickets": [self.taskId] as AnyObject]
            
            let manager = APIManager.apiManager
            manager.postDataWithBlankResponseOrErrorMsgFromUrl(url: "queue/ticket/attachdocument", dic: parameters as NSDictionary) { (dataResponse, result) in
                
                if (result == APIResult.APISuccess) {
                    DispatchQueue.main.async {
                        self.view.isUserInteractionEnabled = true
                        CommonFunctions().stopAnimate()
                        CommonFunctions().showAlert(msg: "Documents attached successfully")
                        self.navigationController?.popViewController(animated: true)
                    }
                }
                else if (result == APIResult.APIError) {
                    DispatchQueue.main.async {
                        self.view.isUserInteractionEnabled = true
                        if let resultDic : NSDictionary = dataResponse as? NSDictionary
                        {
                            CommonFunctions().showErrorMessage(resultDic: resultDic)
                        }
                        else {
                            appDel?.window?.makeToast(msgSomethingWrong)
                        }
                        CommonFunctions().stopAnimate()
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
        }
        else if isFromLead {
            var uploadedECMDocArray = [NSMutableDictionary]()
            for obj in self.selectedDocuments {
                if obj.docID != 0 {
                    let DocDict : NSMutableDictionary = NSMutableDictionary()
                    DocDict.setValue(obj.docID, forKey: "DocId")
                    uploadedECMDocArray.append(DocDict)
                }
            }
            
            var parameters :[String:AnyObject] = [:]
            parameters = ["LEAD_ID": self.taskId as AnyObject, "UploadedFiles": self.uploadedDocArray as AnyObject,"COMPANY_ID": self.leadCompanyID as AnyObject, "COMPANY_NAME": self.leadCompanyName as AnyObject, "EntityAttachments": uploadedECMDocArray as AnyObject]
            
            CommonFunctions().attachDocumentsToLead(dic: parameters as NSDictionary) { (uploadedDocs) in
                if uploadedDocs {
                    self.view.isUserInteractionEnabled = true
                    CommonFunctions().stopAnimate()
                    CommonFunctions().showAlert(msg: "Documents attached successfully")
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
        else {
            CommonFunctions().attachDocumentsToTask(taskIds: [taskId], docs: uploadedDocArray) { (success) in
                if success {
                    self.view.isUserInteractionEnabled = true
                    self.navigationController?.popViewController(animated: true)
                }
                else {
                    self.view.isUserInteractionEnabled = true
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast(msgSomethingWrong)
                    
                }
            }
        }
    }
    
    //MARK: REMOVE DOCUMENT
    @objc func removeDocClicked(sender : UIButton) {
        CommonFunctions().showThemeAlert(msgTitle: "Alert", msg: "Are you sure you want to delete ?") { (isSuccess) in
            if isSuccess {
                self.selectedDocuments.remove(at: sender.tag)
                self.tblTasks.reloadData()
            }
            else {
                return
            }
        }
    }
    
    //MARK: UItableview Delegate Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.selectedDocuments.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ECMDocumentListCell", for: indexPath) as? ECMDocumentListCell
   
        cell?.imgArray = self.selectedDocuments
        cell?.setView(imgObj: selectedDocuments[indexPath.row])
        
        cell?.btnClose.isHidden = false
        cell?.btnClose.addTarget(self, action: #selector(self.removeDocClicked(sender:)), for: .touchUpInside)
        cell?.btnClose.tag = indexPath.row
        
        cell?.bgView.layer.shadow()
        
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
    }
}

extension AddDocumentToTaskVC : getSelectedDocument {
    func document(docs: [DocumentUploadModel]) {
        
        dismiss(animated: true, completion: {
            self.selectedDocuments.append(contentsOf: docs)
            self.selectedDocuments = self.selectedDocuments.unique{$0.docID}
            self.lblHeader.attributedText = CommonFunctions().getHeader(title: "Selected document(s)", count: String(describing: self.selectedDocuments.count))
            self.tblTasks.reloadData()
        })
        
    }
}
