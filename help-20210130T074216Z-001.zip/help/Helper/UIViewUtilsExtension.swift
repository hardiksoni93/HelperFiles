//
//  UIViewUtilsExtension.swift
//  Swift Shopper
//
//  Created by Ajay.Ghodadra on 03/05/16.
//  Copyright © 2016 Simform. All rights reserved.
//

import Foundation
import UIKit

public let kUIViewPropertyCornerRadiusValue = 0.0
private var kUIViewPropertyCornerRadius = "kUIViewPropertyCornerRadius"

public let kUIViewPropertyBorderColorValue = UIColor.clear
private var kUIViewPropertyBorderColor = "kUIViewPropertyBorderColor"

public let kUIViewPropertyBorderWidthValue = 0.0
private var kUIViewPropertyBorderWidth = "kUIViewPropertyBorderWidth"

public let kUIViewPropertyBackgroundColorValue = UIColor.white
private var kUIViewPropertyBackgroundColor = "kUIViewPropertyBackgroundColor"

//public let kUIViewPropertyUserInformationValue as? AnyObject;
//private var kUIViewPropertyUserInformation = "kUIViewPropertyUserInformation"


@IBDesignable
class UILabelX: UILabel {
    // *******************************************************
    // DEFINITIONS (Because I'm not brilliant and I'll forget most this tomorrow.)
    // Radius: A straight line from the center to the circumference of a circle.
    // Circumference: The distance around the edge (outer line) the circle.
    // Arc: A part of the circumference of a circle. Like a length or section of the circumference.
    // Theta: A label or name that represents an angle.
    // Subtend: A letter has a width. If you put the letter on the circumference, the letter's width
    //          gives you an arc. So now that you have an arc (a length on the circumference) you can
    //          use that to get an angle. You get an angle when you draw a line from the center of the
    //          circle to each end point of your arc. So "subtend" means to get an angle from an arc.
    // Chord: A line segment connecting two points on a curve. If you have an arc then there is a
    //          start point and an end point. If you draw a straight line from start point to end point
    //          then you have a "chord".
    // sin: (Super simple/incomplete definition) Or "sine" takes an angle in degrees and gives you a number.
    // asin: Or "asine" takes a number and gives you an angle in degrees. Opposite of sine.
    //          More complete definition: http://www.mathsisfun.com/sine-cosine-tangent.html
    // cosine: Also takes an angle in degrees and gives you another number from using the two radiuses (radii).
    // *******************************************************
    
    @IBInspectable var angle: CGFloat = 1.6
    @IBInspectable var clockwise: Bool = true
    
    override func draw(_ rect: CGRect) {
        centreArcPerpendicular()
    }
    
    /**
     This draws the self.text around an arc of radius r,
     with the text centred at polar angle theta
     */
    func centreArcPerpendicular() {
        guard let context = UIGraphicsGetCurrentContext() else { return }
        let str = self.text ?? ""
        let size = self.bounds.size
        context.translateBy(x: size.width / 2, y: size.height / 2)
        
        let radius = getRadiusForLabel()
        let l = str.count
        let attributes: [String : Any] = [convertFromNSAttributedStringKey(NSAttributedString.Key.font): self.font]
        
        let characters: [String] = str.map { String($0) } // An array of single character strings, each character in str
        var arcs: [CGFloat] = [] // This will be the arcs subtended by each character
        var totalArc: CGFloat = 0 // ... and the total arc subtended by the string
        
        // Calculate the arc subtended by each letter and their total
        for i in 0 ..< l {
            arcs += [chordToArc(characters[i].size(withAttributes: convertToOptionalNSAttributedStringKeyDictionary(attributes)).width, radius: radius)]
            totalArc += arcs[i]
        }
        
        // Are we writing clockwise (right way up at 12 o'clock, upside down at 6 o'clock)
        // or anti-clockwise (right way up at 6 o'clock)?
        let direction: CGFloat = clockwise ? -1 : 1
        //let slantCorrection = clockwise ? -CGFloat(M_PI_2) : CGFloat(M_PI_2)
        let slantCorrection = clockwise ? -CGFloat.pi/2 : CGFloat.pi/2
        // The centre of the first character will then be at
        // thetaI = theta - totalArc / 2 + arcs[0] / 2
        // But we add the last term inside the loop
        var thetaI = angle - direction * totalArc / 2
        
        for i in 0 ..< l {
            thetaI += direction * arcs[i] / 2
            // Call centre with each character in turn.
            // Remember to add +/-90º to the slantAngle otherwise
            // the characters will "stack" round the arc rather than "text flow"
            centre(text: characters[i], context: context, radius: radius, angle: thetaI, slantAngle: thetaI + slantCorrection)
            // The centre of the next character will then be at
            // thetaI = thetaI + arcs[i] / 2 + arcs[i + 1] / 2
            // but again we leave the last term to the start of the next loop...
            thetaI += direction * arcs[i] / 2
        }
    }
    
    func chordToArc(_ chord: CGFloat, radius: CGFloat) -> CGFloat {
        // *******************************************************
        // Simple geometry
        // *******************************************************
        return 2 * asin(chord / (2 * radius))
    }
    
    /**
     This draws the String str centred at the position
     specified by the polar coordinates (r, theta)
     i.e. the x= r * cos(theta) y= r * sin(theta)
     and rotated by the angle slantAngle
     */
    func centre(text str: String, context: CGContext, radius r:CGFloat, angle theta: CGFloat, slantAngle: CGFloat) {
        // Set the text attributes
        let attributes = [convertFromNSAttributedStringKey(NSAttributedString.Key.foregroundColor): self.textColor,
                          convertFromNSAttributedStringKey(NSAttributedString.Key.font): UIFont(name: "Gotham-Book", size: 15.0)!] as [String : Any]
        // Save the context
        context.saveGState()
        // Move the origin to the centre of the text (negating the y-axis manually)
        context.translateBy(x: r * cos(theta), y: -(r * sin(theta)))
        // Rotate the coordinate system
        context.rotate(by: -slantAngle)
        // Calculate the width of the text
        let offset = str.size(withAttributes: convertToOptionalNSAttributedStringKeyDictionary(attributes))
        // Move the origin by half the size of the text
        context.translateBy(x: -offset.width / 2, y: -offset.height / 2) // Move the origin to the centre of the text (negating the y-axis manually)
        // Draw the text
        str.draw(at: CGPoint(x: 0, y: 0), withAttributes: convertToOptionalNSAttributedStringKeyDictionary(attributes))
        // Restore the context
        context.restoreGState()
    }
    
    func getRadiusForLabel() -> CGFloat {
        // Imagine the bounds of this label will have a circle inside it.
        // The circle will be as big as the smallest width or height of this label.
        // But we need to fit the size of the font on the circle so make the circle a little
        // smaller so the text does not get drawn outside the bounds of the circle.
        let smallestWidthOrHeight = min(self.bounds.size.height, self.bounds.size.width)
        let heightOfFont = self.text?.size(withAttributes: convertToOptionalNSAttributedStringKeyDictionary([convertFromNSAttributedStringKey(NSAttributedString.Key.font): self.font])).height ?? 0
        
        // Dividing the smallestWidthOrHeight by 2 gives us the radius for the circle.
        return (smallestWidthOrHeight/2) - heightOfFont + 5
    }
}

public extension UIView{
    @IBInspectable public var cornerRadius: CGFloat{
        get {
            if let aValue = objc_getAssociatedObject(self, &kUIViewPropertyCornerRadius) as? CGFloat {
                return aValue
            } else {
                return CGFloat(kUIViewPropertyCornerRadiusValue)
            }
        }
        set(newValue) {
            objc_setAssociatedObject(self, &kUIViewPropertyCornerRadius, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
            self.layer.cornerRadius = newValue
        }
    }
    
    @IBInspectable public var borderColor: UIColor{
        get {
            if let aValue = objc_getAssociatedObject(self, &kUIViewPropertyBorderColor) as? UIColor {
                return aValue
            } else {
                return kUIViewPropertyBorderColorValue
            }
        }
        set(newValue) {
            objc_setAssociatedObject(self, &kUIViewPropertyBorderColor, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
            self.layer.borderColor = newValue.cgColor
        }
    }
    
    @IBInspectable public var borderWidth: CGFloat{
        get {
            if let aValue = objc_getAssociatedObject(self, &kUIViewPropertyBorderWidth) as? CGFloat {
                return aValue
            } else {
                return CGFloat(kUIViewPropertyBorderWidthValue)
            }
        }
        set(newValue) {
            objc_setAssociatedObject(self, &kUIViewPropertyBorderWidth, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
            self.layer.borderWidth = newValue
        }
    }
    
//    public var userInformation: AnyObject{
//        get {
//            if let aValue = objc_getAssociatedObject(self, &kUIViewPropertyBackgroundColor) as? UIColor {
//                return aValue
//            } else {
//                return kUIViewPropertyBackgroundColorValue
//            }
//        }
//        set(newValue) {
//            objc_setAssociatedObject(self, &kUIViewPropertyBackgroundColor, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
//        }
//    }
    
    
    
}
class CustomText: UITextField {
    @IBInspectable var rightImage : UIImage?{
        didSet{
            let imageView = UIImageView(frame: CGRect(x: 0, y: 3, width: 15, height: 15))
            imageView.image = rightImage
            imageView.tintColor = tintColor
            let view = UIView(frame : CGRect(x: 0, y: 0, width: 25, height: 20))
            view.addSubview(imageView)
            
            self.rightView = view
            // select mode -> .never .whileEditing .unlessEditing .always
            self.rightViewMode = .always
        }
    }
}

extension NSLayoutConstraint {
    func setMultiplier(multiplier:CGFloat) -> NSLayoutConstraint {
        
        NSLayoutConstraint.deactivate([self])
        
        let newConstraint = NSLayoutConstraint(
            item: firstItem,
            attribute: firstAttribute,
            relatedBy: relation,
            toItem: secondItem,
            attribute: secondAttribute,
            multiplier: multiplier,
            constant: constant)
        
        newConstraint.priority = priority
        newConstraint.shouldBeArchived = self.shouldBeArchived
        newConstraint.identifier = self.identifier
        
        NSLayoutConstraint.activate([newConstraint])
        return newConstraint
    }
}

extension UIViewController {
    func addInputAccessoryForTextFields(textFields: [UITextField], dismissable: Bool = true, previousNextable: Bool = false) {
        for (index, textField) in textFields.enumerated() {
            textField.autocorrectionType = .no
            let toolbar: UIToolbar = UIToolbar()
            toolbar.sizeToFit()
            
            var items = [UIBarButtonItem]()
            if previousNextable {
                let previousButton = UIBarButtonItem(image: UIImage(named: "tool_back"), style: .plain, target: nil, action: nil)
                previousButton.width = 30
                if textField == textFields.first {
                    previousButton.isEnabled = false
                } else {
                    previousButton.target = textFields[index - 1]
                    previousButton.action = #selector(UITextField.becomeFirstResponder)
                }
                
                let nextButton = UIBarButtonItem(image: UIImage(named: "tool_next"), style: .plain, target: nil, action: nil)
                nextButton.width = 30
                if textField == textFields.last {
                    nextButton.isEnabled = false
                } else {
                    nextButton.target = textFields[index + 1]
                    nextButton.action = #selector(UITextField.becomeFirstResponder)
                }
                
                items.append(contentsOf: [previousButton, nextButton])
            }
            
            let spacer = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
            let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: view, action: #selector(UIView.endEditing))
            items.append(contentsOf: [spacer, doneButton])
            
            toolbar.setItems(items, animated: false)
            textField.inputAccessoryView = toolbar
        }
    }
    
    
}

extension UIImageView {
    func setImageThemeColor() {
        let templateImage = self.image?.withRenderingMode(.alwaysTemplate)
        self.image = templateImage
        if let colorcode : String = UserDefaults.standard.object(forKey: themeBorder) as? String{
            self.tintColor = hexStringToUIColor(hex: colorcode)
        }
    }
    
    func pulsate() {
        
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 0.3
        pulse.fromValue = 0.95
        pulse.toValue = 1.0
        pulse.autoreverses = true
        pulse.repeatCount = 2
        pulse.initialVelocity = 0.5
        pulse.damping = 1.0
        
        layer.add(pulse, forKey: nil)
    }
}

extension UIImage {
    func toBase64() -> String? {
        guard let imageData = self.pngData() else { return nil }
        return imageData.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
    }
}

extension Collection where Indices.Iterator.Element == Index {
    subscript (exist index: Index) -> Iterator.Element? {
        return indices.contains(index) ? self[index] : nil
    }
}

extension UITextField {
    func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    func setRightPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
}

extension Double {
    /// Rounds the double to decimal places value
    func roundTo(places:Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded() / divisor
    }
    
    var clean: String {
       return self.truncatingRemainder(dividingBy: 1) == 0 ? String(format: "%.0f", self) : String(self)
    }
    
    func withCommas() -> String {
           let numberFormatter = NumberFormatter()
           //numberFormatter.locale = Locale(identifier: "en_US_POSIX")
           //numberFormatter.locale = Locale.autoupdatingCurrent
           numberFormatter.numberStyle = .decimal
           numberFormatter.secondaryGroupingSize = 3
           return numberFormatter.string(from: NSNumber(value:self))!
    }
}

extension Int {
    func withCommas() -> String {
        let numberFormatter = NumberFormatter()
        //numberFormatter.locale = Locale(identifier: "en_US_POSIX")
        //numberFormatter.locale = Locale.autoupdatingCurrent
        numberFormatter.numberStyle = .decimal
        numberFormatter.secondaryGroupingSize = 3
        return numberFormatter.string(from: NSNumber(value:self))!
    }
}

extension Float {
    /// Rounds the double to decimal places value
    func roundTo(places:Int) -> Float {
        let divisor = pow(10.0, Float(places))
        return (self * divisor).rounded() / divisor
    }
}

extension String {
    
    init?(htmlEncodedString: String) {
        
        guard let data = htmlEncodedString.data(using: .utf8) else {
            return nil
        }
        
        let options: [String: Any] = [
            convertFromNSAttributedStringDocumentAttributeKey(NSAttributedString.DocumentAttributeKey.documentType): convertFromNSAttributedStringDocumentType(NSAttributedString.DocumentType.html),
            convertFromNSAttributedStringDocumentAttributeKey(NSAttributedString.DocumentAttributeKey.characterEncoding): String.Encoding.utf8.rawValue
        ]
        
        guard let attributedString = try? NSAttributedString(data: data, options: convertToNSAttributedStringDocumentReadingOptionKeyDictionary(options), documentAttributes: nil) else {
            return nil
        }
        
        self.init(attributedString.string)
    }
    
    func htmlAttributedString() -> NSAttributedString? {
        guard let data = self.data(using: String.Encoding.utf16, allowLossyConversion: false) else { return nil }
        guard let html = try? NSMutableAttributedString(
            data: data,
            options: [NSAttributedString.DocumentReadingOptionKey.documentType: NSAttributedString.DocumentType.html],
            documentAttributes: nil) else { return nil }
        return html
    }
    
    func deleteHTMLTag(tag: String)-> String{
        let str = tag.replacingOccurrences(of: "<[^>]+>", with: " ", options: String.CompareOptions.regularExpression, range: nil)
        let finalstr = str.replacingOccurrences(of: "&[^;]+;", with: "", options: String.CompareOptions.regularExpression, range: nil)
        return finalstr
    }
    
    func condenseWhitespace() -> String {
        let components = self.components(separatedBy: .whitespacesAndNewlines)
        return components.filter { !$0.isEmpty }.joined(separator: " ")
    }
    
    var isInt: Bool {
        return Int(self) != nil
    }
    public func isValidPassword() -> Bool {
        let passwordRegex = "^(?=.*[a-z])(?=.*\\d)(?=.*[d$@$!%*?&#])[A-Za-z\\dd$@$!%*?&#]{8,}"//"^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z!@#$%^&*()\\-_=+{}|?>.<,:;~`’]{6,}$"
        return NSPredicate(format: "SELF MATCHES %@", passwordRegex).evaluate(with: self)
    }
    
    func isValidDouble(maxDecimalPlaces: Int) -> Bool {
      // Use NumberFormatter to check if we can turn the string into a number
      // and to get the locale specific decimal separator.
      let formatter = NumberFormatter()
      formatter.allowsFloats = true // Default is true, be explicit anyways
      let decimalSeparator = formatter.decimalSeparator ?? "."  // Gets the locale specific decimal separator. If for some reason there is none we assume "." is used as separator.

      // Check if we can create a valid number. (The formatter creates a NSNumber, but
      // every NSNumber is a valid double, so we're good!)
      if formatter.number(from: self) != nil {
        // Split our string at the decimal separator
        let split = self.components(separatedBy: decimalSeparator)

        // Depending on whether there was a decimalSeparator we may have one
        // or two parts now. If it is two then the second part is the one after
        // the separator, aka the digits we care about.
        // If there was no separator then the user hasn't entered a decimal
        // number yet and we treat the string as empty, succeeding the check
        let digits = split.count == 2 ? split.last ?? "" : ""

        // Finally check if we're <= the allowed digits
        return digits.count <= maxDecimalPlaces    // TODO: Swift 4.0 replace with digits.count, YAY!
      }

      return false // couldn't turn string into a valid number
    }
    
}

extension URL {
    func valueOf(_ queryParamaterName: String) -> String? {
        guard let url = URLComponents(string: self.absoluteString) else { return nil }
        return url.queryItems?.first(where: { $0.name == queryParamaterName })?.value
    }
}

public extension UIImage {
    convenience init?(color: UIColor, size: CGSize = CGSize(width: 1, height: 1)) {
        let rect = CGRect(origin: .zero, size: size)
        UIGraphicsBeginImageContextWithOptions(rect.size, false, 0.0)
        color.setFill()
        UIRectFill(rect)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        guard let cgImage = image?.cgImage else { return nil }
        self.init(cgImage: cgImage)
    }
}
extension UISearchBar {
    
    func change(textFont : UIFont?) {
        
        for view : UIView in (self.subviews[0]).subviews {
            
            if let textField = view as? UITextField {
                textField.font = textFont
            }
        }
    }
    
}

extension UIButton {
    
    func pulsate() {
        
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 0.3
        pulse.fromValue = 0.95
        pulse.toValue = 1.0
        pulse.autoreverses = true
        pulse.repeatCount = 2
        pulse.initialVelocity = 0.5
        pulse.damping = 1.0
        
        layer.add(pulse, forKey: nil)
    }
}

extension UILabel {
    
    /// Will auto resize the contained text to a font size which fits the frames bounds.
    /// Uses the pre-set font to dynamically determine the proper sizing
    func fitTextToBounds() {
        guard let text = text, let currentFont = font else { return }
        
        let bestFittingFont = UIFont.bestFittingFont(for: text, in: bounds, fontDescriptor: currentFont.fontDescriptor, additionalAttributes: basicStringAttributes)
        font = bestFittingFont
    }
    
    func fitTextToBoundsWorkItem() {
        guard let text = text, let currentFont = font else { return }
        
        let bestFittingFont = UIFont.bestFittingFontWorkItem(for: text, in: bounds, fontDescriptor: currentFont.fontDescriptor, additionalAttributes: basicStringAttributes)
        font = bestFittingFont
    }
    
    private var basicStringAttributes: [NSAttributedString.Key: Any] {
        var attribs = [NSAttributedString.Key: Any]()
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = self.textAlignment
        paragraphStyle.lineBreakMode = self.lineBreakMode
        attribs = [NSAttributedString.Key.paragraphStyle: paragraphStyle] as [NSAttributedString.Key : Any]
        
        return attribs
    }
    
    func underline() {
        if let textString = self.text {
            let attributedString = NSMutableAttributedString(string: textString)
            attributedString.addAttribute(NSAttributedString.Key.underlineStyle, value: NSUnderlineStyle.double.rawValue, range: NSRange(location: 0, length: attributedString.length))
            attributedText = attributedString
            
//            let attributedString = NSMutableAttributedString(string: textString)
//            attributedString.addAttribute(NSUnderlineStyleAttributeName, value: NSUnderlineStyle.patternDot.rawValue, range: NSRange(location: 0, length: attributedString.length))
//            attributedText = attributedString
        }
    }
}

extension UIFont {
    
    /**
     Will return the best font conforming to the descriptor which will fit in the provided bounds.
     */
    static func bestFittingFontSizeWorkItem(for text: String, in bounds: CGRect, fontDescriptor: UIFontDescriptor, additionalAttributes: [NSAttributedString.Key: Any]? = nil) -> CGFloat {
        let constrainingDimension = min(bounds.width, bounds.height)
        let properBounds = CGRect(origin: .zero, size: bounds.size)
        var attributes = additionalAttributes ?? [:]
        
        let infiniteBounds = CGSize(width: CGFloat.infinity, height: CGFloat.infinity)
        var bestFontSize: CGFloat = constrainingDimension
        
        for fontSize in stride(from: bestFontSize, through: 0, by: -1) {
            let newFont = UIFont(descriptor: fontDescriptor, size: fontSize)
            attributes = [NSAttributedString.Key.font:newFont] as [NSAttributedString.Key : Any]
            
//            let currentFrame = NSString(string: text).boundingRect(with: infiniteBounds, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: [NSAttributedString.Key.font:self], context: nil) // text.boundingRect(with: infiniteBounds, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: convertToOptionalNSAttributedStringKeyDictionary(attributes as [NSAttributedString.Key : Any]), context: nil)
            let currentFrame = NSString(string: text).boundingRect(with: infiniteBounds, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attributes, context: nil) // text.boundingRect(with: infiniteBounds, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: convertToOptionalNSAttributedStringKeyDictionary(attributes as [NSAttributedString.Key : Any]), context: nil)
            if properBounds.contains(currentFrame) {
                bestFontSize = fontSize - 2
                break
            }
        }
        return bestFontSize
    }
    
    static func bestFittingFontSize(for text: String, in bounds: CGRect, fontDescriptor: UIFontDescriptor, additionalAttributes: [NSAttributedString.Key: Any]? = nil) -> CGFloat {
            let constrainingDimension = min(bounds.width, bounds.height)
            let properBounds = CGRect(origin: .zero, size: bounds.size)
            var attributes = additionalAttributes ?? [:]
            
            let infiniteBounds = CGSize(width: CGFloat.infinity, height: CGFloat.infinity)
            var bestFontSize: CGFloat = constrainingDimension
            
            for fontSize in stride(from: bestFontSize, through: 0, by: -1) {
                let newFont = UIFont(descriptor: fontDescriptor, size: fontSize)
                attributes = [NSAttributedString.Key.font:newFont] as [NSAttributedString.Key : Any]
                
    //            let currentFrame = NSString(string: text).boundingRect(with: infiniteBounds, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: [NSAttributedString.Key.font:self], context: nil) // text.boundingRect(with: infiniteBounds, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: convertToOptionalNSAttributedStringKeyDictionary(attributes as [NSAttributedString.Key : Any]), context: nil)
                let currentFrame = NSString(string: text).boundingRect(with: infiniteBounds, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attributes, context: nil) // text.boundingRect(with: infiniteBounds, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: convertToOptionalNSAttributedStringKeyDictionary(attributes as [NSAttributedString.Key : Any]), context: nil)
                if properBounds.contains(currentFrame) {
                    bestFontSize = fontSize
                    break
                }
            }
            return bestFontSize
        }
    
    static func bestFittingFont(for text: String, in bounds: CGRect, fontDescriptor: UIFontDescriptor, additionalAttributes: [NSAttributedString.Key: Any]? = nil) -> UIFont {
        let bestSize = bestFittingFontSize(for: text, in: bounds, fontDescriptor: fontDescriptor, additionalAttributes: additionalAttributes)
        return UIFont(descriptor: fontDescriptor, size: bestSize)
    }
    
    static func bestFittingFontWorkItem(for text: String, in bounds: CGRect, fontDescriptor: UIFontDescriptor, additionalAttributes: [NSAttributedString.Key: Any]? = nil) -> UIFont {
        let bestSize = bestFittingFontSizeWorkItem(for: text, in: bounds, fontDescriptor: fontDescriptor, additionalAttributes: additionalAttributes)
        return UIFont(descriptor: fontDescriptor, size: bestSize)
    }
    
    var isItalic: Bool
    {
        return fontDescriptor.symbolicTraits.contains(.traitItalic)
    }
    
    func setItalic()-> UIFont
    {
        var fontDescriptorVar: UIFontDescriptor
        var symTraits = fontDescriptor.symbolicTraits
        symTraits.insert([.traitItalic])
        
        if(isItalic) {
            return self
        }
        else
        {
            fontDescriptorVar = UIFontDescriptor().withSymbolicTraits(symTraits)!
        }
        return UIFont(descriptor: fontDescriptorVar, size: pointSize)
    }
}

extension UIView {
    func hideWithAnimation(hidden: Bool) {
        UIView.transition(with: self, duration: 0.5, options: .transitionCrossDissolve, animations: {
            self.isHidden = hidden
        })
    }
    
    func hideWithCustomAnimation(animation: UIView.AnimationOptions, hidden: Bool) {
        UIView.transition(with: self, duration: 3, options: animation, animations: {
            self.isHidden = hidden
        })
    }
}

extension Bundle {
    var displayName: String? {
        return object(forInfoDictionaryKey: "CFBundleDisplayName") as? String
    }
}

extension UIColor {
    static var random: UIColor {
        return UIColor(red: .random(in: 0...1),
                       green: .random(in: 0...1),
                       blue: .random(in: 0...1),
                       alpha: 1.0)
    }
}

extension Array {
    func unique<T:Hashable>(map: ((Element) -> (T)))  -> [Element] {
        var set = Set<T>() //the unique list kept in a Set for fast retrieval
        var arrayOrdered = [Element]() //keeping the unique list of elements but ordered
        for value in self {
            if !set.contains(map(value)) {
                set.insert(map(value))
                arrayOrdered.append(value)
            }
        }
        
        return arrayOrdered
    }
}

extension RangeReplaceableCollection where Indices: Equatable {
    mutating func rearrange(from: Index, to: Index) {
        precondition(from != to && indices.contains(from) && indices.contains(to), "invalid indices")
        insert(remove(at: from), at: to)
    }
}

extension UIScrollView {
    
    // Exposes a _refreshControl property to iOS versions anterior to iOS 10
    // Use _refreshControl and refreshControl intercheangeably in a UIScrollView (get + set)
    //
    // All iOS versions: `bounces` is always required if `contentSize` is smaller than `frame`
    // Pre iOS 10 versions: `alwaysBounceVertical` is also required for small content
    // Only iOS 10 allows the refreshControl to work without drifting when pulled to refresh
    var _refreshControl : UIRefreshControl? {
        get {
            if #available(iOS 10.0, *) {
                return refreshControl
            } else {
                return subviews.first(where: { (view: UIView) -> Bool in
                    view is UIRefreshControl
                }) as? UIRefreshControl
            }
        }
        
        set {
            if #available(iOS 10.0, *) {
                refreshControl = newValue
            } else {
                // Unique instance of UIRefreshControl added to subviews
                if let oldValue = _refreshControl {
                    oldValue.removeFromSuperview()
                }
                if let newValue = newValue {
                    insertSubview(newValue, at: 0)
                }
            }
        }
    }
    
    // Creates and adds a UIRefreshControl to this UIScrollView
    func addRefreshControl(target: Any?, action: Selector) -> UIRefreshControl {
        let control = UIRefreshControl()
        addRefresh(control: control, target: target, action: action)
        return control
    }
    
    // Adds the UIRefreshControl passed as parameter to this UIScrollView
    func addRefresh(control: UIRefreshControl, target: Any?, action: Selector) {
        if #available(iOS 9.0, *) {
            control.addTarget(target, action: action, for: .primaryActionTriggered)
        } else {
            control.addTarget(target, action: action, for: .valueChanged)
        }
        _refreshControl = control
    }
}

extension CALayer {
    
    public func shadow() {
        shadowColor = UIColor.gray.cgColor
        shadowOffset = CGSize(width: 4.0, height: 4.0)
        shadowOpacity = 0.2
        shadowRadius = 1
        masksToBounds = false
        
    }
    
    public func circleshadow(myview: UIView) {
        let shadowSize :CGFloat = 3.0
        let shadowmyPath = UIBezierPath(rect: CGRect(x: -shadowSize/2, y: 0, width: myview.frame.size.width+shadowSize, height: myview.frame.size.height+shadowSize))
        masksToBounds = false
        shadowColor = UIColor.darkGray.cgColor
        shadowOffset = CGSize(width: 3.0, height: -3.0)
        shadowOpacity = 0.3
        shadowRadius = 17//myview.layer.cornerRadius
        shadowPath = shadowmyPath.cgPath
    }
    
    public func shadowBottom() {
        shadowColor = UIColor.gray.cgColor
        shadowOffset = CGSize(width: 0.0, height: 4.0)
        shadowOpacity = 0.2
        shadowRadius = 1
        masksToBounds = false
        
    }
    public func shadowThreeSide(myview: UIView) {
        let shadowSize :CGFloat = 5.0
        let shadowmyPath = UIBezierPath(rect: CGRect(x: -shadowSize/2, y: 0, width: myview.frame.size.width+shadowSize, height: myview.frame.size.height+shadowSize))
        masksToBounds = false
        shadowColor = UIColor.darkGray.cgColor
        shadowOffset = CGSize(width: 0.0, height: 0.0)
        shadowOpacity = 0.2
        shadowRadius = 4
        shadowPath = shadowmyPath.cgPath
    
    }
    
    
    func addBorder(edge: UIRectEdge, color: UIColor, thickness: CGFloat) {
        
        let border = CALayer();
        
        switch edge {
        case UIRectEdge.top:
            border.frame = CGRect(x: 0, y: 0, width: self.frame.width, height: thickness)
            break
        case UIRectEdge.bottom:
            border.frame = CGRect(x:0, y:self.frame.height - thickness, width:self.frame.width, height:thickness)
            break
        case UIRectEdge.left:
            border.frame = CGRect(x:0, y:0, width: thickness, height: self.frame.height)
            break
        case UIRectEdge.right:
            border.frame = CGRect(x:self.frame.width - thickness, y: 0, width: thickness, height:self.frame.height)
            break
        default:
            break
        }
        
        border.backgroundColor = color.cgColor;
        
        self.addSublayer(border)
    }
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromNSAttributedStringKey(_ input: NSAttributedString.Key) -> String {
	return input.rawValue
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToOptionalNSAttributedStringKeyDictionary(_ input: [String: Any]?) -> [NSAttributedString.Key: Any]? {
	guard let input = input else { return nil }
	return Dictionary(uniqueKeysWithValues: input.map { key, value in (NSAttributedString.Key(rawValue: key), value)})
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromNSAttributedStringDocumentAttributeKey(_ input: NSAttributedString.DocumentAttributeKey) -> String {
	return input.rawValue
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromNSAttributedStringDocumentType(_ input: NSAttributedString.DocumentType) -> String {
	return input.rawValue
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToNSAttributedStringDocumentReadingOptionKeyDictionary(_ input: [String: Any]) -> [NSAttributedString.DocumentReadingOptionKey: Any] {
	return Dictionary(uniqueKeysWithValues: input.map { key, value in (NSAttributedString.DocumentReadingOptionKey(rawValue: key), value)})
}
