//
//  VCExtension.swift
//  Etherio
//
//  Created by Sanjaysinh Chauhan on 10/10/16.
//  Copyright © 2016 Sanjaysinh Chauhan. All rights reserved.
//

import Foundation
import UIKit

public extension UIViewController {
    
    public func addBackButtonInNavigationBar(){
        
        let imgback = UIImage(named: "back")
        
        self.addLeftButtonInNavigationBar(imgLeftbarBtn: imgback! , action: #selector(backTapped(sender:)))
        
    }
    
    

    public func addLeftButtonInNavigationBar (imgLeftbarBtn : UIImage ,action : Selector){
        let back = UIBarButtonItem(image: imgLeftbarBtn , style: UIBarButtonItem.Style.plain, target: self, action:action)
        
        self.navigationItem.leftBarButtonItem = back
    }
    
    @objc public func backTapped(sender : AnyObject){
        
        self.navigationController!.popViewController(animated: true)
        
    }
    
    public func menuTapped(sender : AnyObject){
        
        //self.sideMenuViewController.presentLeftMenuViewController()
    }
    
    
    
    public func addRightButtonInNavigationBar (imgRightbarBtn : UIImage){
        let rightButton = UIBarButtonItem(image: imgRightbarBtn , style: UIBarButtonItem.Style.plain, target: self, action:#selector(rightButtonTapped(sender:)))
        
        self.navigationItem.rightBarButtonItem = rightButton
    }
  
    public func removeRightBarButtonInNavigationBar () {
        self.navigationItem.rightBarButtonItem = nil
    }

    @objc public func rightButtonTapped(sender : AnyObject){
        
        
    }
    
    
    //For MWPhotobroser
    public func addDissmissButtom(){
        
        let imgback = UIImage(named: "back")
        
        self.addLeftButtonInNavigationBar(imgLeftbarBtn: imgback! , action: #selector(dissmissTapped(sender:)))
        
    }
    @objc public func dissmissTapped(sender : AnyObject){
            
            self.dismiss(animated: true, completion: nil)
            
        }
}
