
//  Created by dip Kasyap on 2/17/16.
//  Copyright © 2016 Esig. All rights reserved.

import UIKit

@IBDesignable class DGSegmentedControl: UIControl {
    
    private var labels = [UILabel]()
    
    var thumbView = UIView()
    var underLine = UIView()
    
    var items: [String] = ["Item 1", "Item 2"] {
        didSet {
            setupLabels()
        }
    }
    
    var selectedIndex : Int = 0 {
        didSet {
            displayNewSelectedIndex()
        }
    }
    
    @IBInspectable var selectedLabelColor : UIColor = UIColor.white {
        didSet {
            setSelectedColors()
        }
    }
    
    @IBInspectable var unselectedLabelColor : UIColor = UIColor.black {
        didSet {
            setSelectedColors()
        }
    }
    
    @IBInspectable var thumbColor : UIColor = UIColor(red: 0.961, green: 0.831, blue: 0.243, alpha: 1.00) {
        didSet {
            setSelectedColors()
        }
    }
    
    @IBInspectable var borderColor2 : UIColor = UIColor(red: 0.788, green: 0.788, blue: 0.788, alpha: 1.00) {
        didSet {
            self.setUnderline(ofColor: borderColor, andSize: borderSize)
        }
    }
    
    @IBInspectable var font : UIFont! = UIFont.systemFont(ofSize: 12) {
        didSet {
            setFont()
        }
    }
    
    @IBInspectable var borderSize:CGFloat = 1.0 {
        didSet {
            self.setUnderline(ofColor: borderColor, andSize: borderSize)
        }
    }
    
    @IBInspectable var thumUnderLineSize:CGFloat = 10 {
        didSet {
            self.layoutSubviews()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupView()
    }
    
    required init(coder: NSCoder) {
        super.init(coder: coder)!
        setupView()
    }
    
    func setupView(){
        backgroundColor = UIColor.clear
        setupLabels()
        addIndividualItemConstraints(items: labels, mainView: self, padding: 0)
        insertSubview(thumbView, at: 0)
    }
    
    func setBorder(){
        self.setUnderline(ofColor: borderColor, andSize: borderSize)
    }
    
    func setupLabels(){
        
        for label in labels {
            label.removeFromSuperview()
        }
        
        labels.removeAll(keepingCapacity: true)
        
        for index in 1...items.count {
            
            let label = UILabel(frame:CGRect(x: 0, y: 5, width: 70, height: 40))
            label.text = items[index - 1]
            label.backgroundColor = UIColor.clear
            label.textAlignment = .center
            label.font = UIFont(name: "Gotham-Book", size: 12)
            label.textColor = index == 1 ? selectedLabelColor : unselectedLabelColor
            if (label.text?.contains("Not Started"))! || (label.text?.contains("Open"))! {
                label.textColor = UIColor.red
            }
            if (label.text?.contains("Completed"))! || (label.text?.contains("Close"))! {
                label.textColor = theme_color
            }
            if (label.text?.contains("In Progress"))! || (label.text?.contains("On Hold"))! || (label.text?.contains("Overdue"))!{
                label.textColor = segmentOrange
            }
            label.translatesAutoresizingMaskIntoConstraints = false
            self.addSubview(label)
            labels.append(label)
        }
        
        addIndividualItemConstraints(items: labels, mainView: self, padding: 0)
    }
    
    func setupLabelsForRoadblock(){
        
        for label in labels {
            label.removeFromSuperview()
        }
        
        labels.removeAll(keepingCapacity: true)
        
        for index in 1...items.count {
            
            let label = UILabel(frame:CGRect(x: 0, y: 5, width: 70, height: 40))
            label.text = items[index - 1]
            label.backgroundColor = UIColor.clear
            label.textAlignment = .center
            label.font = UIFont(name: "Gotham-Book", size: 12)
            label.textColor = index == 0 ? selectedLabelColor : unselectedLabelColor
            if (label.text?.contains("is being blocked by"))! {
                label.textColor = UIColor.red
            }
            if (label.text?.contains("is blocking"))! {
                label.textColor = segmentOrange
            }
            label.translatesAutoresizingMaskIntoConstraints = false
            self.addSubview(label)
            labels.append(label)
        }
        
        addIndividualItemConstraints(items: labels, mainView: self, padding: 0)
    }
    
    func setupLabelsforWorkBoard(){
        
        for label in labels {
            label.removeFromSuperview()
        }
        
        labels.removeAll(keepingCapacity: true)
        
        for index in 1...items.count {
            
            let label = UILabel(frame:CGRect(x: 0, y: 5, width: 70, height: self.frame.height))
            label.numberOfLines = 0
            label.text = items[index - 1]
            label.backgroundColor = UIColor.white
            label.textAlignment = .center
            label.font = UIFont(name: "Gotham-Book", size: 12)
            label.textColor = index == 1 ? selectedLabelColor : unselectedLabelColor
            label.translatesAutoresizingMaskIntoConstraints = false
            self.addSubview(label)
            labels.append(label)
        }
        
        addIndividualItemConstraints(items: labels, mainView: self, padding: 0)
    }
    
    func setupLabelsForTicket(){
        
        for label in labels {
            label.removeFromSuperview()
        }
        
        labels.removeAll(keepingCapacity: true)
        
        for index in 1...items.count {
            
            let label = UILabel(frame:CGRect(x: 0, y: 5, width: 70, height: 40))
            label.text = items[index - 1]
            label.backgroundColor = UIColor.clear
            label.textAlignment = .center
            label.font = UIFont(name: "Gotham-Book", size: 12)
            //label.textColor = index == 1 ? selectedLabelColor : unselectedLabelColor
            if (label.text?.contains("Open"))!{
                label.textColor = UIColor.red
            }
            if (label.text?.contains("Close"))!{
                label.textColor = theme_color
            }
            if (label.text?.contains("On Hold"))!{
                label.textColor = segmentOrange
            }
            label.translatesAutoresizingMaskIntoConstraints = false
            self.addSubview(label)
            labels.append(label)
        }
        addIndividualItemConstraints(items: labels, mainView: self, padding: 0)
    }
    
    func setViewForLabel(label: UILabel) {
        var oldFrame = label.bounds
        let newWidth = oldFrame.width - 50
        oldFrame.size.width = newWidth
        label.frame = oldFrame
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        var selectFrame = self.bounds
        let newWidth = selectFrame.width / CGFloat(items.count)
        selectFrame.size.width = newWidth
        thumbView.frame = selectFrame
        thumbView.backgroundColor = thumbColor
        displayNewSelectedIndex()
        
    }
    
    override func beginTracking(_ touch: UITouch, with event: UIEvent?) -> Bool {
        
        let location = touch.location(in: self)
        
        var calculatedIndex : Int?
        for (index, item) in labels.enumerated() {
            if item.frame.contains(location) {
                calculatedIndex = index
            }
        }
        
        
        if calculatedIndex != nil {
            selectedIndex = calculatedIndex!
            sendActions(for: .valueChanged)
        }
        
        return false
    }
    
    func displayNewSelectedIndex(){
        for (_, item) in labels.enumerated() {
            item.textColor = unselectedLabelColor
            if (item.text?.contains("Not Started"))! || (item.text?.contains("Open"))! {
                item.textColor = UIColor.red
            }
            if (item.text?.contains("Completed"))! || (item.text?.contains("Close"))! {
                item.textColor = theme_color
            }
            if (item.text?.contains("In Progress"))! || (item.text?.contains("On Hold"))! || (item.text?.contains("Overdue"))! {
                item.textColor = segmentOrange
            }
            
        }
        
        let label = labels[selectedIndex]
        label.textColor = selectedLabelColor
        if (label.text?.contains("Not Started"))! || (label.text?.contains("Open"))! {
            label.textColor = UIColor.red
        }
        if (label.text?.contains("Completed"))! || (label.text?.contains("Close"))! {
            label.textColor = theme_color
        }
        if (label.text?.contains("In Progress"))! || (label.text?.contains("On Hold"))! || (label.text?.contains("Overdue"))! {
            label.textColor = segmentOrange
        }
        UIView.animate(withDuration: 0.5, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.8, options: UIView.AnimationOptions.allowAnimatedContent, animations: {
            
            var newFrame = label.frame
            newFrame.origin.y = newFrame.height-self.thumUnderLineSize
            newFrame.size.height = self.thumUnderLineSize
            
            self.thumbView.frame = newFrame //label.frame
            
            }, completion: nil)
    }
    
    func addIndividualItemConstraints(items: [UIView], mainView: UIView, padding: CGFloat) {
        
        for (index, button) in items.enumerated() {
            
            let topConstraint = NSLayoutConstraint(item: button, attribute: NSLayoutConstraint.Attribute.top, relatedBy: NSLayoutConstraint.Relation.equal, toItem: mainView, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1.0, constant: 0)
            
            let bottomConstraint = NSLayoutConstraint(item: button, attribute: NSLayoutConstraint.Attribute.bottom, relatedBy: NSLayoutConstraint.Relation.equal, toItem: mainView, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1.0, constant: 0)
            
            var rightConstraint : NSLayoutConstraint!
            
            if index == items.count - 1 {
                
                rightConstraint = NSLayoutConstraint(item: button, attribute: NSLayoutConstraint.Attribute.right, relatedBy: NSLayoutConstraint.Relation.equal, toItem: mainView, attribute: NSLayoutConstraint.Attribute.right, multiplier: 1.0, constant: -padding)
                
            }else{
                
                let nextButton = items[index+1]
                rightConstraint = NSLayoutConstraint(item: button, attribute: NSLayoutConstraint.Attribute.right, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nextButton, attribute: NSLayoutConstraint.Attribute.left, multiplier: 1.0, constant: -padding)
            }
            
            
            var leftConstraint : NSLayoutConstraint!
            
            if index == 0 {
                
                leftConstraint = NSLayoutConstraint(item: button, attribute: NSLayoutConstraint.Attribute.left, relatedBy: NSLayoutConstraint.Relation.equal, toItem: mainView, attribute: NSLayoutConstraint.Attribute.left, multiplier: 1.0, constant: padding)
                
            }else{
                
                let prevButton = items[index-1]
                leftConstraint = NSLayoutConstraint(item: button, attribute: NSLayoutConstraint.Attribute.left, relatedBy: NSLayoutConstraint.Relation.equal, toItem: prevButton, attribute: NSLayoutConstraint.Attribute.right, multiplier: 1.0, constant: padding)
                
                let firstItem = items[0]
                
                let widthConstraint = NSLayoutConstraint(item: button, attribute: .width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: firstItem, attribute: .width, multiplier: 1.0  , constant: 0)
                
                mainView.addConstraint(widthConstraint)
            }
            
            mainView.addConstraints([topConstraint, bottomConstraint, rightConstraint, leftConstraint])
        }
    }
    
    func setSelectedColors(){
        for item in labels {
            item.textColor = unselectedLabelColor
            if (item.text?.contains("Not Started"))! || (item.text?.contains("Open"))! {
                item.textColor = UIColor.red
            }
            if (item.text?.contains("Completed"))! || (item.text?.contains("Close"))! {
                item.textColor = theme_color
            }
            if (item.text?.contains("In Progress"))! || (item.text?.contains("On Hold"))! || (item.text?.contains("Overdue"))! {
                item.textColor = segmentOrange
            }
        }
        
        if labels.count > 0 {
            labels[0].textColor = selectedLabelColor
            if (labels[0].text?.contains("Not Started"))! || (labels[0].text?.contains("Open"))! {
                labels[0].textColor = UIColor.red
            }
            if (labels[0].text?.contains("Completed"))! || (labels[0].text?.contains("Close"))! {
                labels[0].textColor = theme_color
            }
            if (labels[0].text?.contains("In Progress"))! || (labels[0].text?.contains("On Hold"))! || (labels[0].text?.contains("Overdue"))! {
                labels[0].textColor = segmentOrange
            }
        }
        
        thumbView.backgroundColor = thumbColor
    }
    
    func setFont(){
        for item in labels {
            item.font = font
        }
    }
}

extension UIView {
    
    func setUnderline(ofColor color:UIColor, andSize sized:CGFloat){
        //Making UnderLIne BOrder on UitextFld
        let underLine = CALayer()
        underLine.frame = CGRect(x: 0, y: self.frame.size.height-1, width: self.frame.size.width, height: sized)
        underLine.backgroundColor = color.cgColor
        self.layer.addSublayer(underLine)
    }
    
}
