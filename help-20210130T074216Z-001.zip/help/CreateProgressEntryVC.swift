//
//  CreateProgressEntryVC.swift
//  WorkInProgress
//
//  Created by AONMac on 17/04/18.
//  Copyright © 2018 Arpit Shah. All rights reserved.
//

import UIKit
import ObjectMapper
import ZAlertView
import SDWebImage
import SAMTextView
import IQKeyboardManagerSwift
import WebKit
class CreateProgressEntryVC: UIViewController, UITableViewDelegate, UITableViewDataSource , UITextViewDelegate,WKUIDelegate,WKNavigationDelegate{

    
    @IBOutlet var iPhoneXHeight: NSLayoutConstraint!
    
    @IBOutlet weak var lblHeader: UILabel!
    @IBOutlet weak var lblHeaderName: UILabel!
    
    @IBOutlet weak var imguser: UIImageView!
    
    @IBOutlet weak var imguser2: UIImageView!
    
    @IBOutlet weak var lblUserInitials: UILabel!
    
    @IBOutlet weak var lblUserInitials2: UILabel!
    
    @IBOutlet weak var lblApprovalDate: UILabel!
    
    @IBOutlet weak var approvalHrs: UILabel!
    
    @IBOutlet weak var approvalTime: UILabel!
    
    @IBOutlet weak var userDetailView: UIView!
    
    @IBOutlet weak var userDetailApprovalView: UIView!
    
    @IBOutlet weak var pickerView: UIView!
    
    @IBOutlet weak var rejectionView: UIView!
    
    @IBOutlet weak var txtReason: SAMTextView!
    
    
    @IBOutlet weak var imgPlus: UIImageView!
    
    @IBOutlet weak var btnPlus: UIButton!
    
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var lblInTime: UILabel!
    
    @IBOutlet weak var lblOutTime: UILabel!
    
    @IBOutlet weak var lblRemainingHrs: UILabel!
    
    @IBOutlet weak var lblTotalHrs: UILabel!
    
    @IBOutlet weak var tblprogressEntry: UITableView!
    
    @IBOutlet weak var btnGetPE: UIButton!
    
    @IBOutlet weak var approvalView: UIView!
    
    @IBOutlet weak var btnApprove: UIButton!
    

    @IBOutlet weak var btnApproveMessage: UIButton!
    
    @IBOutlet weak var btnMessageDone: UIButton!
    
    @IBOutlet weak var lblMsgBoxTitle: UILabel!
    
    @IBOutlet weak var lblStatus: UILabel!
    
    @IBOutlet weak var lblApprovalStatus: UILabel!
    
    @IBOutlet weak var btnSubmit: UIButton!
    
    @IBOutlet weak var btnPEApproval: UIButton!
    
    @IBOutlet weak var btnAddProgressEntry: UIButton!
    
    @IBOutlet weak var selectionBgView: UIView!
    
    @IBOutlet weak var myPickerView: UIDatePicker!
    
    @IBOutlet weak var btnDone: UIButton!
    
    @IBOutlet weak var viewGetSubmission: UIView!
    
    @IBOutlet weak var btnGetPESave: UIButton!
    @IBOutlet weak var btnGetPESubmit: UIButton!
    
    let formatter = DateFormatter()
    var ProgressEntryDate = String()
    var isapproved = Int()
    var timesheetID = Int()
    var Intime = String()
    var Outtime = String()
    var workdate = String()
    var remainingHrs = String()
    var totalHrs = String()
    var setRowNO = Int()
    var totalApprovePE : Int = 0
    var setDateFrom = String()
    var setUserContactID = Int()
    var getUserContactID = String()
    var setIsFromApproval : Bool = false
    var leveltype = true // Next level
    var userImg = String()
    var tag = Int()
    var taskID : String = ""
    var arraytimesheetlineitemmodel = [ProgressEntryTimeSheetLineItemModel]()
    var arrayProgressEntryTask = [ProgressEntryTaskModel]()
    var arrayProgressEntryEditedTask = [ProgressEntryTaskModel]()
    var arrayProgressEntryTimesheet = [ProgressEntryTimeSheetModel]()
    var ProgressEntryUserInfo = ProgressEntryUserInfoModel()
    var objTimesheetTaskModel : ProgressEntryTaskModel?
    
        
    override func viewDidLoad() {
        super.viewDidLoad()

        if iphoneX == false {
            iPhoneXHeight.constant = 0
        }
    
        self.setDefaultValue()
        self.fetchPEData()
    }

    override func viewWillAppear(_ animated: Bool) {
        if UserDefaults.standard.bool(forKey: "isFromEditPE") {
            if UserDefaults.standard.bool(forKey: "isSavedPE") {
                UserDefaults.standard.set(false, forKey: "isFromEditPE")
                UserDefaults.standard.set(false, forKey: "isSavedPE")
                imgPlus.isHidden = false
                btnPlus.isHidden = false
                self.approvalView.isHidden = true
                
                self.getProgressEntries(currentDate: mydate(),userID: self.getcurrentUSERID())
            }
            else {
                // Load Data in Table
                if self.arrayProgressEntryEditedTask.count >= 1 {
                    CommonFunctions().animate()
                    if self.arrayProgressEntryTask.count >= 1 {
                        for i in 0..<self.arrayProgressEntryEditedTask.count {
                            let newTask = self.arrayProgressEntryEditedTask[i]
                            for j in 0..<self.arrayProgressEntryTask.count {
                                let oldTask = self.arrayProgressEntryTask[j]
                                if oldTask.tASKID == newTask.tASKID {
                                    self.arrayProgressEntryTask[j] = newTask
                                    break
                                }
                                else {
                                    if let foo = self.arrayProgressEntryTask.enumerated().first(where: {$0.element.tASKID == newTask.tASKID}) {
                                        if foo.element.tASKID == newTask.tASKID {
                                            self.arrayProgressEntryTask[foo.offset] = newTask
                                            break
                                        }
                                        else {
                                            self.arrayProgressEntryTask.append(newTask)
                                            break
                                        }
                                    }
                                    else {
                                        self.arrayProgressEntryTask.append(newTask)
                                        break
                                    }
                                }
                            }
                        }
                    }
                    else {
                        self.arrayProgressEntryTask = self.arrayProgressEntryEditedTask
                    }
                    
                    if self.arrayProgressEntryTask.count >= 1 {
                        self.btnAddProgressEntry.isHidden = true
                        self.setGetProgressEntryHours()
                        
                        self.viewGetSubmission.isHidden = false
                        self.tblprogressEntry.reloadData()
                        self.tblprogressEntry.isHidden = false
                        CommonFunctions().stopAnimate()
                    }
                    else {
                        self.setGetProgressEntryHours()
                        self.viewGetSubmission.isHidden = true
                        self.tblprogressEntry.isHidden = true
                        CommonFunctions().stopAnimate()
                    }
                }
            }
        }
        
    }
    
    func setDefaultValue()
    {
        UserDefaults.standard.set(false, forKey: "isFromEditPE")
        UserDefaults.standard.set(false, forKey: "isSavedPE")
        
        self.lblStatus.isHidden = true
        self.approvalView.isHidden = true
        self.userDetailApprovalView.isHidden = true
        self.rejectionView.isHidden = true
        self.btnPEApproval.isHidden = true
        self.lblApprovalStatus.isHidden = true
        self.btnGetPE.backgroundColor = theme_selected_color
        self.btnGetPE.tag = 0
        txtReason.delegate = self
        self.viewGetSubmission.isHidden = true
        btnGetPESave.layer.borderWidth = 1
        btnGetPESubmit.layer.borderWidth = 1
        btnGetPESave.layer.borderColor = theme_selected_color?.cgColor
        btnGetPESubmit.layer.borderColor = theme_selected_color?.cgColor
        btnGetPESave.backgroundColor = theme_selected_color
        btnGetPESubmit.backgroundColor = theme_selected_color
        
        txtReason.contentInset = UIEdgeInsets.init(top: -7.0,left: -3.0,bottom: 0,right: 0.0)
        
        let date = Date()
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        
        let currentdate = formatter.string(from: date)
        lblDate.text = currentdate
        self.workdate = currentdate
        
        lblInTime.text = "- : -"
        lblOutTime.text = "- : -"
        
        lblRemainingHrs.text = "-"
        lblTotalHrs.text = "/ -"
        
        self.selectionBgView.isHidden = true
        self.btnSubmit.isHidden = true
        self.btnAddProgressEntry.isHidden = true
        self.tblprogressEntry.isHidden = true
        self.btnPlus.isUserInteractionEnabled = true
        
        self.addGestureRecognizer()
        IQKeyboardManager.shared.enable = true
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tapToClose(_:)))
        self.selectionBgView.addGestureRecognizer(tapGesture)
        //MARK: Dynamic cell height
        self.tblprogressEntry.rowHeight = UITableView.automaticDimension
        self.tblprogressEntry.estimatedRowHeight = 90
    }
    
    func fetchPEData() {
        
        //MARK: Get progress entry
        if setIsFromApproval == false {
            
            imgPlus.isHidden = false
            btnPlus.isHidden = false
            self.approvalView.isHidden = true
            
            self.getProgressEntries(currentDate: mydate(),userID: self.getcurrentUSERID())
        }
        else {
            
            self.btnPEApproval.isHidden = true
            self.lblApprovalStatus.isHidden = true
            
            self.lblStatus.isHidden = true
            txtReason.isHidden = false
            imgPlus.isHidden = true
            btnPlus.isHidden = true
            self.userDetailView.isHidden = true
            self.userDetailApprovalView.isHidden = false
            self.approvalView.isHidden = false
            self.btnApproveMessage.setTitle(String.fontAwesomeIcon(name: .commenting), for: .normal)
            //fontAwesomeIcon(name: .fileTextO, textColor: theme_color, size: CGSize(width: 30, height: 30))
            self.rejectionView.isHidden = false
            self.pickerView.isHidden = true
            if setRowNO == 0 {
                self.setRowNO = UserDefaults.standard.integer(forKey: "rowNo")
                self.leveltype = UserDefaults.standard.bool(forKey: "levelType")
            }
            self.getApproveProgressEntry(rowno: setRowNO, level: self.leveltype)
        }
    }
    
    //MARK: Get Recorded ProgressEntry
    func getRecordedProgressEntries(currentDate: String,userID: String){
        self.view.isUserInteractionEnabled = false
        self.btnGetPE.isUserInteractionEnabled = false
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        
        let manager = APIManager.apiManager
        
        manager.getDatadicFromUrl(url: "pms/progressentry/" + currentDate + "/recorded" + userID, dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                if let taskDic : NSDictionary = dataResponse as? NSDictionary
                {
                    DispatchQueue.main.async {
                        
                        let taskArray = taskDic.object(forKey: "Tasks") as! NSArray
                        self.arrayProgressEntryTask.removeAll()
                        self.arrayProgressEntryTask = Mapper<ProgressEntryTaskModel>().mapArray(JSONObject: taskArray)!
                        
                        self.view.isUserInteractionEnabled = true
                        self.btnGetPE.isUserInteractionEnabled = true
                        
                        //time and hour
                        if (taskDic.object(forKey: "CompanyOvertime") as? Int) != nil{
                            self.ProgressEntryUserInfo.companyOvertime = (taskDic.object(forKey: "CompanyOvertime") as? Int)!
                        }
                        if (taskDic.object(forKey: "CompanyProductiveHours") as? Double) != nil{
                            self.ProgressEntryUserInfo.CompanyProductiveHours = (taskDic.object(forKey: "CompanyProductiveHours") as? Double)!
                        }
                        if (taskDic.object(forKey: "CompanyWorkHours") as? Double) != nil{
                            self.ProgressEntryUserInfo.CompanyWorkHours = (taskDic.object(forKey: "CompanyWorkHours") as? Double)!
                        }
                        
                        if (taskDic.object(forKey: "InTime") as? String) != nil{
                            self.arrayProgressEntryTimesheet[0].iN_TIME = (taskDic.object(forKey: "InTime") as? String)!
                            
                        }
                        if (taskDic.object(forKey: "OutTime") as? String) != nil{
                            self.arrayProgressEntryTimesheet[0].oUT_TIME = (taskDic.object(forKey: "OutTime") as? String)!
                        }
                        if (taskDic.object(forKey: "WorkStartDate") as? String) != nil{
                            self.arrayProgressEntryTimesheet[0].wORKDATE = (taskDic.object(forKey: "WorkStartDate") as? String)!
                        }
                        
                        self.setGetProgressEntryTime()
                       
                        // User info
                        if (taskDic.object(forKey: "CONTACT_COLOR_CODE") as? String) != nil{
                            self.ProgressEntryUserInfo.colorCode = (taskDic.object(forKey: "CONTACT_COLOR_CODE") as? String)!
                        }
                        
                        if taskDic.object(forKey: "IMAGE_NAME") != nil {
                            if (taskDic.object(forKey: "IMAGE_NAME") as? String) != nil{
                                self.ProgressEntryUserInfo.imageName = (taskDic.object(forKey: "IMAGE_NAME") as? String)!
                            }
                        }
                        
                        if (taskDic.object(forKey: "CONTACT_NAME") as? String) != nil{
                            self.ProgressEntryUserInfo.contactName = (taskDic.object(forKey: "CONTACT_NAME") as? String)!
                        }
                        
                        if (taskDic.object(forKey: "CONTACT_ID") as? Int) != nil{
                            self.ProgressEntryUserInfo.contactId = (taskDic.object(forKey: "CONTACT_ID") as? Int)!
                            self.setUserContactID = self.ProgressEntryUserInfo.contactId
                            self.btnPlus.isUserInteractionEnabled = true
                        }
                        
                        self.setProfile()
                        
                        // Load Data in Table
                        if self.arrayProgressEntryTask.count > 0 {
                            self.btnAddProgressEntry.isHidden = true
                            self.setGetProgressEntryHours()
                            
                            self.viewGetSubmission.isHidden = false
                            self.tblprogressEntry.reloadData()
                            self.tblprogressEntry.isHidden = false
                            CommonFunctions().stopAnimate()
                        
                        }
                        else {
                            DispatchQueue.main.async {
                                self.setGetProgressEntryHours()
                                self.viewGetSubmission.isHidden = true
                                self.tblprogressEntry.isHidden = true
                                CommonFunctions().stopAnimate()
                            }
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    self.view.isUserInteractionEnabled = true
                    self.btnGetPE.isUserInteractionEnabled = true
                    self.viewGetSubmission.isHidden = true
                    CommonFunctions().stopAnimate()
                }
                
            }
            else {
                DispatchQueue.main.async {
                    self.view.isUserInteractionEnabled = true
                    self.btnGetPE.isUserInteractionEnabled = true
                    self.viewGetSubmission.isHidden = true
                    CommonFunctions().stopAnimate()
                }
            }
        }
    }
    
    //MARK: Get saved ProgressEntry
    func getProgressEntries(currentDate: String,userID: String){
        self.view.isUserInteractionEnabled = false
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        
        let manager = APIManager.apiManager
        //currentDate = "2018-03-05"
        manager.getDatadicFromUrl(url: "pms/progressentry/" + currentDate + userID + "/" + taskID, dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                print("Starting api take")
                
                if let taskDic : NSDictionary = dataResponse as? NSDictionary
                {
                    
                    let taskArray = taskDic.object(forKey: "tasks") as! NSArray
                    self.arrayProgressEntryTask.removeAll()
                    self.arrayProgressEntryTask = Mapper<ProgressEntryTaskModel>().mapArray(JSONObject: taskArray)!
                    
                    // Timesheet
                    let timesheetarray = taskDic.object(forKey: "timesheetInfos") as! NSArray
                    
                    self.arrayProgressEntryTimesheet = Mapper<ProgressEntryTimeSheetModel>().mapArray(JSONObject: timesheetarray)!
                    
                    DispatchQueue.main.async {
                        self.view.isUserInteractionEnabled = true
                        self.setTimeSheetData()
                        
                        // User info
                        if (taskDic.object(forKey: "ColorCode") as? String) != nil{
                            self.ProgressEntryUserInfo.colorCode = (taskDic.object(forKey: "ColorCode") as? String)!
                        }
                        
                        if taskDic.object(forKey: "ImageName") != nil {
                            if (taskDic.object(forKey: "ImageName") as? String) != nil{
                                self.ProgressEntryUserInfo.imageName = (taskDic.object(forKey: "ImageName") as? String)!
                            }
                        }
                        
                        if (taskDic.object(forKey: "ContactName") as? String) != nil{
                            self.ProgressEntryUserInfo.contactName = (taskDic.object(forKey: "ContactName") as? String)!
                        }
                        if (taskDic.object(forKey: "CompanyOvertime") as? Int) != nil{
                            self.ProgressEntryUserInfo.companyOvertime = (taskDic.object(forKey: "CompanyOvertime") as? Int)!
                        }
                        if (taskDic.object(forKey: "CompanyProductiveHours") as? Double) != nil{
                            self.ProgressEntryUserInfo.CompanyProductiveHours = (taskDic.object(forKey: "CompanyProductiveHours") as? Double)!
                        }
                        if (taskDic.object(forKey: "CompanyWorkHours") as? Double) != nil{
                            self.ProgressEntryUserInfo.CompanyWorkHours = (taskDic.object(forKey: "CompanyWorkHours") as? Double)!
                        }
                        
                        if (taskDic.object(forKey: "ContactId") as? Int) != nil{
                            self.ProgressEntryUserInfo.contactId = (taskDic.object(forKey: "ContactId") as? Int)!
                            self.setUserContactID = self.ProgressEntryUserInfo.contactId
                            self.btnPlus.isUserInteractionEnabled = true
                        }
                        
                        self.setProfile()
                        
                        if self.objTimesheetTaskModel != nil {
                            if let foo = self.arrayProgressEntryTask.enumerated().first(where: {$0.element.tASKID != self.objTimesheetTaskModel?.tASKID}) {
                                self.arrayProgressEntryTask.append((self.objTimesheetTaskModel)!)
                                self.arrayProgressEntryTask.rearrange(from: self.arrayProgressEntryTask.count - 1, to: 0)
                            }
                            
                        }
                        
                        if self.taskID.count > 0 {
                            if self.arrayProgressEntryTask[0].tASKID == Int(self.taskID) {
                                self.objTimesheetTaskModel = self.arrayProgressEntryTask[0]
                            }
                            
                            CommonFunctions().getPEData(currentDate: self.mydate(), userID: self.getcurrentUSERID(), taskID: Int(self.taskID)!) { (hrs, success) in
                                if success {
                                    self.arrayProgressEntryTask[0].days![0].taskHourMin = hrs
                                    
                                    if self.arrayProgressEntryTask.count > 0 {
                                        
                                        self.btnAddProgressEntry.isHidden = true
                                        
                                        self.tblprogressEntry.reloadData()
                                        self.tblprogressEntry.isHidden = false
                                        CommonFunctions().stopAnimate()
                                        
                                    }
                                    else {
                                        
                                        self.btnAddProgressEntry.isHidden = false
                                        self.tblprogressEntry.isHidden = true
                                        self.btnSubmit.isHidden = true
                                        CommonFunctions().stopAnimate()
                                    }
                                    
                                }
                            }
                            self.taskID = ""
                        }
                        
                        // Load Data in Table
                        if self.arrayProgressEntryTask.count > 0 {
                            
                            
                            self.btnAddProgressEntry.isHidden = true
                            
                           
                            
                            //DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: {
                                //RunLoop.current.run(until: Date.init(timeIntervalSinceNow: 1))
                                self.tblprogressEntry.reloadData()
                                self.tblprogressEntry.isHidden = false
                                CommonFunctions().stopAnimate()
                            //})
                        }
                        else {
                            
                            self.btnAddProgressEntry.isHidden = false
                            self.tblprogressEntry.isHidden = true
                            self.btnSubmit.isHidden = true
                            CommonFunctions().stopAnimate()
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    self.view.isUserInteractionEnabled = true
                    CommonFunctions().stopAnimate()
                }
                self.taskID = ""
            }
            else {
                DispatchQueue.main.async {
                    self.view.isUserInteractionEnabled = true
                    CommonFunctions().stopAnimate()
                }
                self.taskID = ""
            }
        }
    }
    
    //MARK: Get Approve ProgressEntry
    func getApproveProgressEntry(rowno: Int,level: Bool) {
        self.view.isUserInteractionEnabled = false
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "pms/progressentry/approval/\(level)/" + String(rowno), dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess)
            {
                let overtime = dataResponse!["COMPANY_OVERTIME"] as? Float
                let prdtvhrs = dataResponse!["COMPANY_PRODUCTIVE_HOURS"] as! Float
                DispatchQueue.main.async {
                    self.view.isUserInteractionEnabled = true
                    if let userDict : NSDictionary = dataResponse!["USER_TIMESHEET_INFO"] as? NSDictionary
                    {
                        
                        if let resultArry : NSArray = userDict["TimeSheetLineItems"] as? NSArray{
                            self.arraytimesheetlineitemmodel = Mapper<ProgressEntryTimeSheetLineItemModel>().mapArray(JSONObject: resultArry) ?? []
                        }
                        
                        if self.arraytimesheetlineitemmodel.count > 0 {
                            
                                self.lblHeader.attributedText = CommonFunctions().getHeader(title: "ProgressEntry", count: String((self.totalApprovePE)))
                            
                                var wrkHr = Double()
                                var finalWorkedHour = Double()
                            
                                for i in 0..<self.arraytimesheetlineitemmodel.count {
                                    let obj = self.arraytimesheetlineitemmodel[i]
                                    wrkHr = obj.wORKHOURS
                                    finalWorkedHour += wrkHr
                                    
                                }
                            
                                let wrkHrs : Float = Float(finalWorkedHour)
                            
                                let overTIME : Float = Float(overtime!)
                                //minute to hrs
                                let overTime : Float = overTIME/60
                            
                            
                                //productive hrs + overtime
                                let productiveOvertime = overTime + prdtvhrs
                            
                                if wrkHrs < prdtvhrs {
                                    self.approvalHrs.textColor = .red
                                }
                                else {
                                    if wrkHrs >= prdtvhrs && wrkHrs < productiveOvertime {
                                        self.approvalHrs.textColor = UIColor.color("#deb887") // light orange
                                    }
                                    if wrkHrs >= productiveOvertime {
                                        self.approvalHrs.textColor = UIColor.color("#2AA53F")! // green
                                    }
                                }
                            
                                //approvalHrs
                                self.approvalHrs.text = CommonFunctions().changeHourMinFormat(hours: finalWorkedHour)//String(format:"%.2f",finalWorkedHour)
                            
                            //DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: {
                            //    RunLoop.current.run(until: Date.init(timeIntervalSinceNow: 1))
                                self.tblprogressEntry.reloadData()
                                appDel?.loader.stopAnimatingGIF()
                                appDel?.loader.isHidden = true
                                self.tblprogressEntry.isHidden = false
                            //})
                        }
                        else {
                            
                            self.tblprogressEntry.isHidden = true
                            
                            let count = rowno - 1
                            if count != 0 {
                                self.getApproveProgressEntry(rowno: count, level: self.leveltype)
                            }
                            else {
                                self.view.makeToast(msgNoRecordFound)
                            }
                            
                            CommonFunctions().stopAnimate()
                            return
                        }
                        
                        if userDict.object(forKey: "TimeSheetId") != nil {
                            self.timesheetID = userDict.object(forKey: "TimeSheetId") as! Int
                            appDel?.currentTimeSheetID = self.timesheetID
                        }
                        
                        if userDict.object(forKey: "TimeSheetDate") != nil {
                            
                            //work date
                            let wd = userDict.object(forKey: "TimeSheetDate")
                            self.formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
                            let myworkdate = self.formatter.date(from: wd! as! String)
                            self.formatter.dateFormat = "EEE, MMM dd, yyyy"
                            self.workdate = self.formatter.string(from: myworkdate!)
                            self.lblApprovalDate.text = self.workdate
                            print(self.workdate)
                            
                        }
                        if userDict.object(forKey: "IN_TIME") != nil {
                            //In time
                            let intime = userDict.object(forKey: "IN_TIME")
                            self.formatter.dateFormat = "HH:mm:ss"
                            
                            let myinTime = self.formatter.date(from: intime! as! String)
                            self.formatter.dateFormat = "hh:mm a"
                            self.formatter.locale = Locale(identifier: "en_US_POSIX")
                            self.Intime = self.formatter.string(from: myinTime!)
                            self.approvalTime.text = self.Intime + " to "
                            
                            print(self.Intime)
                        }
                        if userDict.object(forKey: "OUT_TIME") != nil {
                            //out time
                            let outtime = userDict.object(forKey: "OUT_TIME")
                            self.formatter.dateFormat = "HH:mm:ss"
                            
                            let myoutTime = self.formatter.date(from: outtime! as! String)
                            self.formatter.dateFormat = "hh:mm a"
                            self.formatter.locale = Locale(identifier: "en_US_POSIX")
                            self.Outtime = self.formatter.string(from: myoutTime!)
                            self.approvalTime.text?.append(self.Outtime)
                            
                            print(self.Outtime)
                        }
                    }
                    else
                    {
                        CommonFunctions().stopAnimate()
                        self.tblprogressEntry.isHidden = true
                        appDel?.window?.makeToast("No More Records Found...")
                        self.navigationController?.popViewController(animated: true)
                    }
                    var colorCode : String?
                    var userName : String = ""
                    var imageName : String?
                
                    
                    if let userContactDic : NSArray = dataResponse!["USER_CONTACT_DETAILS"] as? NSArray {
                        
                        // User info
                        let contactDic = userContactDic[0] as! NSDictionary
                        
                        if let color_Code = contactDic.object(forKey: "COLOR_CODE") as? String{
                            print("Success")
                            colorCode = color_Code
                        }
                        else {
                            print("Failure")
                        }
                        
                        
                        if let image_name = contactDic.object(forKey: "IMAGE_NAME") as? String{
                            print("Success")
                            imageName = image_name
                        }
                        else {
                            print("Failure")
                        }
                        
                        if contactDic.object(forKey: "CONTACT_DISPLAY_NAME") != nil {
                            userName = (contactDic.object(forKey: "CONTACT_DISPLAY_NAME") as? String)!
                        }
                        if contactDic.object(forKey: "CONTACT_ID") != nil {
                            self.setUserContactID = contactDic.object(forKey: "CONTACT_ID") as! Int
                        }
                        CommonFunctions().stopAnimate()
                        self.setApprovalProfile(colorcode: colorCode, username: userName, imagename: imageName)
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    self.view.isUserInteractionEnabled = true
                    CommonFunctions().stopAnimate()
                }
            }
            else {
                DispatchQueue.main.async {
                    self.view.isUserInteractionEnabled = true
                    CommonFunctions().stopAnimate()
                }
            }
        }
    }
    
    func setGetProgressEntryTime() {
        //In time
        let intime = self.arrayProgressEntryTimesheet[0].iN_TIME
        formatter.dateFormat = "HH:mm:ss"
        let myinTime = formatter.date(from: intime)
        formatter.dateFormat = "hh:mm a"
        Intime = formatter.string(from: myinTime!)
        self.lblInTime.text = Intime
        print(self.Intime)
        
        //out time
        let outtime = self.arrayProgressEntryTimesheet[0].oUT_TIME
        formatter.dateFormat = "HH:mm:ss"
        let myoutTime = formatter.date(from: outtime)
        formatter.dateFormat = "hh:mm a"
        Outtime = formatter.string(from: myoutTime!)
        lblOutTime.text = Outtime
        print(self.Outtime)
        
        //work date
        let wd = self.arrayProgressEntryTimesheet[0].wORKDATE
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        let myworkdate = formatter.date(from: wd)
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        workdate = formatter.string(from: myworkdate!)
        lblDate.text = workdate
        print(self.workdate)
    }
    
    func setGetProgressEntryHours() {
        var totalTaskHours : Double = 0
        for i in 0..<arrayProgressEntryTask.count {
            let obj = arrayProgressEntryTask[i]
            totalTaskHours += obj.days![0].taskHours
            timesheetID = obj.days![0].timesheetId
        }
        appDel?.currentTimeSheetID = timesheetID
        self.arrayProgressEntryTimesheet[0].wORK_HOURS = totalTaskHours
        self.arrayProgressEntryTimesheet[0].wORKHOURMINUTE = CommonFunctions().changeHourMinFormat(hours: totalTaskHours)
        UserDefaults.standard.set(self.arrayProgressEntryTimesheet[0].wORK_HOURS, forKey: "timesheetWorkHrs")
        self.setTotalHrsRemainingHours()
    }
    
    func setTotalHrsRemainingHours() {
        //work Hours = remaining hour = green
        
        if self.arrayProgressEntryTimesheet[0].wORK_HOURS != 0  {
            
            UserDefaults.standard.set(self.arrayProgressEntryTimesheet[0].wORK_HOURS, forKey: "timesheetWorkHrs")
            
            formatter.dateFormat = "hh:mm a"
            let startTime = formatter.date(from: self.Intime)
            
            formatter.dateFormat = "hh:mm a"
            let endTime = formatter.date(from: self.Outtime)
            
            let mydiff = getDiifference(intime: startTime!, outtime: endTime!)
            
            if mydiff.remainingHour <= 0.00 {
                remainingHrs = String(format:"%.2f",mydiff.remainingHour)
                self.lblRemainingHrs.text = CommonFunctions().changeHourMinFormat(hours: mydiff.remainingHour)//remainingHrs
                
                self.lblRemainingHrs.textColor = UIColor.color("#2e8f0c")//#2AA53F
            }
            else {
                let tempvalue = mydiff.totalhour.remainder(dividingBy: 2)
                if mydiff.remainingHour.isEqual(to: tempvalue) || tempvalue > mydiff.remainingHour {
                    self.lblRemainingHrs.textColor = segmentOrange
                }
                else {
                    self.lblRemainingHrs.textColor = UIColor.red
                }
                remainingHrs = String(format:"%.2f",mydiff.remainingHour)
                self.lblRemainingHrs.text = CommonFunctions().changeHourMinFormat(hours: mydiff.remainingHour)//remainingHrs
                
            }
            print(lblRemainingHrs.text as Any)
            print(mydiff.totalhour)
            totalHrs = String(format:"%.2f",mydiff.totalhour)
            self.lblTotalHrs.text = "/ " + CommonFunctions().changeHourMinFormat(hours: mydiff.totalhour)
            
        }
        else {
            
            formatter.dateFormat = "hh:mm a"
            let startTime = formatter.date(from: self.Intime)
            
            formatter.dateFormat = "hh:mm a"
            let endTime = formatter.date(from: self.Outtime)
            
            let mydiff = getDiifference(intime: startTime!, outtime: endTime!)
            
            if mydiff.remainingHour <= 0.00 {
                remainingHrs = String(format:"%.2f",mydiff.remainingHour)
                self.lblRemainingHrs.text = CommonFunctions().changeHourMinFormat(hours: mydiff.remainingHour)//remainingHrs
                
                self.lblRemainingHrs.textColor = UIColor.color("#2e8f0c")//#2AA53F
            }
            else {
                remainingHrs = String(format:"%.2f",mydiff.remainingHour)
                self.lblRemainingHrs.text = CommonFunctions().changeHourMinFormat(hours: mydiff.remainingHour)//remainingHrs
                self.lblRemainingHrs.textColor = UIColor.red
            }
            print(lblRemainingHrs.text as Any)
            print(mydiff.totalhour)
            totalHrs = String(format:"%.2f",mydiff.totalhour)
            self.lblTotalHrs.text = "/ " + CommonFunctions().changeHourMinFormat(hours: mydiff.totalhour)
            UserDefaults.standard.set(0, forKey: "timesheetWorkHrs")
        }
    }
    //MARK: Set timesheet data
    func setTimeSheetData(){
        
        if self.arrayProgressEntryTimesheet.count > 0 {
            
            //timesheet id
            timesheetID = self.arrayProgressEntryTimesheet[0].tIME_SHEET_ID
            appDel?.currentTimeSheetID = timesheetID
            if self.arrayProgressEntryTimesheet[0].aPPROVAL_STATUS != nil {
                
                isapproved = self.arrayProgressEntryTimesheet[0].aPPROVAL_STATUS!
                self.btnSubmit.isHidden = true
                
                if isapproved == 1 {
                    
                    if UserDefaults.standard.bool(forKey: "FromRecentPE") {
                        lblApprovalStatus.isHidden = false
                        lblApprovalStatus.text = "Approved"
                        lblApprovalStatus.textColor = UIColor.color("#2AA540")
                        btnPEApproval.isHidden = false
                        btnPEApproval.setTitle("REJECT", for: .normal)
                        btnPEApproval.backgroundColor = UIColor.red
                    }
                    else {
                        lblApprovalStatus.isHidden = true
                        btnPEApproval.isHidden = true
                        self.lblStatus.isHidden = false
                        self.lblStatus.text = "APPROVED"
                        self.lblStatus.backgroundColor = UIColor.color("#2AA540") // green
                        
                        self.btnSubmit.isHidden = true
                    }
                    
                }
                else if isapproved == 2 {
                    
                    if UserDefaults.standard.bool(forKey: "FromRecentPE") {
                        lblApprovalStatus.isHidden = false
                        lblApprovalStatus.text = "Rejected"
                        lblApprovalStatus.textColor = UIColor.red
                        btnPEApproval.isHidden = false
                        btnPEApproval.setTitle("APPROVE", for: .normal)
                        btnPEApproval.backgroundColor = UIColor.color("#2AA540") // orange
                    }
                    else {
                        lblApprovalStatus.isHidden = true
                        btnPEApproval.isHidden = true
                        self.lblStatus.isHidden = false
                        self.lblStatus.text = "REJECTED"
                        self.lblStatus.backgroundColor = UIColor.red
                        
                        self.btnSubmit.isHidden = true
                    }
                }
                else if isapproved == 0 {
                    if UserDefaults.standard.bool(forKey: "FromRecentPE") {
                        lblApprovalStatus.isHidden = false
                        lblApprovalStatus.text = "Approval Pending"
                        lblApprovalStatus.textColor = theme_orange_color// Orange
                        btnPEApproval.isHidden = true
                        btnPEApproval.setTitle("", for: .normal)
                        btnPEApproval.backgroundColor = UIColor.color("#2AA540")
                        self.approvalView.isHidden = false
                        self.btnApproveMessage.setTitle(String.fontAwesomeIcon(name: .commenting), for: .normal)
                        
                    }
                    else {
                        lblApprovalStatus.isHidden = false
                        lblApprovalStatus.text = "Unapproved"
                        lblApprovalStatus.textColor = UIColor.black
                        btnPEApproval.isHidden = true
                        self.lblStatus.isHidden = false
                        self.lblStatus.text = "APPROVAL PENDING"
                        self.lblStatus.backgroundColor = theme_orange_color // Orange
                        
                        self.btnSubmit.isHidden = true
                    }
                }
            }
            else {
                
                lblApprovalStatus.isHidden = false
                lblApprovalStatus.text = "Unsubmitted"
                btnPEApproval.isHidden = true
                
                self.btnSubmit.isHidden = false
                self.lblStatus.isHidden = true
                
                self.btnSubmit.isUserInteractionEnabled = true
                self.btnSubmit.setTitle("SUBMIT FOR APPROVAL", for: .normal)
                
                self.btnSubmit.backgroundColor = hexStringToUIColor(hex: (UserDefaults.standard.object(forKey: themeBorder) as? String)!)//UIColor.color("#2AA540")
                self.btnSubmit.setTitleColor(UIColor.white, for: .normal)
            }
            
            
            //In time
            let intime = self.arrayProgressEntryTimesheet[0].iN_TIME
            formatter.dateFormat = "HH:mm:ss"
            let myinTime = formatter.date(from: intime)
            formatter.dateFormat = "hh:mm a"
            formatter.locale = Locale(identifier: "en_US_POSIX")
            Intime = formatter.string(from: myinTime!)
            self.lblInTime.text = Intime
            print(self.Intime)
            
            //out time
            let outtime = self.arrayProgressEntryTimesheet[0].oUT_TIME
            formatter.dateFormat = "HH:mm:ss"
            let myoutTime = formatter.date(from: outtime)
            formatter.dateFormat = "hh:mm a"
            formatter.locale = Locale(identifier: "en_US_POSIX")
            Outtime = formatter.string(from: myoutTime!)
            lblOutTime.text = Outtime
            print(self.Outtime)
            
            //work date
            let wd = self.arrayProgressEntryTimesheet[0].wORKDATE
            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
            let myworkdate = formatter.date(from: wd)
            formatter.dateFormat = "EEE, MMM dd, yyyy"
            workdate = formatter.string(from: myworkdate!)
            lblDate.text = workdate
            print(self.workdate)
            
            self.setTotalHrsRemainingHours()
        }
        else {
            UserDefaults.standard.set(0, forKey: "timesheetWorkHrs")
        }
    }
    
    //MARK: Time difference
    func getDiifference(intime: Date, outtime: Date) -> (totalhour: Double, remainingHour: Double) {
        
        let diff = Int((outtime.timeIntervalSince1970) - (intime.timeIntervalSince1970))
        
        let hours = diff / 3600
        let minute = (diff - hours * 3600) / 60
        
        print(hours,minute)
        
        var minutes = Double()
        
        minutes = Double(minute)
        minutes = minutes/60
        
        var hourMin = Double(hours) + minutes
        hourMin = hourMin.roundTo(places: 2)
        
        hourMin = Double(round(1000 *  hourMin) / 1000 )
        hourMin = hourMin.roundTo(places: 2)
        
        print(hourMin)
        
        var workhour : Double = self.arrayProgressEntryTimesheet[0].wORK_HOURS
        workhour = workhour.roundTo(places: 2)
        print(workhour)
        
        let remainingHour = hourMin - workhour
        
        print(remainingHour)
        
        return (hourMin,remainingHour)
    }
    
    //MARK: Set profile data
    func setProfile(){
        if (ProgressEntryUserInfo.imageName == ""){
            lblUserInitials.isHidden = true
            lblUserInitials.isHidden = false
            
            lblUserInitials.textColor = UIColor.white
            
            if ProgressEntryUserInfo.colorCode != "" {
                lblUserInitials.backgroundColor = UIColor.color(ProgressEntryUserInfo.colorCode)
            }
            else {
                lblUserInitials.backgroundColor = UIColor.darkGray
            }
            
            
            let userInitial : String = CommonFunctions().generateInitial(username: ProgressEntryUserInfo.contactName)
            
            lblUserInitials.text = userInitial
        }
        else{
            lblUserInitials.isHidden = true
            imguser.isHidden = false
            lblUserInitials.text = ""
            imguser.sd_setImage(with: URL(string: baseContactImageURL + "\(String(describing: (ProgressEntryUserInfo.contactId)))" + "/image?filename=" + ProgressEntryUserInfo.imageName), placeholderImage: UIImage(named: "person_icon"))
        }
        
        self.lblHeaderName.text = ProgressEntryUserInfo.contactName
    }
    
    //MARK: SET APPROVAL USER PROFILE
    func setApprovalProfile(colorcode: String?, username: String, imagename: String?){
        if imagename == nil {
            lblUserInitials2.isHidden = true
            lblUserInitials2.isHidden = false
            
            lblUserInitials2.textColor = UIColor.white
            
            if colorcode != nil {
                lblUserInitials2.backgroundColor = UIColor.color(colorcode!)
            }
            else {
                lblUserInitials2.backgroundColor = UIColor.darkGray
            }
            
            let userInitial : String = CommonFunctions().generateInitial(username: username)
            
            lblUserInitials2.text = userInitial
            
        }
        else{
            lblUserInitials2.isHidden = true
            imguser2.isHidden = false
            lblUserInitials2.text = ""
            imguser2.sd_setImage(with: URL(string: baseContactImageURL + "\(String(describing: (setUserContactID)))" + "/image?filename=" + imagename!), placeholderImage: UIImage(named: "person_icon"))
        }
        
        self.lblHeaderName.text = username
    }
    
    func timesheetTimeConversion() -> (mydate: String, intime: String, outtime: String) {
        
        //date
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        let myworkdate = formatter.date(from: lblDate.text!)
        
        formatter.dateFormat = "yyyy-MM-dd"
        let mydate = formatter.string(from: myworkdate!)
        
        print(mydate)
        
        //in time
        formatter.dateFormat = "hh:mm a"
        let myInTime = formatter.date(from: Intime)
        formatter.dateFormat = "HH:mm:ss"
        let intime = formatter.string(from: myInTime!)
        
        print(intime)
        
        //out time
        formatter.dateFormat = "hh:mm a"
        let myoutTime = formatter.date(from: Outtime)
        formatter.dateFormat = "HH:mm:ss"
        let outtime = formatter.string(from: myoutTime!)
        return (mydate,intime,outtime)
    }
    
    func getTimesheetTimeConversion() -> (mydate: String, intime: String, outtime: String) {
        
        //date
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        let myworkdate = formatter.date(from: lblDate.text!)
        
        formatter.dateFormat = "yyyy-MM-dd"
        let mydate = formatter.string(from: myworkdate!)
        
        print(mydate)
        
        //in time
        formatter.dateFormat = "hh:mm a"
        let myInTime = formatter.date(from: Intime)
        formatter.dateFormat = "HH:mm"
        let intime = formatter.string(from: myInTime!)
        
        print(intime)
        
        //out time
        formatter.dateFormat = "hh:mm a"
        let myoutTime = formatter.date(from: Outtime)
        formatter.dateFormat = "HH:mm"
        let outtime = formatter.string(from: myoutTime!)
        return (mydate,intime,outtime)
    }
    
    func getcurrentUSERID() -> String {
        if self.setUserContactID <= 0 {
            if appDel?.selectedUserID == 0   {
                self.getUserContactID = "/"
            }
            else {
                let userid : Int = (appDel?.selectedUserID)!
                self.getUserContactID = String(userid)
                self.getUserContactID = "/" + getUserContactID
            }
        }
        else {
            self.getUserContactID = "/"+String(setUserContactID)
        }
        return self.getUserContactID
    }
    
    @objc func tapToClose(_ sender: UITapGestureRecognizer) {
        self.selectionBgView.isHidden = true
        
    }
    
    func addGestureRecognizer(){
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
        swipeLeft.direction = .left
        self.view.addGestureRecognizer(swipeLeft)
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
        swipeRight.direction = .right
        self.view.addGestureRecognizer(swipeRight)
    }
    @objc func handleGesture(gesture: UISwipeGestureRecognizer) -> Void {
        if gesture.direction == UISwipeGestureRecognizer.Direction.left {
            print("Swipe Right")
            if setRowNO < totalApprovePE {
                setRowNO = setRowNO + 1
                self.getApproveProgressEntry(rowno: setRowNO, level: self.leveltype)
            }
        }
        else if gesture.direction == UISwipeGestureRecognizer.Direction.right {
            print("Swipe Left")
            if setRowNO >= 1 {
                setRowNO = setRowNO - 1
                self.getApproveProgressEntry(rowno: setRowNO, level: self.leveltype)
            }
        }
    }
    
    //MARK: Set date for api
    func mydate() -> String {
        
        let date = Date()
        
        formatter.dateFormat = "yyyy-MM-dd"
        var resultDate : String = String()
       
        if self.setDateFrom == "" {
            if workdate != "" {
                
                formatter.dateFormat = "EEE, MMM dd, yyyy"
                let myworkdate = formatter.date(from: workdate)
                
                formatter.dateFormat = "yyyy-MM-dd"
                resultDate = formatter.string(from: myworkdate!)
                print(resultDate)
            }
            else if UserDefaults.standard.string(forKey: "timesheetDate") != ""{
                let timesheetdate = UserDefaults.standard.string(forKey: "timesheetDate")
                
                formatter.dateFormat = "EEE, MMM dd, yyyy"
                let dt = formatter.date(from: timesheetdate!)
                
                formatter.dateFormat = "MMM dd, yyyy"
                resultDate = formatter.string(from: dt!)
                
            }
            else {
                myPickerView.date = date
                formatter.dateFormat = "yyyy-MM-dd"
            
                let pickerdate = formatter.string(from: myPickerView.date)
                resultDate = pickerdate
            }
        }
        else {
            
            formatter.dateFormat = "MM/dd/yyyy"
            let dt = formatter.date(from: setDateFrom)
            formatter.dateFormat = "yyyy-MM-dd"
            resultDate = formatter.string(from: dt!)
            print(resultDate)
        }
        
        return resultDate
    }
    //MARK: OPEN PROGRESS ENTRY TO EDIT
    func openEditProgreessEntry(objTask: ProgressEntryTaskModel) {
        
        let controller = (appDel?.WIPNewStoryBoard.instantiateViewController(withIdentifier: "WIPEditProgressEntryVC"))! as! WIPEditProgressEntryVC
        controller.ProgressEntryUserInfo = self.ProgressEntryUserInfo
        controller.createProgressEntry = self
        controller.intimeFrom = self.Intime
        controller.outtimeFrom = self.Outtime
        controller.dateFrom = self.workdate
        controller.totalhrsFrom = totalHrs
        controller.rEMAININGHOURSALL = Double(self.remainingHrs)!
        controller.timesheetID = objTask.days![0].timesheetId
        controller.timesheetLineitemID = objTask.days![0].timesheetLineItemId
        controller.objTimesheetTaskModel = objTask
        controller.projectID = (objTask.pROJECTID)
        controller.sprintID = (objTask.sPRINTID)
        controller.taskID = (objTask.tASKID)
        controller.attachmentCountFrom = 0
        controller.editFlag = true
        controller.GeteditFlag = true
        controller.editOpenData = false
        if self.btnGetPE.tag == 0 {
            UserDefaults.standard.set(true, forKey: "isSavedPE")
        }
        else {
            UserDefaults.standard.set(false, forKey: "isSavedPE")
        }
        appDel?.selectedUserID = self.ProgressEntryUserInfo.contactId
        appDel?.attachedPEDocument.removeAll()
        appDel?.taskIDArray.removeAllObjects()
        
        for i in 0..<arrayProgressEntryTask.count {
            let obj = arrayProgressEntryTask[i]
            if !((appDel?.taskIDArray.contains(obj.tASKID))!) {
                appDel?.taskIDArray.add(obj.tASKID)
            }
        }

        self.navigationController?.pushViewController(controller, animated: true)
        
    }
    
    func isValidSaveInfo() -> Bool {
        var ErrorMSG = ""
        for i in 0..<self.arrayProgressEntryTask.count {
            let objTask = self.arrayProgressEntryTask[i]
            if objTask.aLLOCATEDHOURS.isLess(than: objTask.days![0].taskHours){
                if ErrorMSG == "" {
                    ErrorMSG = "Work Item hours Exceeded for Work Item " + String(describing: objTask.tASKID)
                }
                else {
                    ErrorMSG.append(" \nWork Item hours Exceeded for Work Item " + String(describing: objTask.tASKID))
                }
            }
        }
        if ErrorMSG != "" {
            CommonFunctions().showAlert(msg: ErrorMSG)
            return false
        }
        return true
    }
    
    func isValidSubmitInfo() -> Bool {
        if self.lblRemainingHrs.text != "00:00" {
            CommonFunctions().showAlert(msg: "Please fill all office hours.")
            return false
        }
        return true
    }
    
    //MARK: IBACTIONS
    @IBAction func onGETPE(_ sender: UIButton) {
        self.btnGetPE.tag = 1
        self.getRecordedProgressEntries(currentDate: mydate(),userID: self.getcurrentUSERID())
    }
    
    @IBAction func onGetPESave(_ sender: UIButton) {
        if isValidSaveInfo() {
            self.setProgressEntryParam(PEType: "1")
        }
    }
    
    @IBAction func onGetPESubmit(_ sender: UIButton) {
        if isValidSaveInfo() {
            if isValidSubmitInfo() {
                self.setProgressEntryParam(PEType: "2")
            }
        }
    }
    
    @IBAction func onApprove(_ sender: Any) {
        self.approveProgressEntry(isapprove: true, reason: "")
    }
    
    
    @IBAction func onApproveMessage(_ sender: UIButton) {
        self.tag = 1
        if arraytimesheetlineitemmodel.count > 0 {
            self.selectionBgView.isHidden = false
            self.lblMsgBoxTitle.text = "Message"
            self.btnMessageDone.setTitle("APPROVE", for: .normal)
            
        }
        else if arrayProgressEntryTask.count > 0 {
            self.selectionBgView.isHidden = false
            self.rejectionView.isHidden = false
            self.pickerView.isHidden = true
            self.lblMsgBoxTitle.text = "Message"
            self.btnMessageDone.setTitle("APPROVE", for: .normal)
        }
        else {
            return
        }

    }
    
    @IBAction func onReject(_ sender: Any) {
        self.tag = 2
        if arraytimesheetlineitemmodel.count > 0 {
            self.selectionBgView.isHidden = false
            self.lblMsgBoxTitle.text = "REASON FOR THE REJECTION"
            self.btnMessageDone.setTitle("REJECT", for: .normal)
        }
        else if arrayProgressEntryTask.count > 0 {
            self.selectionBgView.isHidden = false
            self.rejectionView.isHidden = false
            self.pickerView.isHidden = true
            self.lblMsgBoxTitle.text = "REASON FOR THE REJECTION"
            self.btnMessageDone.setTitle("REJECT", for: .normal)
        }
        else {
            return
        }

    }
    
    @IBAction func onRejectWithReason(_ sender: Any) {
        if self.tag == 2 {
            if txtReason.text != "" && txtReason.text != " " {
                self.approveProgressEntry(isapprove: false, reason: txtReason.text.condenseWhitespace())
                txtReason.text = ""
                txtReason.resignFirstResponder()
                self.selectionBgView.isHidden = true
            }
            else {
                appDel?.window?.makeToast("Please enter rejection reason")
            }
        }
        else {
            self.approveProgressEntry(isapprove: true, reason: txtReason.text.condenseWhitespace())
            txtReason.text = ""
            txtReason.resignFirstResponder()
            self.selectionBgView.isHidden = true
        }
    }
    
    @IBAction func onCancel(_ sender: Any) {
        self.selectionBgView.isHidden = true
        
    }
    
    
    @IBAction func onBack(_ sender: Any) {
        appDel?.selectedUserID = 0
        appDel?.currentTimeSheetID = 0
        appDel?.taskIDArray.removeAllObjects()
        UserDefaults.standard.set(false, forKey: "isFromEditPE")
        UserDefaults.standard.set(false, forKey: "isSavedPE")
        UserDefaults.standard.set("", forKey: "timesheetDate")
        UserDefaults.standard.set(false, forKey: "FromRecentPE")
        self.navigationController?.popViewController(animated: true)
    }
    

    @IBAction func onPlus(_ sender: Any) {

        let controller = (appDel?.WIPNewStoryBoard.instantiateViewController(withIdentifier: "WIPEditProgressEntryVC"))! as! WIPEditProgressEntryVC
        controller.createProgressEntry = self
        controller.ProgressEntryUserInfo = self.ProgressEntryUserInfo
        controller.intimeFrom = self.Intime
        controller.outtimeFrom = self.Outtime
        controller.dateFrom = self.workdate
        controller.totalhrsFrom = totalHrs
        controller.rEMAININGHOURSALL = Double(self.remainingHrs)!
        controller.timesheetID = (appDel?.currentTimeSheetID)!
        controller.projectID = 0
        controller.sprintID = 0
        controller.taskID = 0
        controller.attachmentCountFrom = 0
        controller.editFlag = false
        controller.GeteditFlag = false
        controller.editOpenData = false
        if self.btnGetPE.tag == 0 {
            UserDefaults.standard.set(true, forKey: "isSavedPE")
        }
        else {
            UserDefaults.standard.set(false, forKey: "isSavedPE")
        }
        appDel?.selectedUserID = self.ProgressEntryUserInfo.contactId
        appDel?.taskIDArray.removeAllObjects()
        
        for i in 0..<arrayProgressEntryTask.count {
            let obj = arrayProgressEntryTask[i]
            if !((appDel?.taskIDArray.contains(obj.tASKID))!) {
                appDel?.taskIDArray.add(obj.tASKID)
            }
        }
        
        appDel?.attachedPEDocument.removeAll()
        
        self.navigationController?.pushViewController(controller, animated: true)
    
    }
    
    @IBAction func OnSubmitForApproval(_ sender: Any) {
        
        if self.lblRemainingHrs.text != "00:00" {
            CommonFunctions().showAlert(msg: "Please fill all office hours.")
        }
        else {
            self.submitProgressEntry()
        }
    }
    
    @IBAction func OnDateSelect(_ sender: UIButton) {
        self.rejectionView.isHidden = true
        self.pickerView.isHidden = false
        self.myPickerView.datePickerMode = .date
        self.selectionBgView.isHidden = false
        self.tag = sender.tag
        var wd : String = String()
        
        if self.workdate != "" {
            wd = self.workdate
            formatter.dateFormat = "EEE, MMM dd, yyyy"
            let myworkdate = formatter.date(from: wd)
            self.myPickerView.setDate(myworkdate!, animated: true)
        }
        let date = Date()
        
        myPickerView.maximumDate = date
    }
    
    
    @IBAction func onInTime(_ sender: UIButton) {
        self.rejectionView.isHidden = true
        self.pickerView.isHidden = false
        self.myPickerView.datePickerMode = .time
        self.selectionBgView.isHidden = false
        self.tag = sender.tag
        
        var it : String = String()
       
        if self.Intime != "" {
            it = self.Intime
            formatter.dateFormat = "hh:mm a"
            formatter.locale = Locale(identifier: "en_US_POSIX")
            let myintime = formatter.date(from: it)
            self.myPickerView.date = myintime!
            self.myPickerView.locale = Locale(identifier: "en_US_POSIX")
        }
    
    }
    
    
    @IBAction func onOutTime(_ sender: UIButton) {
        self.rejectionView.isHidden = true
        self.pickerView.isHidden = false
        self.myPickerView.datePickerMode = .time
        self.selectionBgView.isHidden = false
        self.tag = sender.tag
        var ot : String = String()
       
        if self.Outtime != "" {
            ot = self.Outtime
            formatter.dateFormat = "hh:mm a"
            formatter.locale = Locale(identifier: "en_US_POSIX")
            let myouttime = formatter.date(from: ot)
            self.myPickerView.date = myouttime!
            self.myPickerView.locale = Locale(identifier: "en_US_POSIX")
        }
        
    }
    
    @IBAction func OnDone(_ sender: Any) {
        
        if self.tag == 0 {
            
            formatter.dateFormat = "EEE, MMM dd, yyyy"
            workdate = formatter.string(from: myPickerView.date)
            print(workdate)
            lblDate.text = workdate
            
            formatter.dateFormat = "yyyy-MM-dd"
            let result = formatter.string(from: myPickerView.date)
            self.arrayProgressEntryTask.removeAll()
            self.arraytimesheetlineitemmodel.removeAll()
            self.tblprogressEntry.reloadData()
            self.tblprogressEntry.reloadInputViews()
            self.tblprogressEntry.reloadData()
            self.btnGetPE.tag = 0
            self.viewGetSubmission.isHidden = true
            self.getProgressEntries(currentDate: result,userID: self.getcurrentUSERID())
            selectionBgView.isHidden = true
            pickerView.isHidden = true
            appDel?.taskIDArray.removeAllObjects()
        }
        
        if self.tag == 1 {
            
            formatter.dateFormat = "hh:mm a"
            Intime = formatter.string(from: myPickerView.date)
            print(Intime)
            lblInTime.text = Intime
            
            if self.Outtime == "- : -" {
                let date = Date()
                let calendar = Calendar.current
                let hour = calendar.component(.hour, from: date)
                let minutes = calendar.component(.minute, from: date)
                var str : String = String(hour)+":"
                str.append(String(minutes))
                formatter.dateFormat = "HH:mm"
                let tm = formatter.date(from: str)
                formatter.amSymbol = "AM"
                formatter.pmSymbol = "PM"
                formatter.dateFormat = "hh:mm a"
                self.Outtime = formatter.string(from: tm!)
                print(self.Outtime)
            }
                formatter.dateFormat = "hh:mm a"
                
                let ot = formatter.date(from: self.Outtime)
                print(ot!)
                print(myPickerView.date)
                let myStringdate = formatter.string(from: myPickerView.date)
                print(myStringdate)
                let comparedate = formatter.date(from: myStringdate)
                print(comparedate!)
                
                if comparedate!.timeIntervalSince1970 > ot!.timeIntervalSince1970 || myStringdate == self.Outtime {
                   CommonFunctions().self.showAlert(msg: "Out time can not be before in time")
                }
                else {
                    
                    formatter.dateFormat = "hh:mm a"
                    Intime = formatter.string(from: myPickerView.date)
                    
                    print(Intime)
                    lblInTime.text = Intime
                    
                    selectionBgView.isHidden = true
                    pickerView.isHidden = true
                    formatter.dateFormat = "hh:mm a"
                    //formatter.timeZone = TimeZone(abbreviation: "UTC")
                    let startTime = formatter.date(from: self.Intime)
                    
                    formatter.dateFormat = "hh:mm a"
                    //formatter.timeZone = TimeZone(abbreviation: "UTC")
                    let endTime = formatter.date(from: self.Outtime)
                    
                    
                    let mydiff = getDiifference(intime: startTime!, outtime: endTime!)
                    
                    if mydiff.remainingHour <= 0.00 {
                        remainingHrs = String(format:"%.2f",mydiff.remainingHour)
                        self.lblRemainingHrs.text = CommonFunctions().changeHourMinFormat(hours: mydiff.remainingHour)//remainingHrs
                        //self.lblRemainingHrs.text = remainingHrs
                        self.lblRemainingHrs.textColor = UIColor.color("#2e8f0c")//#2AA53F
                    }
                    else {
                        let tempvalue = mydiff.totalhour.remainder(dividingBy: 2)
                        if mydiff.remainingHour.isEqual(to: tempvalue) || tempvalue > mydiff.remainingHour {
                            self.lblRemainingHrs.textColor = segmentOrange
                        }
                        else {
                            self.lblRemainingHrs.textColor = UIColor.red
                        }
                        remainingHrs = String(format:"%.2f",mydiff.remainingHour)
                        self.lblRemainingHrs.text = CommonFunctions().changeHourMinFormat(hours: mydiff.remainingHour)//remainingHrs
                        //self.lblRemainingHrs.text = remainingHrs
                    }
                    print(lblRemainingHrs.text as Any)
                    print(mydiff.totalhour)
                    totalHrs = String(format:"%.2f",mydiff.totalhour)
                    self.lblTotalHrs.text = "/ " + totalHrs//CommonFunctions().changeHourMinFormat(hours: mydiff.totalhour)
                }
        }
        
        if self.tag == 2 {
            if self.Intime != "" {
                
                formatter.dateFormat = "hh:mm a"
                
                let it = formatter.date(from: self.Intime)
                print(it!)
                print(myPickerView.date)
                let myStringdate = formatter.string(from: myPickerView.date)
                print(myStringdate)
                let comparedate = formatter.date(from: myStringdate)
                print(comparedate!)
               
                if comparedate!.timeIntervalSince1970 < it!.timeIntervalSince1970 || myStringdate == self.Intime {
                  
                    CommonFunctions().self.showAlert(msg: "Out time can not be before in time")
                    
                }
                else {
                    
                    formatter.dateFormat = "hh:mm a"
                    Outtime = formatter.string(from: myPickerView.date)
                    
                    print(Outtime)
                    lblOutTime.text = Outtime
                    
                    selectionBgView.isHidden = true
                    pickerView.isHidden = true
                    formatter.dateFormat = "hh:mm a"
                    //formatter.timeZone = TimeZone(abbreviation: "UTC")
                    let startTime = formatter.date(from: self.Intime)
                    
                    formatter.dateFormat = "hh:mm a"
                    //formatter.timeZone = TimeZone(abbreviation: "UTC")
                    let endTime = formatter.date(from: self.Outtime)
                    
                    let mydiff = getDiifference(intime: startTime!, outtime: endTime!)
                    
                    if mydiff.remainingHour <= 0.00 {
                        remainingHrs = String(format:"%.2f",mydiff.remainingHour)
                        self.lblRemainingHrs.text = CommonFunctions().changeHourMinFormat(hours: mydiff.remainingHour)//remainingHrs
                        self.lblRemainingHrs.textColor = UIColor.color("#2e8f0c")//#2AA53F
                    }
                    else {
                        let tempvalue = mydiff.totalhour.remainder(dividingBy: 2)
                        if mydiff.remainingHour.isEqual(to: tempvalue) || tempvalue > mydiff.remainingHour {
                            self.lblRemainingHrs.textColor = segmentOrange
                        }
                        else {
                            self.lblRemainingHrs.textColor = UIColor.red
                        }
                        remainingHrs = String(format:"%.2f",mydiff.remainingHour)
                        self.lblRemainingHrs.text = CommonFunctions().changeHourMinFormat(hours: mydiff.remainingHour)//remainingHrs
                    }
                    print(lblRemainingHrs.text as Any)
                    print(mydiff.totalhour)
                    totalHrs = String(format:"%.2f",mydiff.totalhour)
                    self.lblTotalHrs.text = "/ " + CommonFunctions().changeHourMinFormat(hours: mydiff.totalhour)
                }
                
            }
            else {
                //In Time Have To Be Set First
                CommonFunctions().showAlert(msg: "In Time Have To Be Set First")
            }
            
        }
        
    }
    
    
    @IBAction func btnApproval(_ sender: Any) {
        if self.arrayProgressEntryTimesheet[0].aPPROVAL_STATUS != nil {
            isapproved = self.arrayProgressEntryTimesheet[0].aPPROVAL_STATUS!
            if isapproved == 1 {
                self.rejectionView.isHidden = false
                txtReason.isHidden = false
                self.pickerView.isHidden = true
                self.selectionBgView.isHidden = false
                self.tag = 2
            }
            if isapproved == 2 {
            
                self.approveProgressEntry(isapprove: true, reason: "")
            }
        }
    }
    
    //MARK: APPROVAL OR REJECTION
    
    func approveProgressEntry(isapprove : Bool, reason : String) {
        CommonFunctions().animate()
        var parameters :[String:AnyObject] = [:]
        if isapprove == true {
            parameters = ["TIMESHEET_ID" : timesheetID as Int, "CONTACT_ID" : setUserContactID as Int, "DESCRIPTION" : reason as String ,"IS_APPROVED" : "true" as AnyObject] as [String : AnyObject]
        }
        else {
            
            parameters = ["TIMESHEET_ID" : timesheetID as Int, "CONTACT_ID" : setUserContactID as Int, "DESCRIPTION" : reason as String , "IS_APPROVED" : "false" as AnyObject] as [String : AnyObject]

        }
        
        print(parameters)
        let manager = APIManager.apiManager
        self.view.isUserInteractionEnabled = false
        manager.postDataForApprovalFromUrl(url: "pms/progressentry/approval", dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    self.view.isUserInteractionEnabled = true
                    CommonFunctions().stopAnimate()
                    appDel?.selectedUserID = 0
                    appDel?.taskIDArray.removeAllObjects()
                    UserDefaults.standard.set("", forKey: "timesheetDate")
                    
                    if UserDefaults.standard.bool(forKey: "FromRecentPE") {
                        
                        if isapprove {
                           appDel?.window?.makeToast("ProgressEntry approved")
                        }
                        else {
                           appDel?.window?.makeToast("ProgressEntry rejected")
                        }
                        //appDel?.window?.makeToast("ProgressEntry Approval saved successfully")
                        
                        self.lblApprovalStatus.isHidden = true
                        self.btnPEApproval.isHidden = true
                        self.approvalView.isHidden = true
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute: {
                            self.navigationController?.popViewController(animated: true)
                        })
                    }
                    else {
                        //last record
                        if self.setRowNO == self.totalApprovePE {
                            self.setRowNO = self.setRowNO - 1
                            self.navigationController?.popViewController(animated: true)
                            return
                        }
                        self.totalApprovePE = self.totalApprovePE - 1
                        self.lblHeader.attributedText = CommonFunctions().getHeader(title: "ProgressEntry", count: String((self.totalApprovePE)))
                        
                        self.getApproveProgressEntry(rowno: self.setRowNO, level: self.leveltype)
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    self.view.isUserInteractionEnabled = true
                    CommonFunctions().stopAnimate()
                    self.view.makeToast("Issue in approval progressEntry")
                    
                }
            }
            else {
                DispatchQueue.main.async {
                    self.view.isUserInteractionEnabled = true
                    CommonFunctions().stopAnimate()
                    self.view.makeToast("Issue in approval progressEntry")
                    
                }
            }
        }
    }
    //MARK: Save progress entry
    func submitProgressEntry() {
        
        let datetime = timesheetTimeConversion()
        CommonFunctions().animate()
        
        self.view.isUserInteractionEnabled = false
       
        var parameters :[String:AnyObject] = [:]
        print(datetime.intime,datetime.outtime)
        parameters = ["TimeSheetDate" : datetime.mydate as AnyObject, "TimeSheetId" : timesheetID as AnyObject ,"IN_TIME" : datetime.intime as AnyObject,"OUT_TIME": datetime.outtime as AnyObject] as [String : AnyObject]
        
        print(parameters)
        let manager = APIManager.apiManager
        
        manager.postDataWithBlankResponseOrErrorMsgFromUrl(url: "pms/progressentry/\(datetime.mydate)/submission", dic: parameters as NSDictionary) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast("ProgressEntry sent for approval")
                    
                    self.view.isUserInteractionEnabled = true
                    
                    if UserDefaults.standard.bool(forKey: "FromRecentPE") {
                        self.btnSubmit.isHidden = true
                        self.lblApprovalStatus.text = "Unapproved"
                        self.lblApprovalStatus.textColor = UIColor.red // Orange
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute: {
                            self.navigationController?.popViewController(animated: true)
                        })
                        
                    }
                    else {
                        self.btnSubmit.isHidden = true
                        self.lblApprovalStatus.text = "Unapproved"
                        self.lblApprovalStatus.textColor = UIColor.black
                        self.lblStatus.isHidden = false
                        self.lblStatus.text = "APPROVAL PENDING"
                        self.lblStatus.backgroundColor = theme_orange_color // Orange
                    }
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    self.view.isUserInteractionEnabled = true
                    
                }
            }
            else {
                
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    self.view.isUserInteractionEnabled = true
                }
            }
        }
        
    }
    
    
    //MARK: SUBMIT GET PROGRESS ENTRY
    func setProgressEntryParam(PEType: String) {
        var finalKeyValueDict : [String:AnyObject] = [:]
        var timesheetLineItemArrayDict = [NSMutableDictionary]()
        let datetime = getTimesheetTimeConversion()
        var timesheet = 0
        for i in 0..<arrayProgressEntryTask.count {
            let objTask = arrayProgressEntryTask[i]
            if timesheet > 0 {
                break
            }
            timesheet = objTask.days![0].timesheetId
        }
        for i in 0..<arrayProgressEntryTask.count {
            let mutableLineItemDic = NSMutableDictionary()
            let objTask = arrayProgressEntryTask[i]
            
            mutableLineItemDic.setValue(datetime.mydate, forKey: "TimeSheetDate")
            mutableLineItemDic.setValue(objTask.days![0].timesheetId, forKey: "TimeSheetId")
            mutableLineItemDic.setValue(objTask.days![0].timesheetLineItemId, forKey: "TIME_SHEET_LINE_ITEM_ID")
            mutableLineItemDic.setValue(objTask.days![0].taskHours.roundTo(places: 2), forKey: "WORK_HOURS")
            mutableLineItemDic.setValue(objTask.days![0].taskId, forKey: "TASK_ID")
            mutableLineItemDic.setValue(objTask.days![0].descriptionField, forKey: "DESCRIPTION")
            timesheetLineItemArrayDict.append(mutableLineItemDic)
            print(mutableLineItemDic)
        }
        finalKeyValueDict["TimeSheetLineItems"] = timesheetLineItemArrayDict as AnyObject
        finalKeyValueDict["IN_TIME"] = datetime.intime as AnyObject
        finalKeyValueDict["OUT_TIME"] = datetime.outtime as AnyObject
        finalKeyValueDict["TimeSheetDate"] = datetime.mydate as AnyObject
        finalKeyValueDict["TimeSheetId"] = timesheet as AnyObject
        finalKeyValueDict["CONTACT_ID"] = ProgressEntryUserInfo.contactId as AnyObject
        print(finalKeyValueDict)
        self.postProgressEntry(finalKeyValueDict: finalKeyValueDict, date: datetime.mydate, type: PEType)
    }
    
    func postProgressEntry(finalKeyValueDict : [String:AnyObject], date: String, type : String){
        
        CommonFunctions().animate()
        let str = (type == "1") ? "1" : "2"
        let url = "pms/progressentry/" + date + "/" + str
        self.view.isUserInteractionEnabled = false
        let manager = APIManager.apiManager
        manager.postDataWithBlankResponseOrErrorMsgFromUrl(url: url, dic: finalKeyValueDict as NSDictionary) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    self.view.isUserInteractionEnabled = true
                    if type == "1" {
                        appDel?.window?.makeToast("ProgressEntry saved successfully")
                        self.lblApprovalStatus.text = "Unsubmitted"
                    }
                    else if type == "2" {
                        appDel?.window?.makeToast("ProgressEntry sent for approval")
                        self.lblApprovalStatus.text = "Unapproved"
                        // ProgressEntry(s) saved successfully
                    }
                    
                    self.approvalView.isHidden = true
                    self.btnGetPE.tag = 0
                    self.viewGetSubmission.isHidden = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute: {
                        self.getProgressEntries(currentDate: self.mydate(),userID: self.getcurrentUSERID())
                    })
                    
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                    self.view.isUserInteractionEnabled = true
                    
                }
            }
        }
    }
    
    //MARK: Delete progress entry
    func deleteTask(objTask : ProgressEntryTaskModel, completion: @escaping (Bool) -> Void) {
        var dateStr : String = ""
        
        dateStr = mydate()
        
        CommonFunctions().animate()
        
        let parameters :[String:AnyObject] = [:]
        let manager = APIManager.apiManager
        CommonFunctions().animate()
        manager.DeleteDatadicFromUrlWithoutProgress(url: "pms/progressentry/" + dateStr + "/lineitem/\(String(describing: objTask.days![0].timesheetLineItemId))", dic: parameters) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.taskIDArray.removeAllObjects()
                    self.view.makeToast("ProgressEntry deleted successfully")
                    if self.btnGetPE.tag == 0 {
                        completion(false)
                    }
                    else {
                        completion(true)
                    }
                }
                
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    self.view.makeToast("You are not authorized to perform this action")
                    completion(false)
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    self.view.makeToast("Issue in deleting progress entry")
                    completion(false)
                }
            }
        }
    }
    
    func removeTasklocal(indx: Int) {
        CommonFunctions().animate()
        self.arrayProgressEntryTask.remove(at: indx)
        self.setGetProgressEntryHours()
        if self.arrayProgressEntryTask.count > 0 {
            
        }
        if self.arrayProgressEntryTask.count == 0 {
            self.btnAddProgressEntry.isHidden = false
            self.tblprogressEntry.isHidden = true
            self.btnGetPE.isUserInteractionEnabled = true
            self.viewGetSubmission.isHidden = true
        }
        CommonFunctions().stopAnimate()
        self.tblprogressEntry.reloadData()
    }
    
    func getRowHeight(htmlString: String) -> Int {
        var height = 0
        let width = view.frame.width
        var size = CGSize()
        size = CGSize(width: width, height: .greatestFiniteMagnitude)
        let estimatedFrame = NSAttributedString(attributedString: htmlString.htmlAttributedString()!).boundingRect(with: size, options: .usesLineFragmentOrigin, context: nil)
        height = Int(estimatedFrame.height)
        return height
    }
    
    //MARK: ProgressEntry table
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if setIsFromApproval == false {
            let obj = arrayProgressEntryTask[indexPath.row]
            if obj.days!.count > 0 {
                if obj.days![0].descriptionField != "" {
                    let str = String(describing: (obj.tASKID)) + "-" + obj.days![0].descriptionField
                    let finalStr = String(format: "<span style=\"font-family: Gotham-Book; font-size:12 \">%@</span>",str)
                    return CGFloat(90 + self.getRowHeight(htmlString: finalStr))
                }
                else {
                    let str = String(describing: (obj.tASKID)) + "-" + obj.tASKFULLDESCRIPTION
                    let finalStr = String(format: "<span style=\"font-family: Gotham-Book; font-size:12 \">%@</span>",str)
                    return CGFloat(90 + self.getRowHeight(htmlString: finalStr))
                }
            }
            else {
                let str = String(describing: (obj.tASKID)) + "-" + obj.tASKFULLDESCRIPTION
                let finalStr = String(format: "<span style=\"font-family: Gotham-Book; font-size:12 \">%@</span>",str)
                return CGFloat(90 + self.getRowHeight(htmlString: finalStr))
            }
        }
        else {
            
            let obj = arraytimesheetlineitemmodel[indexPath.row]
            if obj.dESCRIPTIONField != "" {
                let finalStr = String(format: "<span style=\"font-family: Gotham-Book; font-size:12 \">%@</span>",obj.dESCRIPTIONField)
                return CGFloat(50 + self.getRowHeight(htmlString: finalStr))
            }
            else {
                let str = String(describing: (obj.tASKID)) + "-" + obj.tASKDESCRIPTION
                let finalStr = String(format: "<span style=\"font-family: Gotham-Book; font-size:12 \">%@</span>",str)
                return CGFloat(50 + self.getRowHeight(htmlString: finalStr))
            }
        }
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if setIsFromApproval == false {
            return arrayProgressEntryTask.count
        }
        else {
            
            return arraytimesheetlineitemmodel.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "progresscell", for: indexPath) as? progressEntryCell
        
        if setIsFromApproval == false {
            cell?.setValues(obj: arrayProgressEntryTask[indexPath.row])
        }
        else {
            cell?.setApprovalValues(obj: arraytimesheetlineitemmodel[indexPath.row])
        }
        
        return cell!
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      
        if arrayProgressEntryTask.count > 0 {
            let obj = self.arrayProgressEntryTask[indexPath.row]
            self.openEditProgreessEntry(objTask: obj)
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if arrayProgressEntryTask.count > 0 {
            return true
        }
        else {
            return false
        }
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]?
    {
        
        let deleteAction = UITableViewRowAction(style: .destructive, title: "Delete") { (action, indexpath) in
            if (self.arrayProgressEntryTask[indexPath.row].days?[0].timesheetLineItemId)! >= 1 {
                self.deleteTask(objTask: self.arrayProgressEntryTask[indexPath.row]) { (islocal) in
                    if islocal {
                        self.removeTasklocal(indx: indexPath.row)
                    }
                    else {
                        self.getProgressEntries(currentDate: self.mydate(),userID: self.getUserContactID)
                    }
                }
            }
            else {
                self.removeTasklocal(indx: indexPath.row)
            }
        }
        deleteAction.backgroundColor = .red
        
        return [deleteAction]
    }
    
    @available(iOS 11.0, *)
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        
        let deleteAction = UIContextualAction(style: .destructive, title: "") { (action, view, handler) in
            if (self.arrayProgressEntryTask[indexPath.row].days?[0].timesheetLineItemId)! >= 1 {
                self.deleteTask(objTask: self.arrayProgressEntryTask[indexPath.row]) { (islocal) in
                    if islocal {
                        self.removeTasklocal(indx: indexPath.row)
                    }
                    else {
                        self.getProgressEntries(currentDate: self.mydate(),userID: self.getUserContactID)
                    }
                }
            }
            else {
                self.removeTasklocal(indx: indexPath.row)
            }
        }
        deleteAction.image = UIImage(named: "Delete_iCon")
        
        deleteAction.backgroundColor = UIColor.red
        let configuration = UISwipeActionsConfiguration(actions: [deleteAction])
        return configuration
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        IQKeyboardManager.shared.enable = false
        CommonFunctions().stopAnimate()
        
        self.getUserContactID = "/"
        self.setUserContactID = -1
        appDel?.selectedProjectId = 0
        self.setRowNO = 0
    }
    
}
