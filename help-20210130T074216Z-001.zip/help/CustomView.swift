
import UIKit
import Foundation

class CustomView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        setProperties()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setProperties()
    }

    private func setProperties() {
        self.backgroundColor = hexStringToUIColor(hex: "#2AA53F")
        if let colorcode : String = UserDefaults.standard.object(forKey: "SelectedTheme") as? String{
            let defaultColorGreen : UIColor = hexStringToUIColor(hex: "#2AA53F")
            let array = colorcode.components(separatedBy: ",")
            
            if array.count == 1 {
                let color1 = hexStringToUIColor(hex: array[0])
                self.backgroundColor = UIColor.fromGradientWithDirection(.leftToRight, frame: self.frame, colors: [color1])
            }
            if array.count == 2 {
                let color1 = hexStringToUIColor(hex: array[0])
                let color2 = hexStringToUIColor(hex: array[1])
                self.backgroundColor = UIColor.fromGradientWithDirection(.leftToRight, frame: self.frame, colors: [color1,color2])
            }
            if array.count == 3 {
                let color1 = hexStringToUIColor(hex: array[0])
                let color2 = hexStringToUIColor(hex: array[1])
                let color3 = hexStringToUIColor(hex: array[2])
                self.backgroundColor = UIColor.fromGradientWithDirection(.leftToRight, frame: self.frame, colors: [color1,color2,color3])
            }
            else {
                self.backgroundColor = defaultColorGreen
            }
        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

class CustomViewBorder : UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setProperties()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setProperties()
    }
    
    private func setProperties() {
        
        self.layer.borderColor = hexStringToUIColor(hex: "#2AA53F").cgColor
        if let colorcode : String = UserDefaults.standard.object(forKey: "SelectedThemeBorder") as? String{
            self.layer.borderColor = hexStringToUIColor(hex: colorcode).cgColor
        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

class CustomImages : UIImageView {
    override init(image: UIImage?) {
        super.init(image: image)
        self.setProperties()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setProperties()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.setProperties()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.layer.cornerRadius = self.frame.size.height / 2
        self.clipsToBounds = true
        self.tintColor = hexStringToUIColor(hex: "#2AA53F")
        if let colorcode : String = UserDefaults.standard.object(forKey: "SelectedThemeBorder") as? String{
            self.tintColor = hexStringToUIColor(hex: colorcode)
        }
    }
    
    private func setProperties() {
        
        self.image?.withRenderingMode(.alwaysTemplate)
        self.tintColor = hexStringToUIColor(hex: "#2AA53F")
        if let colorcode : String = UserDefaults.standard.object(forKey: "SelectedThemeBorder") as? String{
            self.tintColor = hexStringToUIColor(hex: colorcode)
        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}


class CustomMyTaskImage : UIImageView {
    override init(image: UIImage?) {
        super.init(image: image)
        self.setProperties()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setProperties()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.setProperties()
    }
    
    private func setProperties() {
        
        self.image?.withRenderingMode(.alwaysTemplate)
        self.tintColor = hexStringToUIColor(hex: "#2AA53F")
        if let colorcode : String = UserDefaults.standard.object(forKey: "SelectedThemeBorder") as? String{
//            let color1 = hexStringToUIColor(hex: "#FFFFFF")
//            let color2 = hexStringToUIColor(hex: colorcode)
//            self.tintColor = UIColor.fromGradientWithDirection(.bottomToTop, frame: self.frame, colors: [color1,color2])
            self.tintColor = hexStringToUIColor(hex: colorcode)//
        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

class CustomSquareImage : UIImageView {
    override init(image: UIImage?) {
        super.init(image: image)
        self.setProperties()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setProperties()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.setProperties()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.layer.cornerRadius = 3//self.frame.size.height / 2
        self.clipsToBounds = true
        let color1 = UIColor.white
        let color2 = hexStringToUIColor(hex: "#2AA53F")

        self.image = UIImage.fromGradientWithDirection(.topToBottom, frame: self.frame,colors: [color1,color2])

        if let colorcode : String = UserDefaults.standard.object(forKey: "SelectedTheme") as? String{
            let defaultColorGreen : UIColor = hexStringToUIColor(hex: "#2AA53F")
            let array = colorcode.components(separatedBy: ",")
            
            if array.count == 1 {
                let color1 = hexStringToUIColor(hex: array[0])
                self.image = UIImage.fromGradientWithDirection(.leftToRight, frame: self.frame, colors: [color1])
            }
            if array.count == 2 {
                let color1 = hexStringToUIColor(hex: array[0])
                let color2 = hexStringToUIColor(hex: array[1])
                self.image = UIImage.fromGradientWithDirection(.leftToRight, frame: self.frame, colors: [color1,color2])
            }
            if array.count == 3 {
                let color1 = hexStringToUIColor(hex: array[0])
                let color2 = hexStringToUIColor(hex: array[1])
                let color3 = hexStringToUIColor(hex: array[2])
                self.image = UIImage.fromGradientWithDirection(.leftToRight, frame: self.frame, colors: [color1,color2,color3])
            }
            else {
                self.image = UIImage.fromGradientWithDirection(.leftToRight, frame: self.frame, colors: [defaultColorGreen])
            }
        }
    }
    
    private func setProperties() {
        
//        self.image?.withRenderingMode(.alwaysTemplate)
//        self.tintColor = hexStringToUIColor(hex: "#2AA53F")
//        if let colorcode : String = UserDefaults.standard.object(forKey: "SelectedThemeBorder") as? String{
//            //            let color1 = hexStringToUIColor(hex: "#FFFFFF")
//            //            let color2 = hexStringToUIColor(hex: colorcode)
//            //            self.tintColor = UIColor.fromGradientWithDirection(.bottomToTop, frame: self.frame, colors: [color1,color2])
//            self.tintColor = hexStringToUIColor(hex: colorcode)//
//        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}
