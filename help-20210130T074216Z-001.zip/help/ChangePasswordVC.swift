//
//  ChangePasswordVC.swift
//  WorkInProgress
//
//  Created by Hardik on 11/3/18.
//  Copyright © 2018 Arpit Shah. All rights reserved.
//

import UIKit

class ChangePasswordVC: UIViewController,UITextFieldDelegate {

    @IBOutlet var txtCurrentPassword: UITextField!
    @IBOutlet var txtNewPassword: UITextField!
    @IBOutlet var txtConfirmPassword: UITextField!
    @IBOutlet var submit: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //MARK: TEXTFIELD DELEGATE
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField.tag == 1 || textField.tag == 2 {
            if (textField.text?.count)! < 6 {
                appDel?.window?.makeToast("Please enter at least 6 characters")
                return
            }
        }
    }
    
    //MARK: VALIDATION CHECK
    func isValidAllinfo() -> Bool {
        if txtCurrentPassword.text?.count == 0 {
            self.view.makeToast("Current password should not be empty")
            return false
        }
        if txtNewPassword.text?.count == 0 {
            self.view.makeToast("New password should not be empty")
            return false
        }
        if txtNewPassword.text == txtCurrentPassword.text {
            self.view.makeToast("New password should not be same as existing password")
            return false
        }
        if txtNewPassword.text != txtConfirmPassword.text {
            self.view.makeToast("Confirm password must be equal to new password")
            return false
        }
        if txtConfirmPassword.text?.count == 0 {
            self.view.makeToast("Confirm password must be equal to new password")
            return false
        }
        if !(txtConfirmPassword.text?.isValidPassword())! {
            self.view.makeToast("Password must have minimum 6 character, at least one number, including one special character and one upper or lower character")
            return false
        }
        return true
    }
    //CHANGE PASSOWRD
    func changePassword() {
        CommonFunctions().animate()
        
        if appDel?.isConnected == false {
            appDel?.window?.makeToast("You are not connected to internet, To get move document please connect your device with internet.")
            appDel?.loader.stopAnimatingGIF()
            appDel?.loader.isHidden = true
            return
        }
        
        let parameters  : NSDictionary = ["Password": txtNewPassword.text as Any,"oldPassword" : txtCurrentPassword.text as Any]
        
        let manager = APIManager.apiManager
        manager.postDataWithBlankResponseOrErrorMsgFromUrl(url: "admin/changepassword", dic: parameters as NSDictionary) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    appDel?.window?.makeToast("Password changed successfully")
            
                    _ = self.navigationController?.popViewController(animated: true)
                }
            }
            else if (result == APIResult.APIError) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                    else {
                        appDel?.window?.makeToast(msgSomethingWrong)
                    }
                }
            }
        }
    }
    //MARK: BUTTON ACTIONS
    @IBAction func onBack(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func OnSubmit(_ sender: Any) {
        if self.isValidAllinfo() {
            print("is valid")
            CommonFunctions().animate()
            self.changePassword()
        }
    }
    
    @IBAction func onTechnicalSupport(_ sender: UIButton) {
        UIApplication.shared.open(NSURL(string: urlContactUs)! as URL)
    }
    
}
