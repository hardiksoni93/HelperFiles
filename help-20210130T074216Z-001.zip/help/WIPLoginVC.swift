//
//  WIPLoginVC.swift
//  WorkInProgress
//
//  Created by AON on 04/12/16.
//  Copyright © 2016 FlowRocket, LLC. All rights reserved.
//

import Foundation
import UIKit
import LocalAuthentication

class WIPLoginVC : UIViewController,UITextFieldDelegate{

    @IBOutlet var txtUserName: UITextField!
    @IBOutlet var txtPassword: UITextField!
    @IBOutlet var btnCheckUncheck: UIButton!
    @IBOutlet var lblVersion: UILabel!
    @IBOutlet var logoWidth: NSLayoutConstraint!
    @IBOutlet var logoHeight: NSLayoutConstraint!
    @IBOutlet var scrollHeight : NSLayoutConstraint!
    @IBOutlet weak var btnInstance: UIButton!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var btnEye: UIButton!
    var isFromDifferentUser = false
    
    override func viewDidLoad() {
        if IsIpad == false{
            if Int((appDel?.window?.frame.size.width)!) > Int((appDel?.window?.frame.size.height)!){
                logoWidth.constant = (((appDel?.window?.frame.size.height)! * 240) / 320)
                logoHeight.constant = (((((appDel?.window?.frame.size.height)! * 240) / 320) * 96) / 240)
            }
            else{
                logoWidth.constant = (((appDel?.window?.frame.size.width)! * 240) / 320)
                logoHeight.constant = (((((appDel?.window?.frame.size.width)! * 240) / 320) * 96) / 240)
            }
        }
        if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
            self.lblVersion.text = "ver " + version
        }
        
        if (UserDefaults.standard.object(forKey: EnterPriseURL) != nil) {
            if let baseurl : String = UserDefaults.standard.object(forKey: EnterPriseURL) as? String{
                if baseurl.contains(".com") == false {
                }
            }
            else{
            }
        }
        else{
        }
        self.btnBack.isHidden = true
        if self.isFromDifferentUser {
            self.btnBack.isHidden = false
        }
        if (appDel?.userPreferenceObj.iSREMEMBER)! {
            if let userNameStr : String = appDel?.userPreferenceObj.uSERNAME {
                txtUserName.text = userNameStr
                self.btnCheckUncheck.isSelected = true
            }
            if let PasswordStr : String = appDel?.userPreferenceObj.pASSWORD{
                txtPassword.text = PasswordStr
                self.btnCheckUncheck.isSelected = true
            }
        }
        if self.isFromDifferentUser {
            self.btnBack.isHidden = false
            self.btnCheckUncheck.isSelected = false
            txtUserName.text = ""
            txtPassword.text = ""
        }
        
        btnInstance.titleLabel?.adjustsFontSizeToFitWidth = true
        btnInstance.setTitle(baseUrl.replacingOccurrences(of: "/api/", with: ""), for: .normal)
        btnInstance.sizeToFit()
        
        btnEye.setImage(UIImage.fontAwesomeIcon(name: .eye, textColor: .white, size: CGSize(width: 26, height: 26)), for: .normal)
        btnEye.setImage(UIImage.fontAwesomeIcon(name: .eyeSlash, textColor: .white, size: CGSize(width: 26, height: 26)), for: .selected)
    }
    
    
    @IBAction func onEye(_ sender: UIButton) {
        btnEye.isSelected = !btnEye.isSelected
        if btnEye.isSelected {
            txtPassword.isSecureTextEntry.toggle()
        }
        else {
            txtPassword.isSecureTextEntry.toggle()
        }
    }
    
    
    @IBAction func onTermsOfServices(_ sender: Any) {
        UIApplication.shared.open(NSURL(string: urlTermsOFUse)! as URL)
    }

    override func viewDidLayoutSubviews() {
        scrollHeight.constant = (appDel?.window?.frame.size.height)!
        if scrollHeight.constant < 440{
            scrollHeight.constant = 440
        }
    }
    
    @IBAction func onBackToTouchId(_ sender: UIButton) {
        let loginVc = appDel?.mainStoryBoard.instantiateViewController(withIdentifier: "LoginTouchVC") as? LoginTouchVC
        appDel?.window?.rootViewController = loginVc
        appDel?.window?.makeKeyAndVisible();
        //self.navigationController?.pushViewController(loginVc!, animated: true)
    }
    
    @IBAction func onBack(_ sender: Any) {
        if isFromDifferentUser {
            let urlVc = appDel?.mainStoryBoard.instantiateViewController(withIdentifier: "WIPEnterPriseURLVC") as? WIPEnterPriseURLVC
            //self.navigationController?.pushViewController(urlVc!, animated: true)
            appDel?.window?.rootViewController = urlVc
            appDel?.window?.makeKeyAndVisible();
        }
        else {
            let urlVc = appDel?.mainStoryBoard.instantiateViewController(withIdentifier: "WIPEnterPriseURLVC") as? WIPEnterPriseURLVC
            //self.navigationController?.pushViewController(urlVc!, animated: true)
            appDel?.window?.rootViewController = urlVc
            appDel?.window?.makeKeyAndVisible();
            //self.navigationController?.popViewController(animated: true)
        }
    }
    
    
    @IBAction func onSignIn(_ sender: Any) {
        self.view.endEditing(true)
        if txtUserName.text?.count == 0 {
            self.view.makeToast("Please enter login name")
            return
        }
        if txtPassword.text?.count == 0 {
            self.view.makeToast("Please enter password")
            return
        }
        let strUsrname = txtUserName.text?.toBase64()
        let strPassword = txtPassword.text?.toBase64()

        let newStr = strUsrname! + ":" + strPassword!
        let finalStr = "Basic " + newStr.toBase64()
        
        let str : String = (appDel?.deviceUDID)!
        let params = ["DeviceToken": "" ,"DeviceID" : str,"Version":"1.0"]
        
        appDel?.webServiceObj.Login(url: "authenticate/login", headerValue: finalStr, dic: params as [String : AnyObject], block: { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    
                    let userDict  = dataResponse
                    print(userDict as Any)
                   
                    let userObj = User()
                    userObj.setAttributeInfo(json:userDict!)
                    
                    if userObj.SessionId.count > 10{
                        
                        userImage = userObj.IMAGE_NAME
                        UserDefaults.standard.set(userImage, forKey: "userImage")
                        let userBG = NSKeyedArchiver.archivedData(withRootObject: userDict as Any)
                        UserDefaults.standard.set(userBG, forKey: userData)
                        
                        UserDefaults.standard.set(userObj.SessionId, forKey: sessionToken)
                        if (appDel?.userPreferenceObj.iSSESSIONEXPIRED)! {
                            if appDel?.selectedOption != nil {
                                var resetCode : String = ""
                                resetCode = (appDel?.selectedOption)!
                                
                                print(resetCode)
                                               
                               var selectedDoc = [DocumentUploadModel]()
                               DispatchQueue.main.async {
                                   
                                   let fileManager = FileManager.default
                                if !fileManager.fileExists(atPath: (appDel?.documentsDirectory())!){
                                       try! fileManager.createDirectory(atPath: (appDel?.documentsDirectory())!, withIntermediateDirectories: true, attributes: nil)
                                   }
                                   
                                   let localFiles = try! FileManager.default.contentsOfDirectory(atPath: (appDel?.documentsDirectory())!)
                                   appDel?.documentsProvider?.contentsOfDirectory(path: "/", completionHandler: { (fileObjects, error) in
                                       for i in 0..<fileObjects.count {
                                           print("Name: \(fileObjects[i].name)")
                                           print("Size: \(fileObjects[i].size)")
                                           print("Path: \(fileObjects[i].path)")
                                           print("Url: \(fileObjects[i].url)")
                                           
                                           if !localFiles.contains(where: { $0.contains(fileObjects[i].name) }) {
                                            let destination = URL(fileURLWithPath: (appDel?.documentsDirectory())! + "/" + fileObjects[i].name)
                                               print("Copying \(fileObjects[i].url) to \(destination)......")
                                               do {
                                                   try FileManager.default.copyItem(at: fileObjects[i].url.absoluteURL, to: destination)
                                                   print("Done.")
                                                   
                                                   let modelDoc = DocumentUploadModel()
                                                   
                                                   modelDoc.docURL = destination
                                                   
                                                   if let cert = NSData(contentsOfFile: destination.path) {
                                                       modelDoc.dataOfDoc = cert as Data
                                                   }
                                                   modelDoc.image = UIImage(data: modelDoc.dataOfDoc)
                                                   if modelDoc.image == nil {
                                                       modelDoc.image = UIImage(named: "Document")
                                                   }
                                                   modelDoc.docID = 0
                                                   modelDoc.docName = (modelDoc.docURL?.absoluteString.components(separatedBy: "/").last)!.removingPercentEncoding!
                                                   modelDoc.imageName = modelDoc.docName//.replacingOccurrences(of: "%20", with: " ")
                                                   modelDoc.strExtention = "." + modelDoc.docURL.pathExtension
                                                   modelDoc.mimeType = MimeType(url: modelDoc.docURL).value
                                                   selectedDoc.append(modelDoc)
                                                   
                                                   if i == fileObjects.count - 1 {
                                                       do {
                                                        if fileManager.fileExists(atPath: (appDel?.containerURL.path)!) {
                                                            try fileManager.removeItem(atPath: (appDel?.containerURL.path)!)
                                                           }
                                                       } catch let error as NSError {
                                                           print(error.debugDescription)
                                                       }
                                                       DispatchQueue.main.async {
                                                           if selectedDoc.count == fileObjects.count {
                                                               if resetCode == selectedOptionKeyTask {
                                                                   let importVC : CreateTaskNewVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateTaskNewVC") as? CreateTaskNewVC)!
                                                                   importVC.selectedDocuments = selectedDoc
                                                                   importVC.allProject = false
                                                                   importVC.isFromShareScreen = true
                                                                   importVC.selectedUserID = (appDel?.userObj.USERID)!
                                                                  
                                                                   let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                                   let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                                   VC.pushViewController(importVC, animated: true)
                                                               }
                                                               else if resetCode == selectedOptionKeyTaskExist {
                                                                   let importVC : AttachToExistingVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "AttachToExistingVC") as? AttachToExistingVC)!
                                                                   importVC.selectedDocuments = selectedDoc
                                                                   importVC.isFromECM = false
                                                                  
                                                                   let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                                   let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                                   VC.pushViewController(importVC, animated: true)
                                                               }
                                                               else if resetCode == selectedOptionKeyTicket {
                                                                   let importVC : CreateTicketVC = (appDel?.WIPNewStoryBoard.instantiateViewController(withIdentifier: "CreateTicketVC") as? CreateTicketVC)!
                                                                   importVC.selectedDocuments = selectedDoc
                                                                   
                                                                   let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                                   let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                                   VC.pushViewController(importVC, animated: true)
                                                               }
                                                               else if resetCode == selectedOptionKeyTicketExist {
                                                                   let importVC : ExistingTicketVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ExistingTicketVC") as? ExistingTicketVC)!
                                                                   importVC.selectedDocuments = selectedDoc
                                                                   importVC.isFromECM = false
                                                                   
                                                                   let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                                   let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                                   VC.pushViewController(importVC, animated: true)
                                                               }
                                                               else if resetCode == selectedOptionKeyToDoExist {
                                                                   let importVC : ExistingTodoVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ExistingTodoVC") as? ExistingTodoVC)!
                                                                   importVC.selectedDocuments = selectedDoc
                                                                   importVC.isFromECM = false
                                                                   
                                                                   let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                                   let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                                   VC.pushViewController(importVC, animated: true)
                                                               }
                                                               else if resetCode == selectedOptionKeyECM {
                                                                   let importVC : ImportExternalDocumentVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ImportExternalDocumentVC") as? ImportExternalDocumentVC)!
                                                                   importVC.docArray = selectedDoc
                                                                   
                                                                   let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                                   let VC : UINavigationController = appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                                   VC.pushViewController(importVC, animated: true)
                                                               }
                                                               else if resetCode == selectedOptionKeyCreateToDo {
                                                                   
                                                                   let importVC : CreateToDoVC = (appDel?.todoStoryBoard.instantiateViewController(withIdentifier: "CreateToDoVC") as? CreateToDoVC)!
                                                                   importVC.selectedDocuments = selectedDoc
                                                                   
                                                                   let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                                   let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                                   VC.pushViewController(importVC, animated: true)
                                                               
                                                               }
                                                               else if resetCode == selectedOptionKeyActivityExist {
                                                                   let importVC : AttachToExistingActivityVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "AttachToExistingActivityVC") as? AttachToExistingActivityVC)!
                                                                   importVC.selectedDocuments = selectedDoc
                                                                   importVC.isFromECM = false
                                                                   
                                                                   let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                                   let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                                   VC.pushViewController(importVC, animated: true)
                                                               }
                                                               else if resetCode == selectedOptionKeyExistingLeads {
                                                                   let importVC : ExistingLeadVC = (appDel?.crmStoryBoard.instantiateViewController(withIdentifier: "ExistingLeadVC") as? ExistingLeadVC)!
                                                                   importVC.selectedDocuments = selectedDoc
                                                                   let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                                   let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                                   VC.pushViewController(importVC, animated: true)
                                                               }
                                                               else if resetCode == selectedOptionKeyexistingOpportunity {
                                                                   let importVC : ExistingOpportunityVC = (appDel?.crmStoryBoard.instantiateViewController(withIdentifier: "ExistingOpportunityVC") as? ExistingOpportunityVC)!
                                                                   importVC.selectedDocuments = selectedDoc
                                                                   
                                                                   let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                                   let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                                   VC.pushViewController(importVC, animated: true)
                                                               }
                                                               else if resetCode == selectedOptionKeyActivity {
                                                                   let importVC : CreateActivityVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateActivityVC") as? CreateActivityVC)!
                                                                   importVC.selectedDocuments = selectedDoc
                                                                   
                                                                   let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                                   let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                                   VC.pushViewController(importVC, animated: true)
                                                               }
                                                               else {
                                           //                        let importVC : ImportExternalDocumentVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ImportExternalDocumentVC") as? ImportExternalDocumentVC)!
                                           //                        importVC.docURL = url
                                           //                        docURL = url
                                           //                        let selectedINdex = mainTabbar.selectedIndex
                                           //                        let VC : UINavigationController =  mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                           //                        VC.pushViewController(importVC, animated: true)
                                                               }
                                                           }
                                                           else {
                                                               DispatchQueue.main.async {
                                                                   CommonFunctions().showAlert(msg: msgSomethingWrong)
                                                               }
                                                           }
                                                       }
                                                   }
                                               } catch {
                                                   print("Could not copy file. Error: \(error)")
                                                   DispatchQueue.main.async {
                                                       CommonFunctions().showAlert(msg: "Error while copying files!")
                                                   }
                                               }
                                           }
                                           else {
                                               print("File exist")
                                            let destination = URL(fileURLWithPath: (appDel?.documentsDirectory())! + "/" + fileObjects[i].name)
                                               
                                               let modelDoc = DocumentUploadModel()
                                               
                                               modelDoc.docURL = destination
                                               
                                               if let cert = NSData(contentsOfFile: destination.path) {
                                                   modelDoc.dataOfDoc = cert as Data
                                               }
                                               modelDoc.image = UIImage(data: modelDoc.dataOfDoc)
                                               if modelDoc.image == nil {
                                                   modelDoc.image = UIImage(named: "Document")
                                               }
                                               modelDoc.docID = 0
                                               modelDoc.docName = (modelDoc.docURL?.absoluteString.components(separatedBy: "/").last)!.removingPercentEncoding!
                                               modelDoc.imageName = modelDoc.docName//.replacingOccurrences(of: "%20", with: " ")
                                               modelDoc.strExtention = "." + modelDoc.docURL.pathExtension
                                               modelDoc.mimeType = MimeType(url: modelDoc.docURL).value
                                               selectedDoc.append(modelDoc)
                                               
                                               if i == fileObjects.count - 1 {
                                                   do {
                                                    if fileManager.fileExists(atPath: (appDel?.containerURL.path)!) {
                                                           try fileManager.removeItem(atPath: (appDel?.containerURL.path)!)
                                                       }
                                                   } catch let error as NSError {
                                                       print(error.debugDescription)
                                                   }
                                                   DispatchQueue.main.async {
                                                       if selectedDoc.count == fileObjects.count {
                                                           if resetCode == selectedOptionKeyTask {
                                                               let importVC : CreateTaskNewVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateTaskNewVC") as? CreateTaskNewVC)!
                                                               importVC.selectedDocuments = selectedDoc
                                                               importVC.allProject = false
                                                               importVC.isFromShareScreen = true
                                                               importVC.selectedUserID = (appDel?.userObj.USERID)!
                                                              
                                                               let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                               let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                               VC.pushViewController(importVC, animated: true)
                                                           }
                                                           else if resetCode == selectedOptionKeyTaskExist {
                                                               let importVC : AttachToExistingVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "AttachToExistingVC") as? AttachToExistingVC)!
                                                               importVC.selectedDocuments = selectedDoc
                                                               importVC.isFromECM = false
                                                              
                                                               let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                               let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                               VC.pushViewController(importVC, animated: true)
                                                           }
                                                           else if resetCode == selectedOptionKeyTicket {
                                                               let importVC : CreateTicketVC = (appDel?.WIPNewStoryBoard.instantiateViewController(withIdentifier: "CreateTicketVC") as? CreateTicketVC)!
                                                               importVC.selectedDocuments = selectedDoc
                                                               
                                                               let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                               let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                               VC.pushViewController(importVC, animated: true)
                                                           }
                                                           else if resetCode == selectedOptionKeyTicketExist {
                                                               let importVC : ExistingTicketVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ExistingTicketVC") as? ExistingTicketVC)!
                                                               importVC.selectedDocuments = selectedDoc
                                                               importVC.isFromECM = false
                                                               
                                                               let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                               let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                               VC.pushViewController(importVC, animated: true)
                                                           }
                                                           else if resetCode == selectedOptionKeyToDoExist {
                                                               let importVC : ExistingTodoVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ExistingTodoVC") as? ExistingTodoVC)!
                                                               importVC.selectedDocuments = selectedDoc
                                                               importVC.isFromECM = false
                                                               
                                                               let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                               let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                               VC.pushViewController(importVC, animated: true)
                                                           }
                                                           else if resetCode == selectedOptionKeyECM {
                                                               let importVC : ImportExternalDocumentVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ImportExternalDocumentVC") as? ImportExternalDocumentVC)!
                                                               importVC.docArray = selectedDoc
                                                               
                                                               let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                               let VC : UINavigationController = appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                               VC.pushViewController(importVC, animated: true)
                                                           }
                                                           else if resetCode == selectedOptionKeyCreateToDo {
                                                               
                                                               let importVC : CreateToDoVC = (appDel?.todoStoryBoard.instantiateViewController(withIdentifier: "CreateToDoVC") as? CreateToDoVC)!
                                                               importVC.selectedDocuments = selectedDoc
                                                               
                                                               let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                               let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                               VC.pushViewController(importVC, animated: true)
                                                           
                                                           }
                                                           else if resetCode == selectedOptionKeyActivityExist {
                                                               let importVC : AttachToExistingActivityVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "AttachToExistingActivityVC") as? AttachToExistingActivityVC)!
                                                               importVC.selectedDocuments = selectedDoc
                                                               importVC.isFromECM = false
                                                               
                                                               let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                               let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                               VC.pushViewController(importVC, animated: true)
                                                           }
                                                           else if resetCode == selectedOptionKeyExistingLeads {
                                                               let importVC : ExistingLeadVC = (appDel?.crmStoryBoard.instantiateViewController(withIdentifier: "ExistingLeadVC") as? ExistingLeadVC)!
                                                               importVC.selectedDocuments = selectedDoc
                                                               let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                               let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                               VC.pushViewController(importVC, animated: true)
                                                           }
                                                           else if resetCode == selectedOptionKeyexistingOpportunity {
                                                               let importVC : ExistingOpportunityVC = (appDel?.crmStoryBoard.instantiateViewController(withIdentifier: "ExistingOpportunityVC") as? ExistingOpportunityVC)!
                                                               importVC.selectedDocuments = selectedDoc
                                                               
                                                               let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                               let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                               VC.pushViewController(importVC, animated: true)
                                                           }
                                                           else if resetCode == selectedOptionKeyActivity {
                                                               let importVC : CreateActivityVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateActivityVC") as? CreateActivityVC)!
                                                               importVC.selectedDocuments = selectedDoc
                                                               
                                                               let selectedINdex = (appDel?.mainTabbar.selectedIndex)!
                                                               let VC : UINavigationController =  appDel?.mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                                               VC.pushViewController(importVC, animated: true)
                                                           }
                                                           else {
                                       //                        let importVC : ImportExternalDocumentVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ImportExternalDocumentVC") as? ImportExternalDocumentVC)!
                                       //                        importVC.docURL = url
                                       //                        docURL = url
                                       //                        let selectedINdex = mainTabbar.selectedIndex
                                       //                        let VC : UINavigationController =  mainTabbar.viewControllers?[selectedINdex] as! UINavigationController
                                       //                        VC.pushViewController(importVC, animated: true)
                                                           }
                                                       }
                                                       else {
                                                           DispatchQueue.main.async {
                                                               CommonFunctions().showAlert(msg: msgSomethingWrong)
                                                           }
                                                       }
                                                   }
                                               }
                                           }
                                       }
                                   })
                               }
                            }
                        }
                        appDel?.userPreferenceObj = UserPreferences(userid: userObj.USERID, contactname: userObj.CONTACT_FIRSTNAME, contactlastname: userObj.CONTACT_LASTNAME, username: self.txtUserName.text!, password: self.txtPassword.text!, sessionid: userObj.SessionId, instance: baseUrl.replacingOccurrences(of: "/api/", with: ""), imagename: userObj.IMAGE_NAME, issessionexpired: false, isrememberme: self.btnCheckUncheck.isSelected, istouchid: false)
                        
                        CommonFunctions().setPreference()
                        CommonFunctions().parsePreference()
                        appDel?.userObj = userObj
                        appDel?.userID = 0
                        appDel?.selectedDate = ""
                        CommonFunctions().addMenus()
                        UserDefaults.standard.set(self.txtUserName.text, forKey: loginUserName)
                        UserDefaults.standard.set(self.txtPassword.text, forKey: loginPassword)
                        
                        /*
                        if self.btnCheckUncheck.isSelected == true{
                            UserDefaults.standard.set(self.txtUserName.text, forKey: loginUserName)
                            UserDefaults.standard.set(self.txtPassword.text, forKey: loginPassword)
                        }
                        else {
                            UserDefaults.standard.removeObject(forKey: loginUserName)
                            UserDefaults.standard.removeObject(forKey: loginPassword)
                        }
                         */
                        if appDel?.docURL?.absoluteString == nil {
                            appDel?.setDefaultTabBarNew()
                        }
                        else if appDel?.emailSharedDocURL?.absoluteString != nil {
                            appDel?.selectedIndex = 3
                            appDel?.setDefaultTabBarNew()
                        }
                        else {
                            let userdft = UserDefaults(suiteName: "group.com.workInProgress")
                            if let option : String = userdft?.object(forKey: selectedOptionKey) as? String {
                                if option == selectedOptionKeyTask {
                                    DispatchQueue.main.async {
                                        appDel?.selectedIndex = 0
                                        appDel?.setDefaultTabBarNew()
                                        var curentVC = UIViewController()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                            if let topVC = UIApplication.getTopViewController() {
                                                curentVC = topVC
                                                let importVC : CreateTaskNewVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateTaskNewVC") as? CreateTaskNewVC)!
                                                importVC.docURL = appDel?.docURL
                                                importVC.allProject = false
                                                importVC.isFromShareScreen = true
                                                importVC.selectedUserID = (appDel?.userObj.USERID)!
                                                curentVC.navigationController?.pushViewController(importVC, animated: true)
                                            }
                                        })
                                    }
                                }
                                else if option == selectedOptionKeyTaskExist {
                                    DispatchQueue.main.async {
                                        appDel?.selectedIndex = 3
                                        appDel?.setDefaultTabBarNew()
                                        var curentVC = UIViewController()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                            if let topVC = UIApplication.getTopViewController() {
                                                curentVC = topVC
                                                let importVC : AttachToExistingVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "AttachToExistingVC") as? AttachToExistingVC)!
                                                importVC.docURL = appDel?.docURL
                                                importVC.isFromECM = false
                                                curentVC.navigationController?.pushViewController(importVC, animated: true)
                                            }
                                        })
                                    }
                                }
                                else if option == selectedOptionKeyActivityExist {
                                    DispatchQueue.main.async {
                                        appDel?.selectedIndex = 3
                                        appDel?.setDefaultTabBarNew()
                                        var curentVC = UIViewController()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                            if let topVC = UIApplication.getTopViewController() {
                                                curentVC = topVC
                                                let importVC : AttachToExistingActivityVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "AttachToExistingActivityVC") as? AttachToExistingActivityVC)!
                                                importVC.docURL = appDel?.docURL
                                                importVC.isFromECM = false
                                                curentVC.navigationController?.pushViewController(importVC, animated: true)
                                            }
                                        })
                                    }
                                }
                                else if option == selectedOptionKeyExistingLeads {
                                    DispatchQueue.main.async {
                                        appDel?.selectedIndex = 3
                                        appDel?.setDefaultTabBarNew()
                                        var curentVC = UIViewController()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                            if let topVC = UIApplication.getTopViewController() {
                                                curentVC = topVC
                                                let importVC : ExistingLeadVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ExistingLeadVC") as? ExistingLeadVC)!
                                                importVC.docURL = appDel?.docURL
                                                curentVC.navigationController?.pushViewController(importVC, animated: true)
                                            }
                                        })
                                    }
                                }
                                else if option == selectedOptionKeyexistingOpportunity {
                                    DispatchQueue.main.async {
                                        appDel?.selectedIndex = 3
                                        appDel?.setDefaultTabBarNew()
                                        var curentVC = UIViewController()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                            if let topVC = UIApplication.getTopViewController() {
                                                curentVC = topVC
                                                let importVC : ExistingOpportunityVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ExistingOpportunityVC") as? ExistingOpportunityVC)!
                                                importVC.docURL = appDel?.docURL
                                                curentVC.navigationController?.pushViewController(importVC, animated: true)
                                            }
                                        })
                                    }
                                }
                                else if option == selectedOptionKeyTicket {
                                    DispatchQueue.main.async {
                                        appDel?.selectedIndex = 0
                                        appDel?.setDefaultTabBarNew()
                                        var curentVC = UIViewController()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                            if let topVC = UIApplication.getTopViewController() {
                                                curentVC = topVC
                                                let importVC : CreateTicketVC = (appDel?.WIPNewStoryBoard.instantiateViewController(withIdentifier: "CreateTicketVC") as? CreateTicketVC)!
                                                importVC.docURL = appDel?.docURL
                                                curentVC.navigationController?.pushViewController(importVC, animated: true)
                                            }
                                        })
                                    }
                                }
                                else if option == selectedOptionKeyTicketExist {
                                    DispatchQueue.main.async {
                                        appDel?.selectedIndex = 3
                                        appDel?.setDefaultTabBarNew()
                                        var curentVC = UIViewController()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                            if let topVC = UIApplication.getTopViewController() {
                                                curentVC = topVC
                                                let importVC : ExistingTicketVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ExistingTicketVC") as? ExistingTicketVC)!
                                                importVC.docURL = appDel?.docURL
                                                importVC.isFromECM = false
                                                curentVC.navigationController?.pushViewController(importVC, animated: true)
                                            }
                                        })
                                    }
                                }
                                else if option == selectedOptionKeyToDoExist {
                                    DispatchQueue.main.async {
                                        appDel?.selectedIndex = 3
                                        appDel?.setDefaultTabBarNew()
                                        var curentVC = UIViewController()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                            if let topVC = UIApplication.getTopViewController() {
                                                curentVC = topVC
                                                let importVC : ExistingTodoVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ExistingTodoVC") as? ExistingTodoVC)!
                                                importVC.docURL = appDel?.docURL
                                                importVC.isFromECM = false
                                                curentVC.navigationController?.pushViewController(importVC, animated: true)
                                            }
                                        })
                                    }
                                }
                                else if option == selectedOptionKeyECM {
                                    appDel?.selectedIndex = 3
                                    appDel?.setDefaultTabBarNew()
                                    var curentVC = UIViewController()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                        if let topVC = UIApplication.getTopViewController() {
                                            curentVC = topVC
                                            let importVC : ImportExternalDocumentVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ImportExternalDocumentVC") as? ImportExternalDocumentVC)!
                                            importVC.docURL = appDel?.docURL
                                            curentVC.navigationController?.pushViewController(importVC, animated: true)
                                        }
                                    })
                                }
                                else if option == selectedOptionKeyCreateToDo {
                                    DispatchQueue.main.async {
                                        appDel?.selectedIndex = 0
                                        appDel?.setDefaultTabBarNew()
                                        var curentVC = UIViewController()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                            if let topVC = UIApplication.getTopViewController() {
                                                curentVC = topVC
                                                let importVC : CreateToDoVC = (appDel?.todoStoryBoard.instantiateViewController(withIdentifier: "CreateToDoVC") as? CreateToDoVC)!
                                                importVC.docURL = appDel?.docURL
                                                curentVC.navigationController?.pushViewController(importVC, animated: true)
                                            }
                                        })
                                    }
                                }
                                else if option == selectedOptionKeyActivity {
                                    DispatchQueue.main.async {
                                        appDel?.selectedIndex = 0
                                        appDel?.setDefaultTabBarNew()
                                        var curentVC = UIViewController()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                            if let topVC = UIApplication.getTopViewController() {
                                                curentVC = topVC
                                                let importVC : CreateActivityVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateActivityVC") as? CreateActivityVC)!
                                                importVC.docURL = appDel?.docURL
                                                curentVC.navigationController?.pushViewController(importVC, animated: true)
                                            }
                                        })
                                    }
                                }
                            }
                            else {
                                appDel?.selectedIndex = 3
                                appDel?.setDefaultTabBarNew()
                                var curentVC = UIViewController()
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                                    if let topVC = UIApplication.getTopViewController() {
                                        curentVC = topVC
                                        let importVC : ImportExternalDocumentVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ImportExternalDocumentVC") as? ImportExternalDocumentVC)!
                                        importVC.docURL = appDel?.docURL
                                        curentVC.navigationController?.pushViewController(importVC, animated: true)
                                    }
                                })
                            }
                        }
                    }
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    self.view.makeToast("Authentication failed")
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    self.view.makeToast("Authentication failed")
                }

            }
        })
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func onCheckUncheck(_ sender: Any) {
        btnCheckUncheck.isSelected = !btnCheckUncheck.isSelected
    }
    
    @IBAction func OnForgot(_ sender: UIButton) {
        
        UserDefaults.standard.set(self.txtUserName.text, forKey: forgotUserName)
        let loginVc = appDel?.mainStoryBoard.instantiateViewController(withIdentifier: "WIPForgotPasswordVC") as? WIPForgotPasswordVC
        loginVc?.isFromLogin = true
        appDel?.window?.rootViewController = loginVc
        appDel?.window?.makeKeyAndVisible();
    }
}
extension String {
    
    func fromBase64() -> String? {
        guard let data = Data(base64Encoded: self) else {
            return nil
        }
        
        return String(data: data, encoding: .utf8)
    }
    
    func toBase64() -> String {
        return Data(self.utf8).base64EncodedString()
    }
}

