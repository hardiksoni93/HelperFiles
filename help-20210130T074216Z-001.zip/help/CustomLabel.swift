import Foundation
import UIKit

class CustomLabel: UILabel {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setProperties()
    }
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        setProperties()
    }
    private func setProperties() {
        self.backgroundColor = hexStringToUIColor(hex: "#2AA53F")
        if let colorcode : String = UserDefaults.standard.object(forKey: "SelectedThemeBorder") as? String{
            self.backgroundColor = hexStringToUIColor(hex: colorcode)
        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

class CustomLabelText : UILabel {
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setProperties()
    }
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        self.setProperties()
    }
    private func setProperties() {
        
        self.textColor = hexStringToUIColor(hex: "#2AA53F")
        if let colorcode : String = UserDefaults.standard.object(forKey: "SelectedThemeBorder") as? String {
            self.textColor = hexStringToUIColor(hex: colorcode)
        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}


class CustomLabelBorder : UILabel {
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setProperties()
    }
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        self.setProperties()
    }
    private func setProperties() {
        self.layer.borderColor = hexStringToUIColor(hex: "#2AA53F").cgColor //default green color
        self.textColor = hexStringToUIColor(hex: "#2AA53F")
        if let colorcode : String = UserDefaults.standard.object(forKey: "SelectedThemeBorder") as? String {
            self.layer.borderColor = hexStringToUIColor(hex: colorcode).cgColor
            self.textColor = hexStringToUIColor(hex: colorcode)
        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}
