//
//  TaskDetailsCell.swift
//  WorkInProgress
//
//  Created by Arpit Shah on 11/09/17.
//  Copyright © 2017 Arpit Shah. All rights reserved.
//

import Foundation
import UIKit

class TaskDetailsCell : UITableViewCell{
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblValue : UILabel!
    
    func setValues(objAttribute : Attribute){
        if objAttribute.nane == "This is gap" {
            lblName.text = ""
            lblValue.text = ""
        }
        else  {
            lblName.text = objAttribute.nane
            lblValue.text = objAttribute.value
            lblName.numberOfLines = 10
            lblValue.numberOfLines = 10
            lblValue.sizeToFit()
            lblValue.textColor = UIColor.darkGray
        }
    }
}
