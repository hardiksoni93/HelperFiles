//
//  LoginTouchVC.swift
//  WorkInProgress
//
//  Created by AONMac on 04/07/19.
//  Copyright © 2019 Arpit Shah. All rights reserved.
//

import UIKit
import SDWebImage
import LocalAuthentication

class LoginTouchVC: UIViewController {

    @IBOutlet var lblVersion: UILabel!
    
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblInstance: UILabel!
    @IBOutlet weak var lblDifferentUserlogin: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setInitialViews()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewDidAppear(true)
        
        CommonFunctions.AppUtility.lockOrientation(.all)
    }
    
    func setInitialViews() {
        
        let value = UIInterfaceOrientation.portrait.rawValue
        UIDevice.current.setValue(value, forKey: "orientation")
        CommonFunctions.AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        
        if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
            self.lblVersion.text = "ver " + version
        }
        
        CommonFunctions().parsePreference()
        lblUsername.text = "Welcome " + (appDel?.userPreferenceObj.cONTACTNAME)!
        
        if ((appDel?.userPreferenceObj.iMAGE_NAME)! == ""){
            imgUser.isHidden = true
            lblUserName.isHidden = false
            lblUserName.backgroundColor = UIColor.darkGray
            
            let userInitial : String = CommonFunctions().generateInitial(username: (appDel?.userPreferenceObj.cONTACTNAME)! + " " +  (appDel?.userPreferenceObj.cONTACTLASTNAME)!)
            
            lblUserName.text = userInitial
            lblUserName.textAlignment = .center
            
        }
        else{
            lblUserName.isHidden = true
            imgUser.isHidden = false
            let strValue = (String(describing: (appDel?.userPreferenceObj.uSERID)!))
            imgUser.sd_setImage(with: URL(string: baseContactImageURL + strValue + "/image?filename=" + (appDel?.userPreferenceObj.iMAGE_NAME)!), placeholderImage: UIImage(named: "placeholder"))
        }
        
        lblInstance.attributedText = CommonFunctions().setDashUnderline(title1: "", title2: String(describing: (appDel?.userPreferenceObj.iNSTANCE)!), fontName1: gothamBook, fontSize1: 12, fontColor1: UIColor.white)
        
        lblDifferentUserlogin.attributedText = CommonFunctions().setDashUnderline(title1: "", title2: "Not " + String(describing: (appDel?.userPreferenceObj.cONTACTNAME)!) + "? Login as a different user", fontName1: gothamBook, fontSize1: 12, fontColor1: UIColor.white)
    }
    
    //MARK: BUTTON ACTION
    @IBAction func OnForgot(_ sender: UIButton) {
        
        UserDefaults.standard.set((appDel?.userPreferenceObj.uSERNAME)!, forKey: forgotUserName)
        let loginVc = appDel?.mainStoryBoard.instantiateViewController(withIdentifier: "WIPForgotPasswordVC") as? WIPForgotPasswordVC
        loginVc?.isFromLogin = false
        appDel?.window?.rootViewController = loginVc
        appDel?.window?.makeKeyAndVisible();
        //self.navigationController?.pushViewController(loginVc!, animated: true)
    }
    
    @IBAction func onInstance(_ sender: UIButton) {
        let urlVc = appDel?.mainStoryBoard.instantiateViewController(withIdentifier: "WIPEnterPriseURLVC") as? WIPEnterPriseURLVC
        appDel?.window?.rootViewController = urlVc
        appDel?.window?.makeKeyAndVisible();
        //self.navigationController?.pushViewController(urlVc!, animated: true)
    }
    
    @IBAction func onDiffrentUser(_ sender: UIButton) {
        let loginVc = appDel?.mainStoryBoard.instantiateViewController(withIdentifier: "WIPLoginVC") as? WIPLoginVC
        loginVc?.isFromDifferentUser = true
        appDel?.window?.rootViewController = loginVc
        appDel?.window?.makeKeyAndVisible();
        //self.navigationController?.pushViewController(loginVc!, animated: true)
    }
    
    @IBAction func onFingertouch(_ sender: UIButton) {
        self.authenticateUserTouchID()
    }
    func isBiometryReady(completion: @escaping (Bool) -> Void)
    {
        let context : LAContext = LAContext();
        var error : NSError?
        
        context.localizedFallbackTitle = ""
        if #available(iOS 10.0, *) {
            context.localizedCancelTitle = "Authentication required to login user."
        } else {
            context.localizedFallbackTitle = "Authentication required to login user."
            // Fallback on earlier versions
        }
        
        if (context.canEvaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, error: &error))
        {
            completion(true)
        }
        else if error?.code == -5
        {
            completion(false)
        }
        else if (context.canEvaluatePolicy(LAPolicy.deviceOwnerAuthentication, error: &error)) {
            completion(true)
        }
        else if error?.code == -7
        {
            self.loginUsingPasscode()
        }
        else if error?.code == -8
        {
            let reason:String = "TouchID/Passcode has been locked out due to few fail attemp. Enter iPhone passcode to enable login.";
            context.evaluatePolicy(LAPolicy.deviceOwnerAuthentication, localizedReason: reason, reply: { (success, error) in
                                    
                print("Touch id enable")
                if success // IF TOUCH ID AUTHENTICATION IS SUCCESSFUL, NAVIGATE TO NEXT VIEW CONTROLLER
                {   self.startLoginProcedure()
                }
                else // IF TOUCH ID AUTHENTICATION IS FAILED, PRINT ERROR MSG
                {
                    guard let eror = error else {
                        return
                    }
                    print(self.evaluateAuthenticationPolicyMessageForLA(errorCode: eror._code))
                }
            })
        }
        else {
           completion(false)
        }
    }
    
    func authenticateUserTouchID() {
        let context : LAContext = LAContext()
        // Declare a NSError variable.
        context.localizedFallbackTitle = "Use Passcode"
        let myLocalizedReasonString = "Authentication required to login user."
        var authError: NSError?
        self.isBiometryReady() { (istrue) in
            if istrue {
                if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &authError) {
                    context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: myLocalizedReasonString) { success, evaluateError in
                        if success // IF TOUCH ID AUTHENTICATION IS SUCCESSFUL, NAVIGATE TO NEXT VIEW CONTROLLER
                        {
                            self.startLoginProcedure()
                        }
                        else // IF TOUCH ID AUTHENTICATION IS FAILED, PRINT ERROR MSG
                        {
                            guard let error = evaluateError else {
                                return
                            }
                            print(self.evaluateAuthenticationPolicyMessageForLA(errorCode: error._code))
                        }
                    }
                }
                else // IF TOUCH ID AUTHENTICATION IS FAILED, PRINT ERROR MSG
                {
                    guard let error = authError else {
                        return
                    }
                    print(self.evaluateAuthenticationPolicyMessageForLA(errorCode: error._code))
                }
            }
            else {
                CommonFunctions().showDispatchMessage(msg: "Touch ID and Passcode not set in your device. Set Touch ID and Passcode to login.")
                return
            }
        }
    }
    
    func evaluatePolicyFailErrorMessageForLA(errorCode: Int) -> String {
        var message = ""
        if #available(iOS 11.0, macOS 10.13, *) {
            switch errorCode {
            case LAError.biometryNotAvailable.rawValue:
                message = "Authentication could not start because the device does not support biometric authentication."
                CommonFunctions().showDispatchMessage(msg: "Your device does not support biometric authentication.")
                
            case LAError.biometryLockout.rawValue:
                message = "Authentication could not continue because the user has been locked out of biometric authentication, due to failing authentication too many times."
                CommonFunctions().showDispatchMessage(msg: "Too many failed attempts. Please try after few mins.")
                
            case LAError.biometryNotEnrolled.rawValue:
                message = "Authentication could not start because the user has not enrolled in biometric authentication."
                self.loginUsingPasscode()
            default:
                message = "Did not find error code on LAError object"
            }
        } else {
            switch errorCode {
            case LAError.touchIDLockout.rawValue:
                message = "Too many failed attempts."
                CommonFunctions().showDispatchMessage(msg: "Too many failed attempts. Please try after few mins.")
                
            case LAError.touchIDNotAvailable.rawValue:
                message = "TouchID is not available on the device"
                CommonFunctions().showDispatchMessage(msg: "Your device does not support biometric authentication.")
                
            case LAError.touchIDNotEnrolled.rawValue:
                message = "TouchID is not enrolled on the device"
                self.loginUsingPasscode()
                
            default:
                message = "Did not find error code on LAError object"
            }
        }
        
        return message;
    }
    
    func evaluateAuthenticationPolicyMessageForLA(errorCode: Int) -> String {
        
        var message = ""
        
        switch errorCode {
            
        case LAError.authenticationFailed.rawValue:
            message = "The user failed to provide valid credentials"
            
        case LAError.appCancel.rawValue:
            message = "Authentication was cancelled by application"
            
        case LAError.invalidContext.rawValue:
            message = "The context is invalid"
            
        case LAError.notInteractive.rawValue:
            message = "Not interactive"
            
        case LAError.passcodeNotSet.rawValue:
            message = "Passcode is not set on the device"
            self.loginUsingPasscode()
            
        case LAError.systemCancel.rawValue:
            message = "Authentication was cancelled by the system"
            
        case LAError.userCancel.rawValue:
            message = "The user did cancel"
            
        case LAError.userFallback.rawValue:
            message = "The user chose to use the fallback"
            
        default:
            message = evaluatePolicyFailErrorMessageForLA(errorCode: errorCode)
        }
        
        return message
    }
    
    func startLoginProcedure() {
        DispatchQueue.main.async{
            print("Authentication success by the system")
            appDel?.window?.makeToast("Authentication success by the device, Please wait connecting you to server.")
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute: {
                let strUsrname = appDel?.userPreferenceObj.uSERNAME.toBase64()
                let strPassword = appDel?.userPreferenceObj.pASSWORD.toBase64()
                
                let newStr = strUsrname! + ":" + strPassword!
                let finalStr = "Basic " + newStr.toBase64()
                
                let str : String = (appDel?.deviceUDID)!
                let params = ["DeviceToken": "" ,"DeviceID" : str,"Version":"1.0"]
                
                CommonFunctions().apiRequestToLogin(encryptdata: finalStr, finalKeyValueDict: params as [String : AnyObject], vc: self)
            })
        }
    }
    
    func loginUsingPasscode() {
        
        let context : LAContext = LAContext();

        context.localizedFallbackTitle = ""
        if #available(iOS 10.0, *) {
            context.localizedCancelTitle = "Authentication required to login user."
        } else {
            context.localizedFallbackTitle = "Authentication required to login user."
            // Fallback on earlier versions
        }
        let reason:String = "Your Touch Id not setup. Enter Passcode to login.";
        context.evaluatePolicy(LAPolicy.deviceOwnerAuthentication, localizedReason: reason, reply: { (success, error) in
            
            print("Authentication success by the system passcode")
            if success // IF TOUCH ID AUTHENTICATION IS SUCCESSFUL, NAVIGATE TO NEXT VIEW CONTROLLER
            {   self.startLoginProcedure()
            }
            else // IF TOUCH ID AUTHENTICATION IS FAILED, PRINT ERROR MSG
            {
                guard let eror = error else {
                    return
                }
                print(self.evaluateAuthenticationPolicyMessageForLA(errorCode: eror._code))
            }
        })
    }
}
