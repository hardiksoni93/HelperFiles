
import Foundation
import UIKit

class CustomButtons: UIButton {
    override init(frame: CGRect) {
        super.init(frame: frame)
        setProperties()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setProperties()
    }
    
    private func setProperties() {
        self.backgroundColor = hexStringToUIColor(hex: "#2AA53F")
        if let colorcode : String = UserDefaults.standard.object(forKey: "SelectedThemeBorder") as? String{
            self.backgroundColor = hexStringToUIColor(hex: colorcode)
        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

class CustomButtonText : UIButton {
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setProperties()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.setProperties()
    }
    
    private func setProperties() {
        self.setTitleColor(hexStringToUIColor(hex: "#2AA53F"), for: .normal)
        self.layer.borderColor = hexStringToUIColor(hex: "#2AA53F").cgColor
        if let colorcode : String = UserDefaults.standard.object(forKey: "SelectedThemeBorder") as? String{
            self.setTitleColor(hexStringToUIColor(hex: colorcode), for: .normal)
            self.layer.borderColor = hexStringToUIColor(hex: colorcode).cgColor
        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

