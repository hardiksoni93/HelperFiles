//
//  WIPMyTasksNewVC.swift
//  WorkInProgress
//
//  Created by Arpit Shah on 03/03/18.
//  Copyright © 2018 Arpit Shah. All rights reserved.
//

import Foundation
import UIKit
import ObjectMapper
import SVProgressHUD

class WIPMyTasksNewVC : UIViewController , UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var segmentedControl: DGSegmentedControl!
    @IBOutlet var iPhoneXHeight: NSLayoutConstraint!
    @IBOutlet var lblHeader : UILabel!
    @IBOutlet weak var cVTasks: UICollectionView!
    @IBOutlet weak var segmentHeightConstraints: NSLayoutConstraint!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tblMenu: UITableView!
    @IBOutlet weak var actionMenu: UIView!
    @IBOutlet weak var iphoneXmenu: NSLayoutConstraint!
    
    var tap = UITapGestureRecognizer()
    
    var activeCell: MyTasksCVCell!
    var AlltaskArray = [MyTaskModel]()
    var myTaskArray = [MyTaskModel]()
    var myTaskSelected : MyTaskModel?
    var selectedStatusStr = "1"
    var refreshControl2: UIRefreshControl!
    var swipDown = UISwipeGestureRecognizer()
    var taskActionMenu : [String] = []
    
    override func viewDidLoad() {
        CommonFunctions().animate()

        if iphoneX == false {
            iPhoneXHeight.constant = 0
            iphoneXmenu.constant = 0
        }   
        self.actionMenu.isHidden = true
        tap = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboard))
        swipDown = UISwipeGestureRecognizer(target: self, action: #selector(self.dismissMenu))
        swipDown.direction = .down
      //  tblMenu.separatorStyle = .singleLine
        
        tblMenu.addGestureRecognizer(swipDown)
        tblMenu.reloadData()
        CommonFunctions().setSearchbar(searchbar: self.searchBar)
        setSegmentController()
        self.addrefreshController()
        self.setHeader()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        AlltaskArray.removeAll()
        myTaskArray.removeAll()
        if appDel?.isTaskType == 0 {
            segmentedControl.selectedIndex = 0
            segmentHeightConstraints.constant = 0
            segmentedControl.isHidden = true
        }
        else if appDel?.isTaskType == 1 {
            segmentedControl.selectedIndex = 1
            segmentHeightConstraints.constant = 40
        }
        else if appDel?.isTaskType == 2 {
            segmentedControl.selectedIndex = 0
            segmentHeightConstraints.constant = 40
        }
        else if appDel?.isTaskType == 4 {
            segmentedControl.selectedIndex = 0
            segmentHeightConstraints.constant = 0
            segmentedControl.isHidden = true
        }
        else if appDel?.isTaskType == 3 {
            segmentedControl.selectedIndex = 2
            segmentHeightConstraints.constant = 40
        }
        else {
            segmentedControl.selectedIndex = 0
        }
        self.segmentValueChanged(segmentedControl)
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        CommonFunctions().stopAnimate()
        self.searchBar.endEditing(true)
        self.searchBar.resignFirstResponder()
    }
    
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
        view.removeGestureRecognizer(tap)
    }
    
    @objc func dismissMenu() {
        self.actionMenu.hideWithCustomAnimation(animation: .curveLinear, hidden: true)
    }
    
    func addrefreshController(){
        refreshControl2 = UIRefreshControl()
        refreshControl2.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl2.addTarget(self, action: #selector(self.refresh), for: UIControl.Event.valueChanged)
        cVTasks.addSubview(refreshControl2)
    }
    
    //MARK: REFRESH TASK
    @objc func refresh(sender:AnyObject) {
        self.myTaskArray.removeAll()
        self.AlltaskArray.removeAll()
        cVTasks.reloadData()
        if appDel?.isTaskType == 0 {
            self.GetTaskAll()
        }
        else if appDel?.isTaskType == 4 {
            self.GetTaskMeeting()
        }
        else {
            self.GetTaskWithStatus(statusStr: self.selectedStatusStr)
        }

    }
    
    //MARK: ADD SWIPE GESTURE ON COLLECTIONVIEW
    func setGesture() {
        let swipeLeft : UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(self.userDidSwipeLeft(_:)))
        swipeLeft.direction = .left
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.userDidSwipeRight))
        swipeRight.direction = .right
        
        if self.segmentedControl.selectedIndex == 0 {
            
            cVTasks?.addGestureRecognizer(swipeLeft)
            cVTasks?.addGestureRecognizer(swipeRight)
        }
        else {
            cVTasks?.removeGestureRecognizer(swipeLeft)
            cVTasks?.removeGestureRecognizer(swipeRight)
        }
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        self.cVTasks?.collectionViewLayout.invalidateLayout()
        
        coordinator.animate(alongsideTransition: { context in
            
        }, completion: { context in
            
            self.tblMenu.reloadData()
            
            if UIDevice.current.orientation.isLandscape {
                self.tblMenu.isScrollEnabled = true
            }
            else {
                self.tblMenu.isScrollEnabled = false
            }
            
            self.cVTasks?.collectionViewLayout.invalidateLayout()
            
            self.cVTasks?.visibleCells.forEach { cell in
                guard let cell = cell as? MyTasksCVCell else {
                    return
                }
                cell.layoutIfNeeded()
                cell.setCornerRadius()
            }
        })
    }
    
    //MARK: SET HEADER
    func setHeader() {
        if appDel?.isTaskType == 1 || appDel?.isTaskType == 2 || appDel?.isTaskType == 3 {
            if let TasksSummary : NSDictionary = appDel?.summaryDic?.object(forKey: "TasksSummary") as? NSDictionary{
                let count1 : Int = Int(String(describing: TasksSummary.object(forKey: "IN_PROGRESS")!))!
                let count2 : Int = Int(String(describing: TasksSummary.object(forKey: "NOT_STARTED")!))!
                let count3 : Int = Int(String(describing: TasksSummary.object(forKey: "COMPLETED_IN_LAST_X_DAYS")!))!
                
                self.lblHeader.attributedText = CommonFunctions().getHeader(title: "My Work Item", count: String(count1 + count2 + count3))
            }
        }
        if appDel?.isTaskType == 0 {
            if let TasksSummary : NSDictionary = appDel?.summaryDic?.object(forKey: "TasksSummary") as? NSDictionary{
                let count1 : Int = Int(String(describing: TasksSummary.object(forKey: "TOTAL_TASK_COUNT")!))!
                self.lblHeader.attributedText = CommonFunctions().getHeader(title: "All", count: String(count1))
            }
        }
        if appDel?.isTaskType == 4 {
            self.lblHeader.attributedText = CommonFunctions().getHeader(title: "Meeting", count: String(myTaskArray.count))
        }
    }
    //MARK: On attachment click
    @objc func DocClicked(sender : UIButton) {
        let taskDetails = appDel?.InsightStoryBoard.instantiateViewController(withIdentifier: "TaskDetailsVC") as? TaskDetailsVC
        taskDetails?.tASKID = self.myTaskArray[sender.tag].tASKID
        taskDetails?.isDirectDocument = true
        self.navigationController?.pushViewController(taskDetails!, animated: true)
    }
    
    //MARK: BUTTON CLICKS
    @IBAction func onPlus(_ sender: Any) {
        
        let controller = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateTaskNewVC"))! as! CreateTaskNewVC
        controller.allProject = true
        controller.selectedUserID = (appDel?.userID)!
//        if appDel?.userObj.CanCreateProject == false{
//
//            UserDefaults.standard.set(true, forKey: "fromMyTask")
//            UserDefaults.standard.set(false, forKey: "fromProgressEntry")
//            UserDefaults.standard.set(appDel?.userObj.CONTACT_FIRSTNAME, forKey: "username")
//            controller.allProject = true
//            controller.selectedUserID = (appDel?.userID)!
//            controller.selectedMembers.append((appDel?.userObj.CONTACT_FIRSTNAME)! + " " + (appDel?.userObj.CONTACT_LASTNAME)!)
//            controller.selectedContactIDs.append((appDel?.userObj.USERID)!)
//            //appDel?.userID = (appDel?.userObj.USERID)!
//        }
        
        self.navigationController?.pushViewController(controller, animated: true)
    }
    @IBAction func onBack(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onCloseMenu(_ sender: UIButton) {
        self.actionMenu.hideWithCustomAnimation(animation: .curveLinear, hidden: true)
    }
    
    //MARK: GET MY MEETING TASK
    func GetTaskMeeting() {
        if appDel?.userID == 0 {
            return
        }
        let userid : String = String(describing: (appDel?.userID)!)
        CommonFunctions().animate()
        self.myTaskArray.removeAll()
        var parameters :[String:AnyObject] = [:]
        parameters = [:]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrlWithoutProgress(url: "pms/progressentry/Task/Meeting/" + userid, dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                if let resultDic : NSArray = dataResponse as? NSArray
                {
                    let arrayTasks = Mapper<MyTaskModel>().mapArray(JSONObject: resultDic) ?? []
                    self.myTaskArray = arrayTasks
                    self.AlltaskArray = arrayTasks
                }
                DispatchQueue.main.async {
                    self.setHeader()
                    self.refreshControl2.endRefreshing()
                    CommonFunctions().stopAnimate()
                    self.cVTasks.reloadData()
                }
            }
                
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
            }
        }
    }
    
    //MARK: GET MY All TASK
    func GetTaskAll() {
        if appDel?.userID == 0 {
            return
        }
        let userid : String = String(describing: (appDel?.userID)!)
        CommonFunctions().animate()
        self.myTaskArray.removeAll()
        var parameters :[String:AnyObject] = [:]
        parameters = [:]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrlWithoutProgress(url: "pms/task/all/" + userid, dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                if let resultDic : NSArray = dataResponse as? NSArray
                {
                    let arrayTasks = Mapper<MyTaskModel>().mapArray(JSONObject: resultDic) ?? []
                    self.myTaskArray = arrayTasks
                    self.AlltaskArray = arrayTasks
                }
                DispatchQueue.main.async {
                    self.refreshControl2.endRefreshing()
                    CommonFunctions().stopAnimate()
                    self.cVTasks.reloadData()
                }
            }
                
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
            }
        }
    }
    
    //MARK: GET MY TASK WITH STATUS
    func GetTaskWithStatus(statusStr : String){
        if appDel?.userID == 0 {
            return
        }
        let userid : String = String(describing: (appDel?.userID)!)
        CommonFunctions().animate()
        self.myTaskArray.removeAll()
        var parameters :[String:AnyObject] = [:]
        parameters = [:]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrlWithoutProgress(url: "pms/task/status/\(statusStr)/" + userid, dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                if let resultDic : NSArray = dataResponse as? NSArray
                {
                    let arrayTasks = Mapper<MyTaskModel>().mapArray(JSONObject: resultDic) ?? []
                    self.myTaskArray = arrayTasks
                    self.AlltaskArray = arrayTasks
                }
                DispatchQueue.main.async {
                    self.refreshControl2.endRefreshing()
                    CommonFunctions().stopAnimate()
                    self.cVTasks.reloadData()
                }
            }
                
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                }
            }
        }
    }
    
    func setSegmentController(){
        
        if let TasksSummary : NSDictionary = appDel?.summaryDic?.object(forKey: "TasksSummary") as? NSDictionary{
            
            let count1 : Int = Int(String(describing: TasksSummary.object(forKey: "IN_PROGRESS")!))!
            let count2 : Int = Int(String(describing: TasksSummary.object(forKey: "NOT_STARTED")!))!
            let count3 : Int = Int(String(describing: TasksSummary.object(forKey: "COMPLETED_IN_LAST_X_DAYS")!))!
            
            segmentedControl.items = ["Not Started (\(String(count2)))","In Progress (\(String(count1)))","Completed (\(String(count3)))"]

        }
        else{
            segmentedControl.items = ["Not Started","In Progress","Completed"]
        }
        segmentedControl.font = UIFont(name: "Gotham-Book", size: 12)
        segmentedControl.unselectedLabelColor = UIColor.darkGray
        segmentedControl.selectedIndex = 0
        segmentedControl.borderSize = 2
        segmentedControl.thumbColor = UIColor(red: 0.988, green: 0.820, blue: 0.447, alpha: 1.00)
        segmentedControl.selectedLabelColor = UIColor(red: 0.9333333333, green: 0.5450980392, blue: 0.07058823529, alpha: 1.0)
        segmentedControl.thumUnderLineSize = 3
        segmentedControl.backgroundColor = UIColor.white
        
        segmentedControl.isHidden = false
    }
    
    @IBAction func segmentValueChanged(_ sender: DGSegmentedControl) {
        self.myTaskArray.removeAll()
        self.cVTasks.reloadData()
        if sender.selectedIndex == 0 {
            self.setGesture()
            selectedStatusStr = "1"
            if appDel?.isTaskType == 0 {
                self.GetTaskAll()
            }
            else if appDel?.isTaskType == 4 {
                self.GetTaskMeeting()
            }
            else {
                self.GetTaskWithStatus(statusStr: "1")
            }
        }
        else if sender.selectedIndex == 1{
            self.setGesture()
            selectedStatusStr = "2"
            self.GetTaskWithStatus(statusStr: "2")
        }
        else{
            self.setGesture()
            selectedStatusStr = "3"
            appDel?.isTaskType = 3
            self.GetTaskWithStatus(statusStr: "3")
        }
    }
    
    
    //MARK: Get cell to Swipe
    
    func getCellAtPoint(_ point: CGPoint) -> MyTasksCVCell? {
        // Function for getting item at point. Note optionals as it could be nil
        let indexPath = cVTasks?.indexPathForItem(at: point)
        var cell : MyTasksCVCell?
        
        if indexPath != nil {
            cell = cVTasks?.cellForItem(at: indexPath!) as? MyTasksCVCell
        } else {
            cell = nil
        }
        
        return cell
    }
    
    @objc func userDidSwipeLeft(_ gesture : UISwipeGestureRecognizer){
        
        if self.segmentedControl.selectedIndex != 0 {
            return
        }
        let point = gesture.location(in: cVTasks)
        //let tapPoint = tap.location(in: collectionView)
        let duration = animationDuration()
        
        if(activeCell == nil){
            activeCell = getCellAtPoint(point)
            
            UIView.animate(withDuration: duration, animations: {
                self.activeCell.DetailView.transform = CGAffineTransform(translationX: -110, y: 0)
            });
        } else {
            // Getting the cell at the point
            let cell = getCellAtPoint(point)
            
            // If the cell is the previously swiped cell, or nothing assume its the previously one.
            if cell == nil || cell == activeCell {
                // To target the cell after that animation I test if the point of the swiping exists inside the now twice as tall cell frame
                let cellFrame = activeCell.frame
                let rect = CGRect(x: cellFrame.origin.x - cellFrame.width, y: cellFrame.origin.y, width: cellFrame.width*2, height: cellFrame.height)
                
                if rect.contains(point) {
                    print("Swiped inside cell")
                    // If swipe point is in the cell delete it
                    
                }
                
                // If another cell is swiped
            } else if activeCell != cell {
                // It's not the same cell that is swiped, so the previously selected cell will get unswiped and the new swiped.
                UIView.animate(withDuration: duration, animations: {
                    self.activeCell.DetailView.transform = CGAffineTransform.identity
                    cell!.DetailView.transform = CGAffineTransform(translationX: -110, y: 0)
                }, completion: {
                    (Void) in
                    self.activeCell = cell
                })
                
            }
        }
    }
    
    @objc func userDidSwipeRight(){
        // Revert back
        if(activeCell != nil){
            let duration = animationDuration()
            
            UIView.animate(withDuration: duration, animations: {
                self.activeCell.DetailView.transform = CGAffineTransform.identity
            }, completion: {
                (Void) in
                self.activeCell = nil
            })
        }
    }
    
    func animationDuration() -> Double {
        return 0.5
    }
    
    //MARK: ACTION MENU TABLE
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 37
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.taskActionMenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuAction", for: indexPath) as? ECMContactCell
        
        cell?.lblName?.text = self.taskActionMenu[indexPath.row]
        
        //cell?.lblName?.textAlignment = .center
        cell?.lblName?.textColor = theme_selected_color!
        cell?.lblName?.font = UIFont.init(name: gothamMedium, size: 17)
        
        cell?.imgIcon.tintColor = theme_selected_color!
        if cell?.lblName.text == menuItem1 {
            cell?.imgIcon.image = #imageLiteral(resourceName: "play48.png")
        }
        if cell?.lblName.text == menuItem2 {
            cell?.imgIcon.image = #imageLiteral(resourceName: "revised48.png")
            cell?.imgIcon.tintColor = theme_selected_color!
        }
        if cell?.lblName.text == menuItem3 {
            cell?.imgIcon.image = #imageLiteral(resourceName: "follow48.png")
        }
        if cell?.lblName.text == menuItem4 {
            cell?.imgIcon.image = #imageLiteral(resourceName: "Progress48.png")
            cell?.imgIcon.tintColor = theme_selected_color!
        }
        if cell?.lblName.text == menuItem5 {
            cell?.imgIcon.image = #imageLiteral(resourceName: "Note48.png")
        }
        if cell?.lblName.text == menuItem6 {
            cell?.imgIcon.image = #imageLiteral(resourceName: "attachment48.png")
        }
        if cell?.lblName.text == menuItem7 {
            cell?.imgIcon.image = #imageLiteral(resourceName: "roadblock48.png")
            cell?.imgIcon.tintColor = theme_selected_color!
        }
        if cell?.lblName.text == menuItem8 {
            cell?.imgIcon.image = #imageLiteral(resourceName: "subtask48.png")
            cell?.imgIcon.tintColor = theme_selected_color!
            //cell?.imgIcon.backgroundColor = theme_selected_color!
        }
        if cell?.lblName.text == menuItem9 {
            //cell?.imgIcon.image = #imageLiteral(resourceName: "bug.png")
            cell?.imgIcon.image = #imageLiteral(resourceName: "bug48.png")
            cell?.imgIcon.tintColor = .red
        }
        
        if indexPath.row == 2 {
            cell?.lblEmail.isHidden = false
        }
        else {
            cell?.lblEmail.isHidden = true
        }
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        self.actionMenu.hideWithCustomAnimation(animation: .curveLinear, hidden: true)
        CommonFunctions().taskActionMenu(index: indexPath.row, task: myTaskSelected, vc: self)
    }
    
    //MARK: UICOLLECTIONVIEW DELEGATE AND DATASOURCE
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let width = cVTasks.frame.width//UIScreen.main.bounds.width
        let height = UIScreen.main.bounds.height
        //let cellRatio: CGFloat = 300 / 214
        if UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiom.pad {

            return CGSize(width: 300, height: 214)
        }
        else {
            if (width == 568) || (width == 320) || (width == 480){
                return CGSize(width: 300, height: 214)
            }
            else if UIDevice.current.orientation.isLandscape {
                let dispWidth = width / 2 - 20
                return CGSize(width: dispWidth, height: 214)
            }
            else if UIDevice.current.orientation.isFlat {
                if width < 370 {
                    return CGSize(width: 300, height: 214)
                }
                if width < height {
                    return CGSize(width: width - 10, height: 214)
                }
                else {
                    let dispWidth = width / 2 - 20
                    return CGSize(width: dispWidth, height: 214)
                }
            }
            else {
                if width < height {
                    return CGSize(width: width - 10, height: 214)
                }
                let dispWidth = width / 2 - 20
                return CGSize(width: dispWidth, height: 214)
            }
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.init(top: 10, left: 10, bottom: 10, right: 10)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.myTaskArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : MyTasksCVCell = (collectionView.dequeueReusableCell(withReuseIdentifier: "Tasks", for: indexPath) as? MyTasksCVCell)!
        
        self.myTaskArray[indexPath.row].cONTACTID = (appDel?.userID)!
        
        cell.setNewView(objTask: myTaskArray[indexPath.row])

        cell.btnAttachment.addTarget(self, action: #selector(self.DocClicked(sender:)), for: .touchUpInside)
        cell.btnAttachment.tag = indexPath.row

        cell.btnDelete.addTarget(self, action: #selector(self.deleteTaskClicked), for: .touchUpInside)
        cell.btnDelete.tag = indexPath.row
        
        cell.btnClose.addTarget(self, action: #selector(self.removeTaskClicked), for: .touchUpInside)
        cell.btnClose.tag = indexPath.row
        
        cell.btnTaskStatus.addTarget(self, action: #selector(self.changeTaskStatus), for: .touchUpInside)
        cell.btnTaskStatus.tag = indexPath.row
        
        cell.btnMenu.addTarget(self, action: #selector(self.opencontextMenu), for: .touchUpInside)
        cell.btnMenu.tag = indexPath.row
        
        if self.segmentedControl.selectedIndex == 2 {
            cell.btnTaskStatus.isHidden = true
        }
        else {
            cell.btnTaskStatus.isHidden = false
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let taskDetails = appDel?.InsightStoryBoard.instantiateViewController(withIdentifier: "TaskDetailsVC") as? TaskDetailsVC

        taskDetails?.tASKID = self.myTaskArray[indexPath.row].tASKID
        taskDetails?.isDirectDescription = true
        self.navigationController?.pushViewController(taskDetails!, animated: true)
    }
    
    @objc func opencontextMenu(sender: UIButton){
        if let cell : MyTasksCVCell = sender.superview?.superview?.superview?.superview as? MyTasksCVCell {
            let indexPath = cVTasks.indexPath(for: cell)
            myTaskSelected = self.myTaskArray[(indexPath?.row)!]
            if myTaskSelected?.tASK_TYPE_ID == 2 {
                if myTaskSelected?.pARENT_TASK_ID != 0 {
                    self.taskActionMenu = [menuItem1,menuItem2,menuItem3,menuItem4,menuItem5,menuItem6,menuItem8,menuItem9]
                }
                else {
                    self.taskActionMenu = [menuItem1,menuItem2,menuItem3,menuItem4,menuItem5,menuItem6]
                }
            }
            else if myTaskSelected?.tASK_TYPE_ID == 4 || myTaskSelected?.tASK_TYPE_ID == 3 {
                if myTaskSelected?.pARENT_TASK_ID != 0 {
                    self.taskActionMenu = TaskActionMenu
                }
                else {
                    self.taskActionMenu = [menuItem1,menuItem2,menuItem3,menuItem4,menuItem5,menuItem6,menuItem7]
                }
                
            }
            else {
                self.taskActionMenu = TaskActionMenu
            }
            tblMenu.reloadData()
            self.actionMenu.hideWithCustomAnimation(animation: .curveEaseIn, hidden: false)
            
            let cells = tblMenu.visibleCells
            let tableHeight: CGFloat = tblMenu.bounds.size.height
                
            for i in cells {
                let cell: UITableViewCell = i as UITableViewCell
                cell.transform = CGAffineTransform(translationX: 0, y: tableHeight)
            }
                
            var index = 0
                
            for a in cells {
                let cell: UITableViewCell = a as UITableViewCell
                
                UIView.animate(withDuration: 0.5, delay: 0.05 * Double(index), options: [.curveLinear],
                animations: {
                    cell.transform = CGAffineTransform(translationX: 0, y: 0);
                }, completion: nil)
                    
                index += 1
            }
            
        }
    }
    
    @objc func changeTaskStatus(sender: UIButton) {
        if let cell : MyTasksCVCell = sender.superview?.superview?.superview?.superview as? MyTasksCVCell {
            let indexPath = cVTasks.indexPath(for: cell)
            let objTask = self.myTaskArray[(indexPath?.row)!]
            if objTask.iSACTIVETASK == 1 {
                self.taskStop(objTask: objTask)
            }
            else {
                CommonFunctions().taskPLay(objTask: objTask, vc: self)
            }
        }
    }
    
    //MARK: STOP TASK
    func taskStop(objTask : MyTaskModel) {
        let parameters: NSDictionary = [
            "taskId" : objTask.tASKID as Any,
            "ContactId" : objTask.cONTACTID as Any,
            ]
        let manager = APIManager.apiManager
        CommonFunctions().animate()
        manager.postReviseTaskFromUrl(url: "pms/progressentry/Task/Stop", dic: parameters as NSDictionary) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    //appDel?.window?.makeToast(msgTaskStopSuccess)
                    CommonFunctions().stopAnimate()
                    _ = self.navigationController?.popViewController(animated: true)

                }
                
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                }
                
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    appDel?.window?.makeToast(msgSomethingWrong)
                }
            }
        }
    }
    
    //MARK: Delete Task
    @objc func deleteTaskClicked(sender : UIButton) {
        
        if let cell : MyTasksCVCell = sender.superview?.superview?.superview as? MyTasksCVCell {
            let indexPath = cVTasks.indexPath(for: cell)
            let objTask = self.myTaskArray[(indexPath?.row)!]
            if objTask.iSACTIVETASK == 1 {
                appDel?.window?.makeToast(msgTaskActiveCanNotBeDelete)
                return
            }
            if objTask.cANDELETETASK == 1 {
                CommonFunctions().showThemeAlert(msgTitle: "Alert", msg: "Are you sure you want to delete ?") { (isSuccess) in
                    if isSuccess {
                        self.deleteTask(objTask: objTask)
                    }
                    else {
                        self.userDidSwipeRight()
                    }
                }
            }
            else {
                self.view.makeToast(msgDeleteTask)
            }
        }
    }
    
    func deleteTask(objTask : MyTaskModel){
        let parameters :[String:AnyObject] = [:]
        let manager = APIManager.apiManager
        CommonFunctions().animate()
        manager.DeleteDatadicFromUrlWithoutProgress(url: "pms/task/\((objTask.tASKID))", dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        if (resultDic.value(forKey: "fail") != nil){
                            
                            self.view.makeToast(msgTaskNotDeleted)
                            
                            return
                        }
                    }
                    self.view.makeToast(msgTaskDeleteSuccess)
                    self.GetTaskWithStatus(statusStr: self.selectedStatusStr)
                    self.userDidSwipeRight()
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    self.view.makeToast(msgUnauthorised)
                }
                
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    self.view.makeToast(msgSomethingWrong)
                }
            }
        }
    }
    
    //MARK: Close Task
    @objc func removeTaskClicked(sender : UIButton) {
        if let cell : MyTasksCVCell = sender.superview?.superview?.superview as? MyTasksCVCell {
            let indexPath = cVTasks.indexPath(for: cell)
            let objTask = self.myTaskArray[(indexPath?.row)!]
            if objTask.iSACTIVETASK == 1 {
                appDel?.window?.makeToast(msgTaskActiveCanNotBeClose)
                return
            }
            if objTask.cANREVISETASK == 1 {
                self.closeTask(objTask: objTask)
            }
            else {
                self.view.makeToast(msgCloseTask)
            }
        }
    }
    
    func closeTask(objTask : MyTaskModel){
        var dateStr : String = ""
        let dateFormattr = DateFormatter()
        dateFormattr.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        if (objTask.tASKENDDATE != ""){
            if let dateObj = dateFormattr.date(from: objTask.tASKENDDATE){
                let dateFormatterM = DateFormatter()
                dateFormatterM.dateFormat = "yyyy-MM-dd"
                dateStr = dateFormatterM.string(from: dateObj)
            }
        }
        else{
            //self.view.makeToast("Task end date not available")
            //return
        }
        let parameters: NSDictionary = [
            "TASK_ID" : objTask.tASKID as Any,
            "ORIGINAL_HOURS" : objTask.aLLOCATEDHOURS as Any,
            "MANUAL_CLOSE" : "true",
            "COMMENTS" : "Work Item Completed",
            "REVISED_HOURS" : objTask.cOMPLETEDHOURS as Any,
            "TASK_END_DATE" : dateStr as Any,
        ]
        let manager = APIManager.apiManager
        CommonFunctions().animate()
        manager.postReviseTaskFromUrl(url: "pms/task/\((objTask.tASKID))/revise", dic: parameters as NSDictionary) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    self.myTaskArray.removeAll()
                    self.cVTasks.reloadData()
                    appDel?.window?.makeToast(msgTaskCloseSuccess)
                    self.GetTaskWithStatus(statusStr: self.selectedStatusStr)
                    self.userDidSwipeRight()
                }
                
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                }
                
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    appDel?.window?.makeToast(msgSomethingWrong)
                }
            }
        }
    }
}

extension WIPMyTasksNewVC : UISearchBarDelegate {
    //MARK: SEARCHBAR DELEGATE
    func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        return true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        view.addGestureRecognizer(tap)
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchBar.text == "" {
            
            myTaskArray = AlltaskArray
            
            cVTasks.reloadData()
            return
        }
        self.showSearchResult(searchText: searchText)
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        if searchBar.text != "" {
            self.view.endEditing(true)
            self.searchBar.endEditing(true)
            self.showSearchResult(searchText: searchBar.text!)
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        
        self.myTaskArray = AlltaskArray
        self.cVTasks.reloadData()
        
    }
    func showSearchResult(searchText: String) {
        myTaskArray.removeAll()
        
        if searchText != "" {
            let namePredicate = NSPredicate(format: "SELF contains[cd] %@",  searchText)
            //taskArray.append(contentsOf: AlltaskArray.filter {namePredicate.evaluate(with: $0.tASKDESCRIPTION)})
            if searchText.isInt {
                myTaskArray.append(contentsOf: AlltaskArray.filter {namePredicate.evaluate(with: $0.tASKSTRINGID)})
                myTaskArray.append(contentsOf: AlltaskArray.filter {namePredicate.evaluate(with: $0.tASKFULLDESCRIPTION)})
            }
            else {
                myTaskArray.append(contentsOf: AlltaskArray.filter {namePredicate.evaluate(with: $0.tASKFULLDESCRIPTION)})
                myTaskArray.append(contentsOf: AlltaskArray.filter {namePredicate.evaluate(with: $0.pROJECTNAME)})
            }
            
        } else {
            self.myTaskArray.append(contentsOf: AlltaskArray) //= (AlltaskArray)
        }
        self.myTaskArray = self.myTaskArray.unique{$0.tASKID}
        cVTasks.reloadData()
    }
}
