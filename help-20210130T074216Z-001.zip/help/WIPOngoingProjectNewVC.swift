//
//  WIPOngoingProjectNewVC.swift
//  WorkInProgress
//
//  Created by Arpit Shah on 10/03/18.
//  Copyright © 2018 Arpit Shah. All rights reserved.
//

import Foundation
import UIKit
import FontAwesome_swift
import ObjectMapper
import SVProgressHUD
import BTNavigationDropdownMenu
import KDropDownMultipleSelection
import DropDown
import FontAwesome_swift
class WIPOngoingProjectNewVC : UIViewController,UICollectionViewDelegate,UICollectionViewDataSource, UITableViewDelegate, UITableViewDataSource,kDropDownListViewDelegate,UITextFieldDelegate, UICollectionViewDelegateFlowLayout {
    @IBOutlet var lblSprintName: UILabel!
    @IBOutlet var lblHeader2: UILabel!
    @IBOutlet var lblHeader3: UILabel!
    
    @IBOutlet weak var segmentedControl: DGSegmentedControl!
    @IBOutlet weak var segmentedControl2: DGSegmentedControl!
    var activeCell: MyTasksCVCell!
    var myTaskArray = [MyTaskModel]()
    var AlltaskArray = [MyTaskModel]()
    @IBOutlet weak var cVTasks: UICollectionView!
    @IBOutlet var tblSort: UITableView!
    
    @IBOutlet weak var plusButtonMenu: UIView!
    @IBOutlet weak var menuTable: UITableView!
    var menuArray = [String]()
    
    var selectedSprint : Int = 0
    
    @IBOutlet var collectionViewprojects : UICollectionView!
    
    var arrayMilestone = [OngoingProjectNewModel]()
    var allArrayMilestone = [OngoingProjectNewModel]()
    var taskArray = [OngoingTask]()
    var projectsArray = [ProjectOngoingModel]()
    
    @objc var selectedIndex : Int = 1000
    var menuView : BTNavigationDropdownMenu?
    
    var dropDownObj : DropDownListView?
    
    @IBOutlet var lblHeader: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var refreshControl: UIRefreshControl!
    var refreshControl2: UIRefreshControl!
    
    var strTableHeader : String = ""
    @IBOutlet var iPhoneXHeight: NSLayoutConstraint!
    @IBOutlet var iPhoneXHeight3: NSLayoutConstraint!
    @IBOutlet var iPhoneXHeight2: NSLayoutConstraint!
    
    let dropDown = DropDown()
    
    var sortByInt : Int = 5
    var isDesc : Bool = true
    
    var arrProjectSelected = NSMutableArray()
    
    @IBOutlet var btnAscending: UIButton!
    @IBOutlet var btnDescensing: UIButton!
    
    
    @IBOutlet var viewTaskListing: UIView!
    
    var isFirstTimeDetails : Bool = true
    var isFirstTimeFilter : Bool = true
    
    @IBOutlet var viewAscDesc: UIView!
    
    @IBOutlet var viewFilterSort: UIView!
    
    var selectedSprintID : Int = 0
    var selectedStatusID : Int = 0
    
    @IBOutlet var lblNoTask: UILabel!
    @IBOutlet weak var tblMenu: UITableView!
    @IBOutlet weak var actionMenu: UIView!
    var myTaskSelected : MyTaskModel?
    var swipDown = UISwipeGestureRecognizer()
    var taskActionMenu : [String] = []
    var apiResponseArray = [Any]()
    var selectedFolderModel = SearchFolderModel(JSON: [:])
    var tap = UITapGestureRecognizer()
    
    //MARK: Methods
    override func viewDidLoad() {
        addMenus()
        if appDel?.projectSortArray.count == 0{
            appDel?.getProjectSortingParams()
        }
        tap = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboard))
        
        swipDown = UISwipeGestureRecognizer(target: self, action: #selector(self.dismissMenu))
                swipDown.direction = .down
        tblMenu.addGestureRecognizer(swipDown)
                tblMenu.reloadData()
        
        menuTable.reloadData()
        plusButtonMenu.isHidden = true
        self.actionMenu.isHidden = true
        viewFilterSort.isHidden = true
        btnDescensing.isSelected = true
        btnDescensing.backgroundColor = hexStringToUIColor(hex: (UserDefaults.standard.object(forKey: themeBorder) as? String)!)//theme_color
        self.tblSort.tag = 15
        self.tblSort.separatorStyle = .none
        self.viewTaskListing.isHidden = true
        self.setSegmentController()
        
        if iphoneX == false {
            iPhoneXHeight.constant = 0
            iPhoneXHeight2.constant = 0
            iPhoneXHeight3.constant = 0
        }
        
        
        CommonFunctions().setSearchbar(searchbar: self.searchBar)
        
        self.lblHeader.attributedText = CommonFunctions().getHeader(title: (appDel?.userObj.projectPlural_label)!, count: String((appDel?.objInsightCount?.pROJECTTASKCOUNT.withCommas())!))
        self.lblHeader3.attributedText = CommonFunctions().getHeader(title: (appDel?.userObj.projectPlural_label)!, count: String((appDel?.objInsightCount?.pROJECTTASKCOUNT.withCommas())!))

        setProjectRefreshView()
        
        refreshControl2 = UIRefreshControl()
        refreshControl2.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl2.addTarget(self, action: #selector(self.refreshTask), for: UIControl.Event.valueChanged)
        cVTasks.addSubview(refreshControl2)
        
       
        self.getProjectLists(isOpen: false)
        
        let nib = UINib(nibName: "OngoingProjectCell", bundle: nil)
        collectionViewprojects.register(nib, forCellWithReuseIdentifier: "cell2")
        
        let cellWidth : CGFloat = 300
        let cellheight : CGFloat = 256
        let cellSize = CGSize(width: cellWidth , height:cellheight)
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical //.horizontal
        layout.itemSize = cellSize
        layout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
        layout.minimumLineSpacing = 1.0
        layout.minimumInteritemSpacing = 1.0
        collectionViewprojects.setCollectionViewLayout(layout, animated: true)
        self.allArrayMilestone.removeAll()
        self.arrayMilestone.removeAll()
        self.collectionViewprojects.reloadData()
        self.setTagView()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
    }
    override func viewDidAppear(_ animated: Bool) {
    }
  
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        self.collectionViewprojects?.collectionViewLayout.invalidateLayout()
        
        coordinator.animate(alongsideTransition: { context in
            
        }, completion: { context in
            
            
            self.tblMenu.reloadData()
            
            if UIDevice.current.orientation.isLandscape {
                self.tblMenu.isScrollEnabled = true
            }
            else {
                self.tblMenu.isScrollEnabled = false
            }
            self.collectionViewprojects?.collectionViewLayout.invalidateLayout()
            
            self.collectionViewprojects?.visibleCells.forEach { cell in
                guard let cell = cell as? OngoingProjectCell else {
                    return
                }
                cell.setCircularImageView()
            }
        })
        
        self.cVTasks?.collectionViewLayout.invalidateLayout()
        
        coordinator.animate(alongsideTransition: { context in
            
        }, completion: { context in
            self.cVTasks?.collectionViewLayout.invalidateLayout()
            
            self.cVTasks?.visibleCells.forEach { cell in
                guard let cell = cell as? MyTasksCVCell else {
                    return
                }
                cell.layoutIfNeeded()
                cell.setCornerRadius()
            }
        })
    }

    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
        view.removeGestureRecognizer(tap)
    }
    
    func addMenus(){
        menuArray.removeAll()
        menuArray = globalMenu
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        //IQKeyboardManager.sharedManager().enable = false
        CommonFunctions().stopAnimate()
        
        plusButtonMenu.isHidden = true
    }
    
    func setSegmentController(){
        segmentedControl.items = ["Not Started","In Progress","Completed"]
        segmentedControl.font = UIFont(name: "Gotham-Book", size: 12)
        segmentedControl.unselectedLabelColor = UIColor.darkGray
        segmentedControl.borderSize = 2
        segmentedControl.thumbColor = UIColor(red: 0.988, green: 0.820, blue: 0.447, alpha: 1.00)
        segmentedControl.selectedLabelColor = UIColor.darkGray
        segmentedControl.backgroundColor = UIColor.white
        segmentedControl.thumUnderLineSize = 3
        
        self.segmentValueChanged(segmentedControl)
        
        segmentedControl2.items = ["Sort By","Filter By"]
        segmentedControl2.font = UIFont(name: "Gotham-Book", size: 13)
        segmentedControl2.unselectedLabelColor = UIColor.darkGray
        //segmentedControl.borderColor = UIColor(red: 0.988, green: 0.820, blue: 0.447, alpha: 1.00)
        //segmentedControl.selectedIndex = 0
        segmentedControl2.borderSize = 2
        segmentedControl2.thumbColor = UIColor(red: 0.988, green: 0.820, blue: 0.447, alpha: 1.00)
        segmentedControl2.selectedLabelColor = UIColor(red: 0.9333333333, green: 0.5450980392, blue: 0.07058823529, alpha: 1.0)
        segmentedControl2.backgroundColor = UIColor.white
        segmentedControl2.thumUnderLineSize = 3
        
        self.segmentValueChanged2(segmentedControl2)
        
    }
    func setProjectRefreshView(){
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh), for: UIControl.Event.valueChanged)
        collectionViewprojects.addSubview(refreshControl) // not required when
    }
    func removeCollectionRefreshView(){
        //refreshControl.removeFromSuperview()
        //refreshControl = nil
    }
   
    func tagSelected(notification: Notification){
    }
    @IBAction func segmentValueChanged2(_ sender: DGSegmentedControl) {
        if appDel?.projectSortArray.count == 0{
            appDel?.getProjectSortingParams()
        }
        if isFirstTimeFilter == true{
            isFirstTimeFilter = false
            return
        }
        self.viewFilterSort.isHidden = false
        if sender.selectedIndex == 0 {
            viewAscDesc.isHidden = false
            self.tblSort.tag = 15
            self.tblSort.reloadData()
        }
        else{
            viewAscDesc.isHidden = true
            if projectsArray.count == 0 {
                getProjectLists(isOpen: true)
                return
            }
            self.tblSort.tag = 16
            self.tblSort.reloadData()
        }
    }
    @IBAction func segmentValueChanged(_ sender: DGSegmentedControl) {
        if isFirstTimeDetails == true{
            isFirstTimeDetails = false
            return
        }
        self.myTaskArray.removeAll()
        self.AlltaskArray.removeAll()
        self.cVTasks.reloadData()
        if sender.selectedIndex == 0 {
            //do some thing}
            self.setGesture()
            selectedSprintID = selectedSprint
            selectedStatusID = 1
            strTableHeader = "Not Started"
            self.getTaskDetailsfromSprintId(sprintID: selectedSprint, statusID: 1)
        }
        else if sender.selectedIndex == 1{
            self.setGesture()
            selectedSprintID = selectedSprint
            selectedStatusID = 2
            strTableHeader = "In Progress"
            self.getTaskDetailsfromSprintId(sprintID: selectedSprint, statusID: 2)
        }
        else{
            self.setGesture()
            selectedSprintID = selectedSprint
            selectedStatusID = 3
            strTableHeader = "Completed in 10 Days"
            self.getTaskDetailsfromSprintId(sprintID: selectedSprint, statusID: 3)
        }
    }
    @objc func refresh(sender:AnyObject) {
        allArrayMilestone.removeAll()
        arrayMilestone.removeAll()
        RunLoop.current.run(until: Date.init(timeIntervalSinceNow: 1))
        collectionViewprojects.reloadData()
        self.getProjectMilestones(sortby: sortByInt, isDesc: isDesc)
        // Code to refresh table view
    }
    @objc func refreshTask(sender:AnyObject) {
        myTaskArray.removeAll()
        AlltaskArray.removeAll()
        cVTasks.reloadData()
        self.getTaskDetailsfromSprintId(sprintID: selectedSprintID, statusID: selectedStatusID)
        // Code to refresh table view
    }
    
    func openSortBy(){
      var sortParams = [String]()
        for itemSort in (appDel?.projectSortArray)! {
            let idStr : String = String(describing: itemSort.id!)
            sortParams.append(itemSort.name! + separator + idStr)
        }
        //dropDown.anchorView = txtSortBy // UIView or UIBarButtonItem
        dropDown.direction = .any
        // The list of items to display. Can be changed dynamically
        dropDown.dataSource = sortParams
        dropDown.show()
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            if item.contains(separator) {
                let array = item.components(separatedBy: separator)
                if array.count == 2 {
                    // self.txtSortBy.text = array[0]
                    self.sortByInt = Int(array[1])!
                    self.allArrayMilestone.removeAll()
                    self.arrayMilestone.removeAll()
                    RunLoop.current.run(until: Date.init(timeIntervalSinceNow: 1))
                    self.collectionViewprojects.reloadData()
                    self.getProjectMilestones(sortby: self.sortByInt, isDesc: self.isDesc)
                }
            }
        }
    }
    
    //MARK: Tagview Methods
    func setTagView(){
        
        
    }
    
    
    //MARK: Get cell to Swipe
    func setGesture() {
        let swipeLeft : UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(self.userDidSwipeLeft(_:)))
        swipeLeft.direction = .left
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.userDidSwipeRight))
        swipeRight.direction = .right
        
        if self.segmentedControl.selectedIndex == 0 {
            
            cVTasks?.addGestureRecognizer(swipeLeft)
            cVTasks?.addGestureRecognizer(swipeRight)
        }
        else {
            cVTasks?.removeGestureRecognizer(swipeLeft)
            cVTasks?.removeGestureRecognizer(swipeRight)
        }
    }
    
    func getCellAtPoint(_ point: CGPoint) -> MyTasksCVCell? {
        // Function for getting item at point. Note optionals as it could be nil
        let indexPath = cVTasks?.indexPathForItem(at: point)
        var cell : MyTasksCVCell?
        
        if indexPath != nil {
            cell = cVTasks?.cellForItem(at: indexPath!) as? MyTasksCVCell
        } else {
            cell = nil
        }
        
        return cell
    }
    
    @objc func userDidSwipeLeft(_ gesture : UISwipeGestureRecognizer){
        
        if self.segmentedControl.selectedIndex != 0 {
            return
        }
        let point = gesture.location(in: cVTasks)
        //let tapPoint = tap.location(in: collectionView)
        let duration = animationDuration()
        
        if(activeCell == nil){
            activeCell = getCellAtPoint(point)
            
            UIView.animate(withDuration: duration, animations: {
                self.activeCell.DetailView.transform = CGAffineTransform(translationX: -110, y: 0)
            });
        } else {
            // Getting the cell at the point
            let cell = getCellAtPoint(point)
            
            // If the cell is the previously swiped cell, or nothing assume its the previously one.
            if cell == nil || cell == activeCell {
                // To target the cell after that animation I test if the point of the swiping exists inside the now twice as tall cell frame
                let cellFrame = activeCell.frame
                let rect = CGRect(x: cellFrame.origin.x - cellFrame.width, y: cellFrame.origin.y, width: cellFrame.width*2, height: cellFrame.height)
                
                if rect.contains(point) {
                    print("Swiped inside cell")
                    // If swipe point is in the cell delete it
                    
                }
                
                // If another cell is swiped
            } else if activeCell != cell {
                // It's not the same cell that is swiped, so the previously selected cell will get unswiped and the new swiped.
                UIView.animate(withDuration: duration, animations: {
                    self.activeCell.DetailView.transform = CGAffineTransform.identity
                    cell!.DetailView.transform = CGAffineTransform(translationX: -110, y: 0)
                }, completion: {
                    (Void) in
                    self.activeCell = cell
                })
                
            }
        }
    }
    
    @objc func userDidSwipeRight(){
        // Revert back
        if(activeCell != nil){
            let duration = animationDuration()
            
            UIView.animate(withDuration: duration, animations: {
                self.activeCell.DetailView.transform = CGAffineTransform.identity
            }, completion: {
                (Void) in
                self.activeCell = nil
            })
        }
    }
    
    func animationDuration() -> Double {
        return 0.5
    }
    
    //MARK: ON PLUS BUTTON
    @IBAction func onPlus(_ sender: Any) {
        if plusButtonMenu.isHidden == false {
            plusButtonMenu.isHidden = true
        }
        else {
            plusButtonMenu.isHidden = false
        }
        
    }
    
    @IBAction func onBack(_ sender: Any) {
        //if viewTaskDetails.isHidden == false {
        // viewTaskDetails.isHidden = true
        //btnFilter.isHidden = false
        //self.btnRefresh.isHidden = false
        //return
        // }
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTaskDetailsClose(_ sender: Any) {
        // viewTaskDetails.isHidden = true
    }
    @IBAction func onClose(_ sender: Any) {
        // viewTasks.isHidden = true
    }
    
    @objc func dismissMenu() {
        self.actionMenu.hideWithCustomAnimation(animation: .curveLinear, hidden: true)
    }
    
    @IBAction func onCloseMenu(_ sender: UIButton) {
        self.actionMenu.hideWithCustomAnimation(animation: .curveLinear, hidden: true)
    }
    
    @IBAction func onDescending(_ sender: Any) {
        self.isDesc = true
        btnAscending.isSelected = false
        btnAscending.backgroundColor = UIColor.clear
        
        btnDescensing.isSelected = true
        btnDescensing.backgroundColor = hexStringToUIColor(hex: (UserDefaults.standard.object(forKey: themeBorder) as? String)!)//theme_color
    }
    @IBAction func onAscensing(_ sender: Any) {
        self.isDesc = false
        btnDescensing.isSelected = false
        btnDescensing.backgroundColor = UIColor.clear
        
        btnAscending.isSelected = true
        btnAscending.backgroundColor = hexStringToUIColor(hex: (UserDefaults.standard.object(forKey: themeBorder) as? String)!)//theme_color
    }
    //MARK: OPEN PROJECT DETAIL
    @objc func projectClicked(sender : UIButton) {
        let objMilestone = arrayMilestone[sender.tag]
        
        let projectDetails = appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "WIPProjectDetailsVC") as? WIPProjectDetailsVC
        projectDetails?.projectID = objMilestone.pROJECTID
        self.navigationController?.pushViewController(projectDetails!, animated: true)
        
        return
    }
    //MARK: CREATE TASK
    @objc func addTaskClicked(sender : UIButton) {
        if  arrayMilestone[sender.tag].cANEDITSPRINT! {
            let projectObj = ProjectModel(JSON: [:])
        
            projectObj?.pROJECTID = arrayMilestone[sender.tag].pROJECTID
            projectObj?.SERVER_ID = arrayMilestone[sender.tag].pROJECTID
            projectObj?.pROJECTNAME = arrayMilestone[sender.tag].pROJECTNAME
        
            let milestoneObj = ProjectSprintModel(JSON: [:])
            milestoneObj?.pROJECTID = arrayMilestone[sender.tag].pROJECTID
            milestoneObj?.sPRINTID = arrayMilestone[sender.tag].sPRINTID
            milestoneObj?.sPRINTNAME = arrayMilestone[sender.tag].sPRINTNAME
        
            let createTaskVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateTaskNewVC"))! as? CreateTaskNewVC
            createTaskVC?.allProject = false
            createTaskVC?.selectedUserID = (appDel?.userObj.USERID)!
            createTaskVC?.selectedProject = projectObj
            createTaskVC?.selectedSprint = milestoneObj
            createTaskVC?.isDepartMent = true
            createTaskVC?.isFromProject = true
            appDel?.selectedDocuments.removeAll()
            self.navigationController?.pushViewController(createTaskVC!, animated: true)
        }
        else {
            self.view.makeToast("You are not authorized to create Work Item")
        }
    }
    @objc func notcompletedClicked(sender : UIButton) {
        let objMilestone = self.arrayMilestone[sender.tag]
        if ((objMilestone.tasksSummary?[0].cATEGORYCOUNT) == 0)  {
            return
        }        
        segmentedControl.items = ["Not Started (\(((String(describing: (objMilestone.tasksSummary?[0].cATEGORYCOUNT.withCommas())!)))))","In Progress (\(((String(describing: (objMilestone.tasksSummary?[1].cATEGORYCOUNT.withCommas())!)))))","Completed (\(((String(describing: (objMilestone.tasksSummary?[2].cATEGORYCOUNT.withCommas())!)))))"]
        segmentedControl.font = UIFont(name: "Gotham-Book", size: 12)
        segmentedControl.selectedIndex = 0
        strTableHeader = "Not Started"
        self.setGesture()
        lblSprintName.text = self.arrayMilestone[sender.tag].sPRINTNAME
        lblHeader2.text = self.arrayMilestone[sender.tag].pROJECTNAME
        if ((objMilestone.tasksSummary?[0].cATEGORYCOUNT) == 0)  {
            return
        }
        self.getTaskDetailsfromSprintId(sprintID: self.arrayMilestone[sender.tag].sPRINTID, statusID: 1)
    }
    @objc func inProgressClicked(sender : UIButton) {
        let objMilestone = self.arrayMilestone[sender.tag]
        if ((objMilestone.tasksSummary?[1].cATEGORYCOUNT) == 0)  {
            return
        }
        segmentedControl.items = ["Not Started (\(((String(describing: (objMilestone.tasksSummary?[0].cATEGORYCOUNT)!)))))","In Progress (\(((String(describing: (objMilestone.tasksSummary?[1].cATEGORYCOUNT)!)))))","Completed (\(((String(describing: (objMilestone.tasksSummary?[2].cATEGORYCOUNT)!)))))"]
        segmentedControl.selectedIndex = 1
        segmentedControl.font = UIFont(name: "Gotham-Book", size: 12)
        strTableHeader = "In Progress"
        self.setGesture()
        lblHeader2.text = self.arrayMilestone[sender.tag].pROJECTNAME
        lblSprintName.text = self.arrayMilestone[sender.tag].sPRINTNAME
        
        self.getTaskDetailsfromSprintId(sprintID: self.arrayMilestone[sender.tag].sPRINTID, statusID: 2)
        
    }
    
    //MARK: Attachment Button Click Func Open ECM
    
    @objc func attchmntClicked(sender : UIButton) {
        
        let objMilestone = self.arrayMilestone[sender.tag]
        if ((objMilestone.pROJECTATTACHMENTSCOUNT) == 0)  {
            return
        }
        //let switchToECM : ECMMainVC = (appDel?.WIPECMStoryBoard.instantiateViewController(withIdentifier: "ECMMainVC") as? ECMMainVC)!
        
        //switchToECM.mainFolderID = String(objMilestone.fOLDERID)
        CommonFunctions().OpenECMFromAttachmentCount(folderID: objMilestone.fOLDERID, sourceVC: self)
        //getFolderAPI(folderID: objMilestone.fOLDERID, vc: switchToECM)
        
    }
    
    @objc func completedin10daysClicked(sender : UIButton) {
        let objMilestone = self.arrayMilestone[sender.tag]
        if ((objMilestone.tasksSummary?[2].cATEGORYCOUNT) == 0)  {
            return
        }
        segmentedControl.items = ["Not Started (\(((String(describing: (objMilestone.tasksSummary?[0].cATEGORYCOUNT)!)))))","In Progress (\(((String(describing: (objMilestone.tasksSummary?[1].cATEGORYCOUNT)!)))))","Completed (\(((String(describing: (objMilestone.tasksSummary?[2].cATEGORYCOUNT)!)))))"]
        segmentedControl.selectedIndex = 2
        lblSprintName.text = self.arrayMilestone[sender.tag].sPRINTNAME
        segmentedControl.font = UIFont(name: "Gotham-Book", size: 12)
        strTableHeader = "Completed in 10 Days"
        lblHeader2.text = self.arrayMilestone[sender.tag].pROJECTNAME
        self.setGesture()
        if ((objMilestone.tasksSummary?[2].cATEGORYCOUNT) == 0)  {
            return
        }
        self.getTaskDetailsfromSprintId(sprintID: self.arrayMilestone[sender.tag].sPRINTID, statusID: 3)
        
    }
    
    //MARK TICKET
    @objc func btnTixClicked(sender : UIButton) {
        let objTaskArrayID = self.arrayMilestone[sender.tag]
        if ((objTaskArrayID.oPENTIX + objTaskArrayID.oNHOLDTIX + objTaskArrayID.cLOSEDTIX) != 0) {
            let pushVC : TaskBreakdownNewVC = ((appDel?.WIPNewStoryBoard.instantiateViewController(withIdentifier: "TaskBreakdownNewVC")) as? TaskBreakdownNewVC)!
            appDel?.selectedProjectId = objTaskArrayID.pROJECTID
            pushVC.projectModel = objTaskArrayID
            
            self.navigationController?.pushViewController(pushVC, animated: true)
        }
    }
    
   
   
    @objc func DocClicked(sender : UIButton) {
        let taskDetails = appDel?.InsightStoryBoard.instantiateViewController(withIdentifier: "TaskDetailsVC") as? TaskDetailsVC
        taskDetails?.tASKID = self.myTaskArray[sender.tag].tASKID
        taskDetails?.isDirectDocument = true
        self.navigationController?.pushViewController(taskDetails!, animated: true)
    }
    @IBAction func onFilter(_ sender: Any) {
        
        return
    }
    func openDropDown(){
        let projectLists = NSMutableArray()
        for itemObj in projectsArray {
            projectLists.add(itemObj.PROJECT_NAME as Any)
        }
        projectLists.add("All")
        if appDel?.oldFilterArray.count == 0 {
            appDel?.oldFilterArray.add(NSIndexPath(row: self.projectsArray.count, section: 0))
        }
        
//        dropDownObj = DropDownListView(title: "Select Project", options: projectLists as! [Any], xy: CGPoint(x: 0, y: 60), size: CGSize(width: (appDel?.window?.frame.size.width)!, height: 300), isMultiple: true, withOldArray: appDel?.oldFilterArray)

        dropDownObj = DropDownListView(title: "Select Company", options: projectLists as? [Any], xy: CGPoint(x: 0, y: 60), size: CGSize(width: (appDel?.window?.frame.size.width)!, height: 300), isMultiple: true)
        
        dropDownObj?.arryData = appDel?.oldFilterArray
        
        dropDownObj?.delegate = self
        //dropDownObj?.setBackGroundDropDwon_R(0.1647058824, g: 0.6470588235, b: 0.2470588235, alpha: 0.8)
        dropDownObj?.show(in: self.view, animated: true)
    }
    
    @IBAction func onTaskBackClicked(_ sender: Any) {
        self.viewTaskListing.isHidden = true
        self.viewFilterSort.isHidden = true
        setProjectRefreshView()
    }
    
    @IBAction func onSelectionDone(_ sender: Any) {
        self.viewTaskListing.isHidden = true
        self.viewFilterSort.isHidden = true
        setProjectRefreshView()
        
        self.arrayMilestone.removeAll()
        RunLoop.current.run(until: Date.init(timeIntervalSinceNow: 1))
        self.collectionViewprojects.reloadData()
        
        for objModel in (appDel?.projectSortArray)!{
            if objModel.isSelected {
                self.getProjectMilestones(sortby: (objModel.id)!, isDesc: self.isDesc)
            }
        }
    }
    func SortingEnabledId() -> Int{
        for objModel in (appDel?.projectSortArray)!{
            if objModel.isSelected {
                return objModel.id!
            }
        }
        return 0
    }
    func ProjectFilterArray(){
        if self.projectsArray.last?.isSelected == true{
            
        }
        else{
            self.arrayMilestone.removeAll()
            for projModel in self.projectsArray {
                if projModel.isSelected == true{
                    for milestoneObj in (self.allArrayMilestone) {
                        if milestoneObj.pROJECTID == projModel.PROJECT_ID {
                            self.arrayMilestone.append(milestoneObj)
                        }
                    }
                }
            }
        }
        
        self.lblHeader.attributedText = CommonFunctions().getHeader(title: (appDel?.userObj.projectPlural_label)!, count: String((appDel?.objInsightCount?.pROJECTTASKCOUNT.withCommas())!))
        self.lblHeader3.attributedText = CommonFunctions().getHeader(title: (appDel?.userObj.projectPlural_label)!, count: String((appDel?.objInsightCount?.pROJECTTASKCOUNT.withCommas())!))
        self.collectionViewprojects.reloadData()
        appDel?.loader.stopAnimatingGIF()
        appDel?.loader.isHidden = true
            
        
    }
    @IBAction func onFilterSort(_ sender: Any) {
        if self.SortingEnabledId() == 0 && appDel?.projectSortArray.count != 0{
            let objModel = SortProjectModel(JSON: [:])
            objModel?.name = appDel?.projectSortArray[0].name
            objModel?.id = appDel?.projectSortArray[0].id
            objModel?.isSelected = true
            appDel?.projectSortArray[0] = objModel!
        }
        
        //        self.lblHeader.text = "Ongoing Projects (\((appDel?.objInsightCount?.pROJECTTASKCOUNT)!))"
        //        self.lblHeader3.text = "Ongoing Projects (\((appDel?.objInsightCount?.pROJECTTASKCOUNT)!))"
        
        self.lblHeader.attributedText = CommonFunctions().getHeader(title: (appDel?.userObj.projectPlural_label)!, count: String((appDel?.objInsightCount?.pROJECTTASKCOUNT.withCommas())!))
        self.lblHeader3.attributedText = CommonFunctions().getHeader(title: (appDel?.userObj.projectPlural_label)!, count: String((appDel?.objInsightCount?.pROJECTTASKCOUNT.withCommas())!))
        
        self.viewFilterSort.isHidden = false
        self.tblSort.reloadData()
    }
    
    //MARK: Get List
    func getProjectMilestones(sortby : Int , isDesc : Bool){
        CommonFunctions().animate()
        var parameters :[String:AnyObject] = [:]
        parameters  = ["SortBy":sortby as AnyObject,"IsDesc" : (isDesc == true) ? "true" as AnyObject : "false" as AnyObject]
        if sortby == 0{
            parameters = ["IsDesc" : (isDesc == true) ? "true" as AnyObject : "false" as AnyObject]
        }
        let manager = APIManager.apiManager
        manager.postArrayDatadicFromUrl(url: "360i/ongoingprojects/sprints", dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    self.arrayMilestone = Mapper<OngoingProjectNewModel>().mapArray(JSONObject: taskArray) ?? []
                    self.allArrayMilestone = self.arrayMilestone
                }
                DispatchQueue.main.async {
                    self.refreshControl.endRefreshing()
                    CommonFunctions().stopAnimate()
                    
                    self.ProjectFilterArray()
                }
                
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    self.refreshControl.endRefreshing()
                    CommonFunctions().stopAnimate()
                }
                
            }
            else {
                DispatchQueue.main.async {
                    self.refreshControl.endRefreshing()
                    CommonFunctions().stopAnimate()
                }
                
            }
        }
    }
    //MARK: Get List
    func getTaskDetailsfromSprintId(sprintID : Int,statusID : Int){
        selectedSprintID = sprintID
        selectedStatusID = statusID
        selectedSprint = sprintID
        CommonFunctions().animate()
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "360i/ongoingprojects/sprints/\(sprintID)/\(statusID)", dic: parameters ) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    self.refreshControl2.endRefreshing()
                    if let taskArray : NSArray = dataResponse as? NSArray
                    {
                        self.myTaskArray = Mapper<MyTaskModel>().mapArray(JSONObject: taskArray) ?? []
                        self.AlltaskArray = Mapper<MyTaskModel>().mapArray(JSONObject: taskArray) ?? []
                    }
                    if self.isFirstTimeDetails == true{
                        self.isFirstTimeDetails = false
                    }
                    else{
                        self.viewTaskListing.isHidden = false
                        self.removeCollectionRefreshView()
                    }
                    self.cVTasks.reloadData()
                    if self.myTaskArray.count >= 1{
                        self.lblNoTask.isHidden = true
                        self.cVTasks.setContentOffset(CGPoint(x:0,y:0), animated: true)
                    }
                    else{
                        self.lblNoTask.isHidden = false
                    }
                }
            }
            else if (result == APIResult.APIError){
                
                DispatchQueue.main.async {
                    self.refreshControl2.endRefreshing()
                    CommonFunctions().stopAnimate()
                }
            }
            else {
                
                DispatchQueue.main.async {
                    self.refreshControl2.endRefreshing()
                    CommonFunctions().stopAnimate()
                }
            }
        }
    }
    
    //MARK: Get List
    func getProjectLists(isOpen: Bool){
        CommonFunctions().animate()
        let parameters :[String:AnyObject] = [:]
        //let parameters  : NSDictionary = ["ProjectIds" : [sprintID]]
        let manager = APIManager.apiManager
        manager.getDatadicFromUrl(url: "360i/ongoingprojects/projects", dic: parameters ) { (dataResponse, result) in
            DispatchQueue.main.async {
                appDel?.loader.stopAnimatingGIF()
                appDel?.loader.isHidden = true
            }
            if (result == APIResult.APISuccess) {
                if let taskArray : NSArray = dataResponse as? NSArray
                {
                    self.projectsArray = Mapper<ProjectOngoingModel>().mapArray(JSONObject: taskArray) ?? []
                }
                let obj = ProjectOngoingModel(JSON: [:])
                obj?.PROJECT_ID = 0
                obj?.PROJECT_NAME = "All"
                obj?.isSelected = true
                self.projectsArray.append(obj!)
                self.getProjectMilestones(sortby: self.sortByInt, isDesc: self.isDesc)
                if isOpen == true && self.projectsArray.count >= 1{
                    self.tblSort.tag = 16
                    self.tblSort.reloadData()
                }
            }
            else if (result == APIResult.APIError){
                
                DispatchQueue.main.async {
                    
                    CommonFunctions().stopAnimate()
                }
            }
            else {
                
                DispatchQueue.main.async {
                    
                    CommonFunctions().stopAnimate()
                }
            }
        }
    }
    
    
    //MARK: UItableview Delegate Methods
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return false
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        if tableView != tblMenu {
            let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.size.width, height: 10))
            headerView.backgroundColor = UIColor.clear
            return headerView
        }
        else {
            return nil
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if tableView != tblMenu {
            return 10
        }
        else {
            return 0
        }
        
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]?
    {
        if tableView != tblMenu {
            if tableView == tblSort{
                return nil
            }
            if strTableHeader != "Not Started"{
                return nil
            }
            return nil
        }
        else {
            return nil
        }
        
    }
    
    @available(iOS 11.0, *)
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        if tableView != tblMenu {
            if tableView == tblSort{
                return nil
            }
            if strTableHeader != "Not Started"{
                return nil
            }
            return nil
        }
        else {
            return nil
        }
    }
    
    @available(iOS 11.0, *)
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        if tableView != tblMenu {
            if tableView == tblSort{
                return nil
            }
            if strTableHeader != "Not Started"{
                return nil
            }
            return nil
        }
        else {
            return nil
        }
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        if tableView == tblSort{
            if self.tblSort.tag == 16{
                return 1
            }
            return 1
        }
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView != tblMenu {
            if tableView == tblSort{
                if self.tblSort.tag == 16{
                    return self.projectsArray.count
                }
                return (appDel?.projectSortArray.count)!
            }
            return menuArray.count
        }
        else {
            return taskActionMenu.count
        }
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView != tblMenu {
            if tableView == tblSort{
                let cell = tableView.dequeueReusableCell(withIdentifier: "OnsightSortListCell", for: indexPath) as? OnsightSortListCell
                cell?.selectionStyle = .none
                if let colorcode : String = UserDefaults.standard.object(forKey: themeBorder) as? String{
                    cell?.layer.borderColor = hexStringToUIColor(hex: colorcode).cgColor
                }
                if self.tblSort.tag == 15{
                    cell?.lblName.text = appDel?.projectSortArray[indexPath.row].name
                    if appDel?.projectSortArray[indexPath.row].isSelected == true{
                        cell?.btnSelected.isSelected = true
                        cell?.btnSelected.imageView?.setImageThemeColor()
                        cell?.btnSelected.backgroundColor = UIColor.white
                    }
                    else{
                        cell?.btnSelected.isSelected = false
                        cell?.btnSelected.backgroundColor = UIColor.clear
                    }
                }
                else{
                    cell?.lblName.text = self.projectsArray[indexPath.row].PROJECT_NAME
                    if self.projectsArray[indexPath.row].isSelected == true{
                        cell?.btnSelected.isSelected = true
                        cell?.btnSelected.imageView?.setImageThemeColor()
                        cell?.btnSelected.backgroundColor = UIColor.white
                    }
                    else{
                        cell?.btnSelected.isSelected = false
                        cell?.btnSelected.imageView?.contentMode = .scaleToFill
                        cell?.btnSelected.backgroundColor = UIColor.clear
                    }
                }
                cell?.btnSelected.imageView?.contentMode = .scaleToFill
                return cell!
            }
            let cell = tableView.dequeueReusableCell(withIdentifier: "360menuCell", for: indexPath) as? OnsightSortListCell
            
            cell?.lblName.text = self.menuArray[indexPath.row]
            
            return cell!
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "MenuAction", for: indexPath) as? ECMContactCell
            
            cell?.lblName?.text = self.taskActionMenu[indexPath.row]
            
            //cell?.lblName?.textAlignment = .center
            cell?.lblName?.textColor = theme_selected_color!
            cell?.lblName?.font = UIFont.init(name: gothamMedium, size: 17)
            
            cell?.imgIcon.tintColor = theme_selected_color!
            if cell?.lblName.text == menuItem1 {
                cell?.imgIcon.image = #imageLiteral(resourceName: "play48.png")
            }
            if cell?.lblName.text == menuItem2 {
                cell?.imgIcon.image = #imageLiteral(resourceName: "revised48.png")
                cell?.imgIcon.tintColor = theme_selected_color!
            }
            if cell?.lblName.text == menuItem3 {
                cell?.imgIcon.image = #imageLiteral(resourceName: "follow48.png")
            }
            if cell?.lblName.text == menuItem4 {
                cell?.imgIcon.image = #imageLiteral(resourceName: "Progress48.png")
                cell?.imgIcon.tintColor = theme_selected_color!
            }
            if cell?.lblName.text == menuItem5 {
                cell?.imgIcon.image = #imageLiteral(resourceName: "Note48.png")
            }
            if cell?.lblName.text == menuItem6 {
                cell?.imgIcon.image = #imageLiteral(resourceName: "attachment48.png")
            }
            if cell?.lblName.text == menuItem7 {
                cell?.imgIcon.image = #imageLiteral(resourceName: "roadblock48.png")
                cell?.imgIcon.tintColor = theme_selected_color!
            }
            if cell?.lblName.text == menuItem8 {
                cell?.imgIcon.image = #imageLiteral(resourceName: "subtask48.png")
                cell?.imgIcon.tintColor = theme_selected_color!
                //cell?.imgIcon.backgroundColor = theme_selected_color!
            }
            if cell?.lblName.text == menuItem9 {
                //cell?.imgIcon.image = #imageLiteral(resourceName: "bug.png")
                cell?.imgIcon.image = #imageLiteral(resourceName: "bug48.png")
                cell?.imgIcon.tintColor = .red
            }
            
            if indexPath.row == 2 {
                cell?.lblEmail.isHidden = false
            }
            else {
                cell?.lblEmail.isHidden = true
            }
            return cell!
        }
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        if tableView != tblMenu {
            if tableView == tblSort{
                if self.tblSort.tag == 15{
                    let intCount = appDel?.projectSortArray.count
                    for i in 0...intCount! - 1 {
                        if i == indexPath.row{
                            let objModel = SortProjectModel(JSON: [:])
                            objModel?.name = appDel?.projectSortArray[i].name
                            objModel?.id = appDel?.projectSortArray[i].id
                            if (appDel?.projectSortArray[i].isSelected) == true{
                                if self.SortingEnabledId() != objModel?.id{
                                    objModel?.isSelected = !(appDel?.projectSortArray[i].isSelected)!
                                    appDel?.projectSortArray[i] = objModel!
                                    
                                }
                                else{
                                    
                                }
                            }
                            else{
                                objModel?.isSelected = !(appDel?.projectSortArray[i].isSelected)!
                                appDel?.projectSortArray[i] = objModel!
                                
                            }
                        }
                        else{
                            let objModel = SortProjectModel(JSON: [:])
                            objModel?.name = appDel?.projectSortArray[i].name
                            objModel?.id = appDel?.projectSortArray[i].id
                            objModel?.isSelected = false
                            appDel?.projectSortArray[i] = objModel!
                        }
                    }
                    self.tblSort.reloadData()
                }
                else{
                    let objModel = ProjectOngoingModel(JSON: [:])
                    objModel?.PROJECT_NAME = projectsArray[indexPath.row].PROJECT_NAME
                    objModel?.PROJECT_ID = self.projectsArray[indexPath.row].PROJECT_ID
                    objModel?.isSelected = !self.projectsArray[indexPath.row].isSelected
                    self.projectsArray[indexPath.row] = objModel!
                    let intCount = self.projectsArray.count
                    
                    if indexPath.row == self.projectsArray.count - 1{
                        for i in 0...intCount - 1 {
                            if i == indexPath.row{
                                
                            }
                            else{
                                let objModel = ProjectOngoingModel(JSON: [:])
                                objModel?.PROJECT_NAME = projectsArray[i].PROJECT_NAME
                                objModel?.PROJECT_ID = self.projectsArray[i].PROJECT_ID
                                objModel?.isSelected = true
                                self.projectsArray[i] = objModel!
                            }
                        }
                    }
                    else{
                        let objModel = ProjectOngoingModel(JSON: [:])
                        objModel?.PROJECT_NAME = "All"
                        objModel?.PROJECT_ID = 0
                        objModel?.isSelected = false
                        self.projectsArray[intCount - 1] = objModel!
                    }
                    self.tblSort.reloadData()
                    
                }
                return
            }
            else {
                if menuArray[indexPath.row] == "ProgressEntry" {
                    UserDefaults.standard.set(false, forKey: "FromRecentPE")
                    appDel?.selectedUserID = (appDel?.userObj.USERID)!
                    let controller = (appDel?.WIPNewStoryBoard.instantiateViewController(withIdentifier: "CreateProgressEntryVC"))!
                    self.navigationController?.pushViewController(controller, animated: true)
                }
                else if menuArray[indexPath.row] == "Work Item" {
                    let controller : CreateTaskNewVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateTaskNewVC"))! as! CreateTaskNewVC
                    controller.allProject = false
                    controller.selectedUserID = (appDel?.userObj.USERID)!
                    self.navigationController?.pushViewController(controller, animated: true)
                    
                }
                else if menuArray[indexPath.row] == "Ticket" {
                    appDel?.selectedQueueID = 0
                    appDel?.selectedTicketTypeID = 0
                    
                    
                    let createTicketVC = appDel?.WIPNewStoryBoard.instantiateViewController(withIdentifier: "CreateTicketVC") as? CreateTicketVC
                    
                    self.navigationController?.pushViewController(createTicketVC!, animated: true)
                }
                else if menuArray[indexPath.row] == "Time-Off" {
                    let aplyTimeOffVC = appDel?.PMSStoryBoard.instantiateViewController(withIdentifier: "ApplyTimeOffVC") as? ApplyTimeOffVC
                    self.navigationController?.pushViewController(aplyTimeOffVC!, animated: true)
                    
                }
                else if menuArray[indexPath.row] == "Activity" {
                    let controller : CreateActivityVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateActivityVC"))! as! CreateActivityVC
                    self.navigationController?.pushViewController(controller, animated: true)
                    
                }
                else if menuArray[indexPath.row] == "Lead" {
                    let controller : CreateLeadVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateLeadVC"))! as! CreateLeadVC
                    self.navigationController?.pushViewController(controller, animated: true)
                    
                }
                else if menuArray[indexPath.row] == "Opportunity" {
                    let controller : CreateOpportunityVC = (appDel?.WIPTaskStoryBoard.instantiateViewController(withIdentifier: "CreateOpportunityVC"))! as! CreateOpportunityVC
                    self.navigationController?.pushViewController(controller, animated: true)
                    
                }
                else if menuArray[indexPath.row] == "To-Do" {
                    let todoVC = appDel?.todoStoryBoard.instantiateViewController(withIdentifier: "CreateToDoVC") as? CreateToDoVC
                    self.navigationController?.pushViewController(todoVC!, animated: true)
                    
                }
            }
        }
        else {
            self.actionMenu.hideWithCustomAnimation(animation: .curveLinear, hidden: true)
            CommonFunctions().taskActionMenu(index: indexPath.row, task: myTaskSelected, vc: self)
        }
        
    }
    
    func seeMoreClicked(sender : UIButton) {
        let index = sender.tag
        selectedIndex = index
        if sender.title(for: .normal) == "See more" {
        }
        else{
            selectedIndex = 1000
        }
    }

    //MARK: UIcollection Delegate Methods
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        if collectionView == cVTasks {
            let width = UIScreen.main.bounds.width
            let height = UIScreen.main.bounds.height
            //let cellRatio: CGFloat = 300 / 214
            if UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiom.pad {
                
                return CGSize(width: 300, height: 214)
            }
            else {
                if (width == 568) || (width == 320) || (width == 480){
                    return CGSize(width: 300, height: 214)
                }
                else if UIDevice.current.orientation.isLandscape {
                    let dispWidth = width / 2 - 20
                    return CGSize(width: dispWidth, height: 214)
                }
                else if UIDevice.current.orientation.isFlat {
                    if width < 370 {
                        return CGSize(width: 300, height: 214)
                    }
                    if width < height {
                        return CGSize(width: width - 10, height: 214)
                    }
                    else {
                        let dispWidth = width / 2 - 20
                        return CGSize(width: dispWidth, height: 214)
                    }
                }
                else {
                    if width < height {
                        return CGSize(width: width - 10, height: 214)
                    }
                    let dispWidth = width / 2 - 20
                    return CGSize(width: dispWidth, height: 214)
                }
            }
        }
        else {
            let width = UIScreen.main.bounds.width
            let height = UIScreen.main.bounds.height
            let cellRatio: CGFloat = 300 / 256
            
            if UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiom.pad {
                return CGSize(width: 300, height: 300 / cellRatio)
            }
            else {
                if (width == 568) || (width == 320) || (width == 480){
                    return CGSize(width: 300, height: 300 / cellRatio)
                }
                else if UIDevice.current.orientation.isLandscape {
                    let dispWidth = width / 2 - 10
                    return CGSize(width: dispWidth, height: dispWidth / cellRatio)
                }
                else if UIDevice.current.orientation.isFlat {
                    //this is sample size returning. here we have to handle our various device size
                    if width < 370 {
                        return CGSize(width: 300, height: 300 / cellRatio)
                    }
                    if width < height {
                        return CGSize(width: width, height: width / cellRatio)
                    }
                    else {
                        let dispWidth = width / 2 - 10
                        return CGSize(width: dispWidth, height: dispWidth / cellRatio)
                    }
                }//if above condition not available then it come here even your your device looking like landscape
                else {
                    if width < height {
                        return CGSize(width: width, height: width / cellRatio)
                    }
                    let dispWidth = width / 2 - 10
                    return CGSize(width: dispWidth, height: dispWidth / cellRatio)
                }
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if collectionView == cVTasks {
            return 10
        }
        return 1
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if collectionView == cVTasks {
            return 10
        }
        return 1
    }
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if collectionView == cVTasks {
            return UIEdgeInsets.init(top: 10, left: 10, bottom: 10, right: 10)
        }
        else {
            return UIEdgeInsets.init(top: 0, left: 0, bottom: 2.0, right: 0)
        }
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == cVTasks {
            return myTaskArray.count
        }
        else {
            return arrayMilestone.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == cVTasks {
            let cell : MyTasksCVCell = (collectionView.dequeueReusableCell(withReuseIdentifier: "Tasks", for: indexPath) as? MyTasksCVCell)!
            cell.setNewView(objTask: self.myTaskArray[indexPath.row])
            
            cell.btnAttachment.addTarget(self, action: #selector(self.DocClicked(sender:)), for: .touchUpInside)
            cell.btnAttachment.tag = indexPath.row
            
            cell.btnDelete.addTarget(self, action: #selector(self.deleteTaskClicked), for: .touchUpInside)
            cell.btnDelete.tag = indexPath.row
            
            cell.btnClose.addTarget(self, action: #selector(self.removeTaskClicked), for: .touchUpInside)
            cell.btnClose.tag = indexPath.row
            
            cell.btnTaskStatus.isHidden = true
            
            cell.btnMenu.addTarget(self, action: #selector(self.opencontextMenu), for: .touchUpInside)
            cell.btnMenu.tag = indexPath.row
            
            return cell
        }
        else {
            let cell : OngoingProjectCell = collectionView.dequeueReusableCell(withReuseIdentifier: "OngoingProjectCell", for: indexPath) as! OngoingProjectCell
            cell.setValues(objMilestone: arrayMilestone[indexPath.row], isUnassigned: false)
            
            cell.btnNotstarted.addTarget(self, action: #selector(self.notcompletedClicked(sender:)), for: .touchUpInside)
            cell.btnNotstarted.tag = indexPath.row
            
            cell.btnInprogress.addTarget(self, action: #selector(self.inProgressClicked(sender:)), for: .touchUpInside)
            cell.btnInprogress.tag = indexPath.row
            
            cell.btnCompleted.addTarget(self, action: #selector(self.completedin10daysClicked(sender:)), for: .touchUpInside)
            cell.btnCompleted.tag = indexPath.row
            
            cell.btnAdd.addTarget(self, action: #selector(self.addTaskClicked(sender:)), for: .touchUpInside)
            cell.btnAdd.tag = indexPath.row
            
            cell.btnProject.addTarget(self, action: #selector(self.projectClicked(sender:)), for: .touchUpInside)
            cell.btnProject.tag = indexPath.row
            
            cell.btnAttchmnt.addTarget(self, action: #selector(self.attchmntClicked(sender:)), for: .touchUpInside)
            cell.btnAttchmnt.tag = indexPath.row
            
            cell.lblOpenTix.text = String(self.arrayMilestone[indexPath.row].oPENTIX.withCommas())
            cell.lblOpenTix.adjustsFontSizeToFitWidth = true
            cell.lblOnHoldTix.text = String(self.arrayMilestone[indexPath.row].oNHOLDTIX.withCommas())
            cell.lblOnHoldTix.adjustsFontSizeToFitWidth = true
            cell.lblClosedTix.text = String(self.arrayMilestone[indexPath.row].cLOSEDTIX.withCommas())
            cell.lblClosedTix.adjustsFontSizeToFitWidth = true
            
            cell.btnForTickets.addTarget(self, action: #selector(self.btnTixClicked(sender:)), for: .touchUpInside)
            cell.btnForTickets.tag = indexPath.row
            return cell
        }
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == cVTasks {
            let taskDetails = appDel?.InsightStoryBoard.instantiateViewController(withIdentifier: "TaskDetailsVC") as? TaskDetailsVC
            taskDetails?.tASKID = self.myTaskArray[indexPath.row].tASKID
            taskDetails?.isDirectDescription = true
            self.navigationController?.pushViewController(taskDetails!, animated: true)
        }
    }
    
    @objc func opencontextMenu(sender: UIButton){
        if let cell : MyTasksCVCell = sender.superview?.superview?.superview?.superview as? MyTasksCVCell {
            let indexPath = cVTasks.indexPath(for: cell)
            myTaskSelected = self.myTaskArray[(indexPath?.row)!]
            if myTaskSelected?.tASK_TYPE_ID == 2 {
                if myTaskSelected?.pARENT_TASK_ID != 0 {
                    self.taskActionMenu = [menuItem1,menuItem2,menuItem3,menuItem4,menuItem5,menuItem6,menuItem8,menuItem9]
                }
                else {
                    self.taskActionMenu = [menuItem1,menuItem2,menuItem3,menuItem4,menuItem5,menuItem6]
                }
            }
            else if myTaskSelected?.tASK_TYPE_ID == 4 || myTaskSelected?.tASK_TYPE_ID == 3 {
                if myTaskSelected?.pARENT_TASK_ID != 0 {
                    self.taskActionMenu = TaskActionMenu
                }
                else {
                    self.taskActionMenu = [menuItem1,menuItem2,menuItem3,menuItem4,menuItem5,menuItem6,menuItem7]
                }
                
            }
            else {
                self.taskActionMenu = TaskActionMenu
            }
            tblMenu.reloadData()
            self.actionMenu.hideWithCustomAnimation(animation: .curveEaseIn, hidden: false)
            
            let cells = tblMenu.visibleCells
            let tableHeight: CGFloat = tblMenu.bounds.size.height
                
            for i in cells {
                let cell: UITableViewCell = i as UITableViewCell
                cell.transform = CGAffineTransform(translationX: 0, y: tableHeight)
            }
                
            var index = 0
                
            for a in cells {
                let cell: UITableViewCell = a as UITableViewCell
                
                UIView.animate(withDuration: 0.5, delay: 0.05 * Double(index), options: [.curveLinear],
                animations: {
                    cell.transform = CGAffineTransform(translationX: 0, y: 0);
                }, completion: nil)
                    
                index += 1
            }
            
        }
    }
    
    
    //MARK: Delete Task
    @objc func deleteTaskClicked(sender : UIButton) {
        
        if let cell : MyTasksCVCell = sender.superview?.superview?.superview as? MyTasksCVCell {
            let indexPath = cVTasks.indexPath(for: cell)
            let objTask = self.myTaskArray[(indexPath?.row)!]
            if objTask.cANDELETETASK == 1 {
                CommonFunctions().showThemeAlert(msgTitle: "Alert", msg: "Are you sure you want to delete ?") { (isSuccess) in
                    if isSuccess {
                        self.deleteTask(objTask: objTask)
                    }
                    else {
                        self.userDidSwipeRight()
                    }
                }
            }
            else {
                self.view.makeToast(msgDeleteTask)
            }
        }
    }
    
    func deleteTask(objTask : MyTaskModel){
        let parameters :[String:AnyObject] = [:]
        let manager = APIManager.apiManager
        CommonFunctions().animate()
        manager.DeleteDatadicFromUrlWithoutProgress(url: "pms/task/\((objTask.tASKID))", dic: parameters) { (dataResponse, result) in
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        if (resultDic.value(forKey: "fail") != nil){
                            
                            self.view.makeToast(msgTaskNotDeleted)
                            
                            return
                        }
                    }
                    self.view.makeToast(msgTaskDeleteSuccess)
                    self.getTaskDetailsfromSprintId(sprintID: self.selectedSprintID, statusID: self.selectedStatusID)
                    self.userDidSwipeRight()
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    self.view.makeToast(msgUnauthorised)
                }
                
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    self.view.makeToast(msgSomethingWrong)
                }
            }
        }
    }
    
    //MARK: Close Task
    @objc func removeTaskClicked(sender : UIButton) {
        if let cell : MyTasksCVCell = sender.superview?.superview?.superview as? MyTasksCVCell {
            let indexPath = cVTasks.indexPath(for: cell)
            let objTask = self.myTaskArray[(indexPath?.row)!]
            if objTask.cANREVISETASK == 1 {
                self.closeTask(objTask: objTask)
            }
            else {
                self.view.makeToast(msgCloseTask)
            }
        }
    }
    
    func closeTask(objTask : MyTaskModel){
        var dateStr : String = ""
        let dateFormattr = DateFormatter()
        dateFormattr.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        if (objTask.tASKENDDATE != ""){
            if let dateObj = dateFormattr.date(from: objTask.tASKENDDATE){
                let dateFormatterM = DateFormatter()
                dateFormatterM.dateFormat = "yyyy-MM-dd"
                dateStr = dateFormatterM.string(from: dateObj)
            }
        }
        else{
            //self.view.makeToast("Task end date not available")
            //return
        }
        let parameters: NSDictionary = [
            "TASK_ID" : objTask.tASKID as Any,
            "ORIGINAL_HOURS" : objTask.aLLOCATEDHOURS as Any,
            "MANUAL_CLOSE" : "true",
            "COMMENTS" : "Work Item Completed",
            "REVISED_HOURS" : objTask.cOMPLETEDHOURS as Any,
            "TASK_END_DATE" : dateStr as Any,
            ]
        let manager = APIManager.apiManager
        CommonFunctions().animate()
        manager.postReviseTaskFromUrl(url: "pms/task/\((objTask.tASKID))/revise", dic: parameters as NSDictionary) { (dataResponse, result) in
            
            if (result == APIResult.APISuccess) {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    self.myTaskArray.removeAll()
                    self.AlltaskArray.removeAll()
                    self.cVTasks.reloadData()
                    appDel?.window?.makeToast(msgTaskCloseSuccess)
                    self.getTaskDetailsfromSprintId(sprintID: self.selectedSprintID, statusID: self.selectedStatusID)
                    self.userDidSwipeRight()
                }
            }
            else if (result == APIResult.APIError){
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    if let resultDic : NSDictionary = dataResponse as? NSDictionary
                    {
                        CommonFunctions().showErrorMessage(resultDic: resultDic)
                    }
                }
                
                
            }
            else {
                DispatchQueue.main.async {
                    CommonFunctions().stopAnimate()
                    
                    appDel?.window?.makeToast(msgSomethingWrong)
                }
            }
        }
    }
    
    //MARK: Multiselect Dropdown
    
    func dropDownListView(_ dropdownListView: DropDownListView!, didSelectedIndex anIndex: Int) {
        if anIndex == self.projectsArray.count {
            appDel?.oldFilterArray.removeAllObjects()
            appDel?.oldFilterArray.add(NSIndexPath(row: self.projectsArray.count, section: 0))
        }
        else{
            let indespth = NSIndexPath(row: self.projectsArray.count, section: 0)
            appDel?.oldFilterArray.remove(indespth)
        }
        dropDownObj?.reloadInputViews()
    }
    func dropDownListView(_ dropdownListView: DropDownListView!, datalist ArryData: NSMutableArray!) {
        appDel?.oldFilterArray = (dropDownObj?.arryData)!
        if ArryData.count >= 1 {
            self.arrayMilestone.removeAll()
            RunLoop.current.run(until: Date.init(timeIntervalSinceNow: 1))
            self.collectionViewprojects.reloadData()
        }
        arrProjectSelected = ArryData
        sortByProjects(ArryData: ArryData)
    }
    func dropDownListViewDidCancel() {
        
    }
    func sortByProjects(ArryData : NSMutableArray){
        if ArryData.count >= 1 {
            self.arrayMilestone.removeAll()
        }
        for projModel in self.projectsArray {
            for data in ArryData {
                if let nameStr : String = data as? String{
                    if nameStr == "All" {
                        appDel?.oldFilterArray.removeAllObjects()
                        return
                    }
                    if nameStr == projModel.PROJECT_NAME {
                        for milestoneObj in (self.allArrayMilestone) {
                            if milestoneObj.pROJECTID == projModel.PROJECT_ID {
                                self.arrayMilestone.append(milestoneObj)
                            }
                        }
                    }
                }
            }
        }
        RunLoop.current.run(until: Date.init(timeIntervalSinceNow: 1))
        collectionViewprojects.reloadData()
        
    }
    
    //MARK: Textfield Delegate Method
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        openSortBy()
        return false
    }
   
}
extension WIPOngoingProjectNewVC : UISearchBarDelegate {
    //MARK: SEARCHBAR DELEGATE
    func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        return true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        view.addGestureRecognizer(tap)
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchBar.text == "" {
            
            myTaskArray = AlltaskArray
            
            cVTasks.reloadData()
            return
        }
        self.showSearchResult(searchText: searchText)
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        if searchBar.text != "" {
            self.view.endEditing(true)
            self.searchBar.endEditing(true)
            self.showSearchResult(searchText: searchBar.text!)
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        
        self.myTaskArray = AlltaskArray
        self.cVTasks.reloadData()
        
    }
    func showSearchResult(searchText: String) {
        myTaskArray.removeAll()
        
        if searchText != "" {
            let namePredicate = NSPredicate(format: "SELF contains[cd] %@",  searchText)
            //taskArray.append(contentsOf: AlltaskArray.filter {namePredicate.evaluate(with: $0.tASKDESCRIPTION)})
            if searchText.isInt {
                myTaskArray.append(contentsOf: AlltaskArray.filter {namePredicate.evaluate(with: $0.tASKSTRINGID)})
            }
            else {
                myTaskArray.append(contentsOf: AlltaskArray.filter {namePredicate.evaluate(with: $0.tASKDESCRIPTION)})
                myTaskArray.append(contentsOf: AlltaskArray.filter {namePredicate.evaluate(with: $0.pROJECTNAME)})
            }
            
        } else {
            self.myTaskArray.append(contentsOf: AlltaskArray) //= (AlltaskArray)
        }
        self.myTaskArray = self.myTaskArray.unique{$0.tASKID}
        cVTasks.reloadData()
    }
}

