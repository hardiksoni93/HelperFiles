
import Foundation
import UIKit
import MBCircularProgressBar
import GTProgressBar

class MyTasksCVCell: UICollectionViewCell {
    
    @IBOutlet var lblProjectName: UILabel!
    @IBOutlet weak var lblMilestone: UILabel!
    
    @IBOutlet weak var btnViews: UIView!
    @IBOutlet weak var imgWorkItemType: UIImageView!
    @IBOutlet weak var imgEllipse: UIImageView!
    @IBOutlet weak var btnMenu: UIButton!
    
    
    @IBOutlet var lblTaskName: UILabel!
    @IBOutlet var custompProgressBar: GTProgressBar!
    
    @IBOutlet weak var lblTaskPercentage: UILabel!
    
    @IBOutlet var lblHours: UILabel!
    @IBOutlet var lblAttchmntCount: UILabel!
    
    @IBOutlet var lblTaskPriority: UILabel!
    @IBOutlet var lblOwnerPriority: UILabel!
    
    @IBOutlet var lblMigratedRiskCount: UILabel!
    @IBOutlet var lblOpenRiskCount: UILabel!
    @IBOutlet var lblGeneralNoteCount: UILabel!
    
    @IBOutlet weak var lblNoteTypeCount: UILabel!
    @IBOutlet weak var lblNoteTotalCount: UILabel!
    @IBOutlet weak var lblRoadBlock: UILabel!
    @IBOutlet weak var lblSubTaskCount: UILabel!
    @IBOutlet weak var lblBugCount: UILabel!
    
    @IBOutlet weak var imgBugIcon: UIImageView!
    @IBOutlet weak var imgSubTaskIcon: UIImageView!
    @IBOutlet weak var imgNoteIcon: UIImageView!
    @IBOutlet weak var imgRoadBlockIcon: UIImageView!
    @IBOutlet weak var imgAttachmentIcon: UIImageView!
    
    @IBOutlet weak var lblPlDate: UILabel!
    @IBOutlet weak var lblEndDate: UILabel!
    
    @IBOutlet var lblMonth: UILabel!
    @IBOutlet var lblDay: UILabel!
    @IBOutlet var lblWeekDay: UILabel!
    @IBOutlet var imgUser: UIImageView!
    @IBOutlet var viewprogress: MBCircularProgressBarView!
    
    @IBOutlet var bgView: UIView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var btnAttachment: UIButton!
 
    @IBOutlet weak var btnDelete: UIButton!
    @IBOutlet weak var btnClose: UIButton!
    @IBOutlet var DetailView: UIView!
    
    @IBOutlet weak var btnTaskStatus: UIButton!
    
    @IBOutlet weak var lblTaskType: UILabel!
    //Workboard outlet
    
    @IBOutlet weak var lblTaskStartTime: UILabel!
    @IBOutlet weak var imgClock: UIImageView!
    @IBOutlet weak var btnProgress: UIButton!
    @IBOutlet weak var btnProgressTaskDescription: UIButton!
    
    @IBOutlet weak var viewPriority: UIView!
    @IBOutlet weak var viewAttachment: UIView!
    @IBOutlet weak var viewroadblock: UIView!
    @IBOutlet weak var viewNote: UIView!
    @IBOutlet weak var viewSubtask: UIView!
    @IBOutlet weak var viewBug: UIView!
    @IBOutlet weak var viewDate: UIView!
    @IBOutlet weak var viewType: UIView!

    
    @IBOutlet weak var typeRightConstraint: NSLayoutConstraint!
    @IBOutlet weak var noteRightConstraint: NSLayoutConstraint!
    @IBOutlet weak var attachmentRightConstraint: NSLayoutConstraint!
    @IBOutlet weak var priorityRightConstraint: NSLayoutConstraint!
    @IBOutlet weak var dateRightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var prioritygRightConstraint: NSLayoutConstraint!
    @IBOutlet weak var attachRightConstraint: NSLayoutConstraint!
    @IBOutlet weak var roadblockRightConstraint: NSLayoutConstraint!
    @IBOutlet weak var notecountRightConstraint: NSLayoutConstraint!
    @IBOutlet weak var subtaskRightConstraint: NSLayoutConstraint!
    @IBOutlet weak var BugRightConstraint: NSLayoutConstraint!
    
    override var bounds: CGRect {
        didSet {
            self.layoutIfNeeded()
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    func setSearchTask(objTask: SearchTaskModel) {
        btnDelete.setTitle(String.fontAwesomeIcon(name: .trashO), for: .normal)
        btnClose.setImage(#imageLiteral(resourceName: "close_Icon.png"), for: .normal)
        
        //Set corner radius
        self.setCornerRadius()
        
        if btnViews != nil && imgWorkItemType != nil && imgEllipse != nil {
            btnViews.borderColor = theme_selected_color!
            if (objTask.pROJECTCOLORCODE != ""){
                btnViews.borderColor = hexStringToUIColor(hex: objTask.pROJECTCOLORCODE)
                imgEllipse.image = UIImage.fontAwesomeIcon(name: .ellipsisH, textColor: hexStringToUIColor(hex: objTask.pROJECTCOLORCODE), size: CGSize(width: 24, height: 21))
            }
            else {
                imgEllipse.image = UIImage.fontAwesomeIcon(name: .ellipsisH, textColor: .darkGray, size: CGSize(width: 24, height: 21))
                btnViews.borderColor = .darkGray
            }
            
            if objTask.tASKTYPEID == 1 {
                if (objTask.pROJECTCOLORCODE != ""){
                    imgWorkItemType.backgroundColor = hexStringToUIColor(hex: objTask.pROJECTCOLORCODE)
                }
                else {
                    imgWorkItemType.backgroundColor = .darkGray
                }
                imgWorkItemType.image = #imageLiteral(resourceName: "Task48x48.png")
            }
            else if objTask.tASKTYPEID == 2 {
                
                if (objTask.pROJECTCOLORCODE != ""){
                    imgWorkItemType.backgroundColor = hexStringToUIColor(hex: objTask.pROJECTCOLORCODE)
                }
                else {
                    imgWorkItemType.backgroundColor = .darkGray
                }
                
                imgWorkItemType.image = #imageLiteral(resourceName: "Activity48x48.png")
            }
            else if objTask.tASKTYPEID == 3 {
                imgWorkItemType.backgroundColor = .clear
                imgWorkItemType.image = UIImage.fontAwesomeIcon(name: .bug, textColor: .red, size: CGSize(width: imgWorkItemType.bounds.width, height: imgWorkItemType.bounds.height))
                
            }
                
            else if objTask.tASKTYPEID == 4 {
                if (objTask.pROJECTCOLORCODE != ""){
                    imgWorkItemType.backgroundColor = hexStringToUIColor(hex: objTask.pROJECTCOLORCODE)
                }
                else {
                    imgWorkItemType.backgroundColor = .darkGray
                }
                imgWorkItemType.image = #imageLiteral(resourceName: "subtask  48.png")
            }
        }
        
        
        lblUserName.text = ""
        bgView.backgroundColor = UIColor.darkGray
        viewprogress.progressColor = UIColor.darkGray
        lblProjectName.textColor = UIColor.darkGray
        custompProgressBar.barFillColor = UIColor.lightGray
        
        setUserImage(objTask: objTask)
        setcolor(objTask: objTask)
        setTaskTypecolor(objTask: objTask)
        
        if btnTaskStatus != nil {
            if objTask.iSACTIVETASK == 1 {
                btnTaskStatus.setImage(UIImage.fontAwesomeIcon(name: .pauseCircleO, textColor: theme_selected_color!, size: CGSize(width: btnTaskStatus.bounds.width, height: btnTaskStatus.bounds.height)), for: .normal)
                btnTaskStatus.imageView?.contentMode = .scaleAspectFill
            }
            else {
                btnTaskStatus.setImage(UIImage.fontAwesomeIcon(name: .playCircleO, textColor: theme_selected_color!, size: CGSize(width: btnTaskStatus.bounds.width, height: btnTaskStatus.bounds.height)), for: .normal)
                btnTaskStatus.imageView?.contentMode = .scaleAspectFill
            }
        }
        
        self.lblProjectName.text = objTask.pROJECTNAME
        self.lblMilestone.text = objTask.tASKSPRINTNAME
        setTaskName(objTask: objTask)
        setHourAndProgress(objTask: objTask)
        
        self.lblAttchmntCount.text = String(describing: (objTask.attachmentCount))
        self.lblAttchmntCount.adjustsFontSizeToFitWidth = true
        //self.lblOwnerPriority.isHidden = true
        self.lblTaskPriority.text = "\((objTask.oWNERPRIORITY))"
        //self.lblOwnerPriority.text = "\((objTask.tASKPRIORITY))"
        
        self.imgRoadBlockIcon.image = #imageLiteral(resourceName: "road block.png")
        self.lblRoadBlock.text = "\((objTask.rOADBLOCKCOUNT))"
        
        self.lblBugCount.text = "\((objTask.bUGCOUNT))"
        
        lblNoteTypeCount.textColor = .white
        if objTask.tASKOPENRISKCOUNT > 0 {
            lblNoteTypeCount.backgroundColor = .red
        }
        else {
            lblNoteTypeCount.backgroundColor = theme_orange_color
        }
        
        var avTypeNote = 0
        
        
        lblNoteTotalCount.text = "\((objTask.tASKNOTETOTALCOUNT))"
        
        if objTask.tASKMITIGATEDRISKCOUNT > 0 {
            avTypeNote += 1
        }
        if objTask.tASKOPENRISKCOUNT > 0 {
            avTypeNote += 1
        }
        if objTask.tASKNOTESCOUNT > 0 {
            avTypeNote += 1
        }
        
        lblNoteTypeCount.text = "\(String(describing: avTypeNote))"
        
//        self.lblMigratedRiskCount.text = "\((objTask.tASKMITIGATEDRISKCOUNT))"
//        self.lblOpenRiskCount.text = "\((objTask.tASKOPENRISKCOUNT))"
//        self.lblGeneralNoteCount.text = "\((objTask.tASKNOTESCOUNT))"
        
//        lblMigratedRiskCount.font = lblMigratedRiskCount.font.withSize(10)
//        lblOpenRiskCount.font = lblOpenRiskCount.font.withSize(10)
//        lblGeneralNoteCount.font = lblGeneralNoteCount.font.withSize(10)
//        lblMigratedRiskCount.adjustsFontSizeToFitWidth = true
//        lblOpenRiskCount.adjustsFontSizeToFitWidth = true
//        lblGeneralNoteCount.adjustsFontSizeToFitWidth = true
        
        
        let dateFormattr = DateFormatter()
        dateFormattr.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        let dateFormattr2 = DateFormatter()
        dateFormattr2.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
        
        self.lblPlDate.text = "-"
        self.lblEndDate.text = "-"
        
        if (objTask.pLANNEDSTARTDATE != ""){
            if let dateObj = dateFormattr.date(from: objTask.pLANNEDSTARTDATE){
                let dateFormatterM = DateFormatter()
                dateFormatterM.dateFormat = "dd MMM"
                self.lblPlDate.text = dateFormatterM.string(from: dateObj).uppercased()
            }
        }
        
        if (objTask.tASKENDDATE != ""){
            if let dateObj = dateFormattr.date(from: objTask.tASKENDDATE){
                let dateFormatterM = DateFormatter()
                dateFormatterM.dateFormat = "MMM"
                //self.lblMonth.text = dateFormatterM.string(from: dateObj)
                
                dateFormatterM.dateFormat = "dd MMM"
                self.lblEndDate.text = dateFormatterM.string(from: dateObj).uppercased()
                
            }
            else if let dateObj = dateFormattr2.date(from: objTask.tASKENDDATE){
                let dateFormatterM = DateFormatter()
                dateFormatterM.dateFormat = "MMM"
                //self.lblMonth.text = dateFormatterM.string(from: dateObj)
                
                dateFormatterM.dateFormat = "dd MMM"
                self.lblEndDate.text = dateFormatterM.string(from: dateObj).uppercased()
            }
            else {
//                self.lblMonth.text = ""
//                self.lblDay.text = ""
//                self.lblWeekDay.text = ""
            }
            
        }
        else {
//            self.lblMonth.text = ""
//            self.lblDay.text = ""
//            self.lblWeekDay.text = ""
        }

        //MARK: ICON SIDE AND SHOW
        if objTask.tASKTYPEID == 3 || objTask.tASKTYPEID == 4 {
            self.lblSubTaskCount.text = "1"
            imgSubTaskIcon.image = #imageLiteral(resourceName: "User Story")
            imgSubTaskIcon.backgroundColor = hexStringToUIColor(hex: "#3C5994")
            self.setviewsforsubtask(objTask: objTask)
            //self.lblSubTaskCount.text = "\((objTask.sUBTASK_COUNT))"
        }
        else {
            self.lblSubTaskCount.text = "\((objTask.sUBTASKCOUNT))"
            imgSubTaskIcon.image = #imageLiteral(resourceName: "subtask.png")
            self.setviewsforStory(objTask: objTask)
        }
    }
    
    func setView(objTask : MyTaskModel){
        
        btnDelete.setTitle(String.fontAwesomeIcon(name: .trashO), for: .normal)
        btnClose.setImage(#imageLiteral(resourceName: "close_Icon.png"), for: .normal)
        
        //Set corner radius
        self.setCornerRadius()
        
        if btnViews != nil && imgWorkItemType != nil && imgEllipse != nil {
            btnViews.borderColor = theme_selected_color!
            imgWorkItemType.backgroundColor = theme_selected_color!
            imgEllipse.image = UIImage.fontAwesomeIcon(name: .ellipsisH, textColor: theme_selected_color!, size: CGSize(width: 24, height: 21))
        }
        
        lblUserName.text = ""
        bgView.backgroundColor = UIColor.darkGray
        viewprogress.progressColor = UIColor.darkGray
        lblProjectName.textColor = UIColor.darkGray
        custompProgressBar.barFillColor = UIColor.lightGray
        
        setUserImage(objTask: objTask)
        setcolor(objTask: objTask)
        setTaskTypecolor(objTask: objTask)
        
        if btnTaskStatus != nil {
            if objTask.iSACTIVETASK == 1 {
                btnTaskStatus.setImage(UIImage.fontAwesomeIcon(name: .pauseCircleO, textColor: theme_selected_color!, size: CGSize(width: btnTaskStatus.bounds.width, height: btnTaskStatus.bounds.height)), for: .normal)
                btnTaskStatus.imageView?.contentMode = .scaleAspectFill
            }
            else {
                btnTaskStatus.setImage(UIImage.fontAwesomeIcon(name: .playCircleO, textColor: theme_selected_color!, size: CGSize(width: btnTaskStatus.bounds.width, height: btnTaskStatus.bounds.height)), for: .normal)
                btnTaskStatus.imageView?.contentMode = .scaleAspectFill
            }
        }
        
        self.lblProjectName.text = objTask.pROJECTNAME
        self.lblMilestone.text = objTask.sPRINTNAME
        setTaskName(objTask: objTask)
        setHourAndProgress(objTask: objTask)
        
        self.lblAttchmntCount.text = String(describing: (objTask.attachmentCount))
        self.lblAttchmntCount.adjustsFontSizeToFitWidth = true
        self.lblOwnerPriority.isHidden = true
        self.lblTaskPriority.text = "\((objTask.oWNERPRIORITY))"
        //self.lblOwnerPriority.text = "\((objTask.tASKPRIORITY))"
        self.lblMigratedRiskCount.text = "\((objTask.tASKMITIGATEDRISKCOUNT))"
        self.lblOpenRiskCount.text = "\((objTask.tASKOPENRISKCOUNT))"
        self.lblGeneralNoteCount.text = "\((objTask.tASKNOTESCOUNT))"
        //10
        lblMigratedRiskCount.font = lblMigratedRiskCount.font.withSize(10)
        lblOpenRiskCount.font = lblOpenRiskCount.font.withSize(10)
        lblGeneralNoteCount.font = lblGeneralNoteCount.font.withSize(10)
        lblMigratedRiskCount.adjustsFontSizeToFitWidth = true
        lblOpenRiskCount.adjustsFontSizeToFitWidth = true
        lblGeneralNoteCount.adjustsFontSizeToFitWidth = true
        
        //136 91 45 45 0
        //type attachment priority date
        if objTask.WORKTYPE_CODE_SHORT_FORM != "" && objTask.attachmentCount > 0 && objTask.oWNERPRIORITY > 0 && objTask.tASKENDDATE != "" {
            viewType.isHidden = false
            viewAttachment.isHidden = false
            viewPriority.isHidden = false
            viewDate.isHidden = false
            viewNote.isHidden = true
            
            
            attachmentRightConstraint.constant = 136
            priorityRightConstraint.constant = 91
            noteRightConstraint.constant = 45
            typeRightConstraint.constant = 45
            dateRightConstraint.constant = 0
                       
        }// blank
        else if objTask.WORKTYPE_CODE_SHORT_FORM == "" && objTask.attachmentCount == 0 && objTask.oWNERPRIORITY == 0 && objTask.tASKENDDATE == "" {
            
            if objTask.tASKMITIGATEDRISKCOUNT == 0 && objTask.tASKNOTESCOUNT == 0 && objTask.tASKOPENRISKCOUNT == 0 {
                viewNote.isHidden = true
                noteRightConstraint.constant = 45
            }
            else {
                viewNote.isHidden = false
                noteRightConstraint.constant = 0
            }
            
           viewType.isHidden = true
           viewAttachment.isHidden = true
           viewPriority.isHidden = true
           viewDate.isHidden = true
           
           attachmentRightConstraint.constant = 136
           priorityRightConstraint.constant = 91
           typeRightConstraint.constant = 45
           dateRightConstraint.constant = 0
           
        }//DAte
        else if objTask.WORKTYPE_CODE_SHORT_FORM == "" && objTask.attachmentCount == 0 && objTask.oWNERPRIORITY == 0 && objTask.tASKENDDATE != "" {
            if objTask.tASKMITIGATEDRISKCOUNT > 0 || objTask.tASKNOTESCOUNT > 0 || objTask.tASKOPENRISKCOUNT > 0 {
                //count show
                viewNote.isHidden = false
                noteRightConstraint.constant = 45
            }
            else {
                viewNote.isHidden = true
                noteRightConstraint.constant = 45
                
            }
            
            viewType.isHidden = true
            viewAttachment.isHidden = true
            viewPriority.isHidden = true
            viewDate.isHidden = false
            

            attachmentRightConstraint.constant = 136
            priorityRightConstraint.constant = 91
            typeRightConstraint.constant = 45
            dateRightConstraint.constant = 0
            
        }
        //Type
        else if objTask.WORKTYPE_CODE_SHORT_FORM != "" && objTask.attachmentCount == 0 && objTask.oWNERPRIORITY == 0 && objTask.tASKENDDATE == "" {
            
            viewType.isHidden = false
            viewAttachment.isHidden = true
            viewPriority.isHidden = true
            viewDate.isHidden = true
            viewNote.isHidden = true
            
            
            attachmentRightConstraint.constant = 136
            priorityRightConstraint.constant = 91
            noteRightConstraint.constant = 45
            typeRightConstraint.constant = 0
            dateRightConstraint.constant = 0
        }
                   //Attachment
        else if objTask.WORKTYPE_CODE_SHORT_FORM == "" && objTask.attachmentCount > 0 && objTask.oWNERPRIORITY == 0 && objTask.tASKENDDATE == "" {
            
            if objTask.tASKMITIGATEDRISKCOUNT > 0 || objTask.tASKNOTESCOUNT > 0 || objTask.tASKOPENRISKCOUNT > 0 {
                //count show
                viewNote.isHidden = false
                noteRightConstraint.constant = 0
            }
            else {
                viewNote.isHidden = true
                noteRightConstraint.constant = 45
                
            }
            
            viewType.isHidden = true
            viewAttachment.isHidden = false
            viewPriority.isHidden = true
            viewDate.isHidden = true
            
            if noteRightConstraint.constant == 0 {
                
                attachmentRightConstraint.constant = 45
            }
            else {
                attachmentRightConstraint.constant = 0
            }
            
            priorityRightConstraint.constant = 91
            typeRightConstraint.constant = 0
            dateRightConstraint.constant = 0
            
        }
                   //Priority
        else if objTask.WORKTYPE_CODE_SHORT_FORM == "" && objTask.attachmentCount == 0 && objTask.oWNERPRIORITY > 0 && objTask.tASKENDDATE == "" {
            
            if objTask.tASKMITIGATEDRISKCOUNT > 0 || objTask.tASKNOTESCOUNT > 0 || objTask.tASKOPENRISKCOUNT > 0 {
                //count show
                viewNote.isHidden = false
                noteRightConstraint.constant = 0
            }
            else {
                viewNote.isHidden = true
                noteRightConstraint.constant = 45
                
            }
                
            viewType.isHidden = true
            viewAttachment.isHidden = true
            viewPriority.isHidden = false
            viewDate.isHidden = true
            
            if noteRightConstraint.constant == 0 {
                
                priorityRightConstraint.constant = 45
            }
            else {
                priorityRightConstraint.constant = 0
            }
            
            attachmentRightConstraint.constant = 45
            typeRightConstraint.constant = 0
            dateRightConstraint.constant = 0
                
        }
                       
        //---------
        //date priority
        else if objTask.WORKTYPE_CODE_SHORT_FORM == "" && objTask.attachmentCount == 0 && objTask.oWNERPRIORITY > 0 && objTask.tASKENDDATE != "" {
            
            
            if objTask.tASKMITIGATEDRISKCOUNT > 0 || objTask.tASKNOTESCOUNT > 0 || objTask.tASKOPENRISKCOUNT > 0 {
                //count show
                viewNote.isHidden = false
                noteRightConstraint.constant = 45
            }
            else {
                viewNote.isHidden = true
                noteRightConstraint.constant = 0
                
            }
                
            viewType.isHidden = true
            viewAttachment.isHidden = true
            viewPriority.isHidden = false
            viewDate.isHidden = false
            
            if noteRightConstraint.constant == 45 {
                
                priorityRightConstraint.constant = 91
            }
            else {
                priorityRightConstraint.constant = 45
            }
            
            attachmentRightConstraint.constant = 45
            typeRightConstraint.constant = 0
            dateRightConstraint.constant = 0
            
        }
        
        //date Attachment
        else if objTask.WORKTYPE_CODE_SHORT_FORM == "" && objTask.attachmentCount > 0 && objTask.oWNERPRIORITY == 0 && objTask.tASKENDDATE != "" {
            
            if objTask.tASKMITIGATEDRISKCOUNT > 0 || objTask.tASKNOTESCOUNT > 0 || objTask.tASKOPENRISKCOUNT > 0 {
                //count show
                viewNote.isHidden = false
                noteRightConstraint.constant = 45
            }
            else {
                viewNote.isHidden = true
                noteRightConstraint.constant = 0
                
            }
                
            viewType.isHidden = true
            viewAttachment.isHidden = false
            viewPriority.isHidden = true
            viewDate.isHidden = false
            
            if noteRightConstraint.constant == 45 {
                
                attachmentRightConstraint.constant = 91
            }
            else {
                attachmentRightConstraint.constant = 45
            }
            
            priorityRightConstraint.constant = 45
            typeRightConstraint.constant = 0
            dateRightConstraint.constant = 0
            
        }
        //date type
        else if objTask.WORKTYPE_CODE_SHORT_FORM != "" && objTask.attachmentCount == 0 && objTask.oWNERPRIORITY == 0 && objTask.tASKENDDATE != "" {
            
            //hide count view
            
            viewType.isHidden = false
            viewAttachment.isHidden = true
            viewPriority.isHidden = true
            viewDate.isHidden = false
            viewNote.isHidden = true
            
            
            attachmentRightConstraint.constant = 136
            priorityRightConstraint.constant = 91
            noteRightConstraint.constant = 45
            typeRightConstraint.constant = 45
            dateRightConstraint.constant = 0
            
        }
            //priority attachmnet
        else if objTask.WORKTYPE_CODE_SHORT_FORM == "" && objTask.attachmentCount > 0 && objTask.oWNERPRIORITY > 0 && objTask.tASKENDDATE == "" {
            
            if objTask.tASKMITIGATEDRISKCOUNT > 0 || objTask.tASKNOTESCOUNT > 0 || objTask.tASKOPENRISKCOUNT > 0 {
                //count show
                viewNote.isHidden = false
                noteRightConstraint.constant = 0
            }
            else {
                viewNote.isHidden = true
                noteRightConstraint.constant = 45
                
            }
                
            viewType.isHidden = true
            viewAttachment.isHidden = false
            viewPriority.isHidden = false
            viewDate.isHidden = true
            
            if noteRightConstraint.constant == 0 {
                priorityRightConstraint.constant = 45
                attachmentRightConstraint.constant = 91
            }
            else {
                priorityRightConstraint.constant = 0
                attachmentRightConstraint.constant = 45
            }
            typeRightConstraint.constant = 0
            dateRightConstraint.constant = 0
            
        }
                   //priority type
        else if objTask.WORKTYPE_CODE_SHORT_FORM != "" && objTask.attachmentCount == 0 && objTask.oWNERPRIORITY > 0 && objTask.tASKENDDATE == "" {
            
            viewType.isHidden = false
            viewAttachment.isHidden = true
            viewPriority.isHidden = false
            viewDate.isHidden = true
            viewNote.isHidden = true
            
            
            attachmentRightConstraint.constant = 136
            priorityRightConstraint.constant = 45
            noteRightConstraint.constant = 45
            typeRightConstraint.constant = 0
            dateRightConstraint.constant = 0
                       
        }
            //attachment Type
        else if objTask.WORKTYPE_CODE_SHORT_FORM != "" && objTask.attachmentCount > 0 && objTask.oWNERPRIORITY == 0 && objTask.tASKENDDATE == "" {
            viewType.isHidden = false
            viewAttachment.isHidden = false
            viewPriority.isHidden = true
            viewDate.isHidden = true
            viewNote.isHidden = true
            
            
            attachmentRightConstraint.constant = 45
            priorityRightConstraint.constant = 45
            noteRightConstraint.constant = 45
            typeRightConstraint.constant = 0
            dateRightConstraint.constant = 0
            
        }
                   //-----
        //date TYPE attachmnet 3
        else if objTask.WORKTYPE_CODE_SHORT_FORM != "" && objTask.attachmentCount > 0 && objTask.oWNERPRIORITY == 0 && objTask.tASKENDDATE != "" {
            
            viewType.isHidden = false
            viewAttachment.isHidden = false
            viewPriority.isHidden = true
            viewDate.isHidden = false
            viewNote.isHidden = true
            
            
            attachmentRightConstraint.constant = 91
            priorityRightConstraint.constant = 45
            noteRightConstraint.constant = 45
            typeRightConstraint.constant = 45
            dateRightConstraint.constant = 0
            
        }
        //priority attachmnet TYPE
        else if objTask.WORKTYPE_CODE_SHORT_FORM != "" && objTask.attachmentCount > 0 && objTask.oWNERPRIORITY > 0 && objTask.tASKENDDATE == "" {
            
            viewType.isHidden = false
            viewAttachment.isHidden = false
            viewPriority.isHidden = false
            viewDate.isHidden = true
            viewNote.isHidden = true
            
            
            attachmentRightConstraint.constant = 91
            priorityRightConstraint.constant = 45
            noteRightConstraint.constant = 45
            typeRightConstraint.constant = 0
            dateRightConstraint.constant = 0
            
        }
        //priority TYPE date
        else if objTask.WORKTYPE_CODE_SHORT_FORM != "" && objTask.attachmentCount == 0 && objTask.oWNERPRIORITY > 0 && objTask.tASKENDDATE != "" {
            viewType.isHidden = false
            viewAttachment.isHidden = true
            viewPriority.isHidden = false
            viewDate.isHidden = false
            viewNote.isHidden = true
            
            
            attachmentRightConstraint.constant = 91
            priorityRightConstraint.constant = 91
            noteRightConstraint.constant = 45
            typeRightConstraint.constant = 45
            dateRightConstraint.constant = 0
            
        }
        //attachment date prority 1
        else if objTask.WORKTYPE_CODE_SHORT_FORM == "" && objTask.attachmentCount > 0 && objTask.oWNERPRIORITY > 0 && objTask.tASKENDDATE != "" {
            if objTask.tASKMITIGATEDRISKCOUNT > 0 || objTask.tASKNOTESCOUNT > 0 || objTask.tASKOPENRISKCOUNT > 0 {
                //count show
                viewNote.isHidden = false
                noteRightConstraint.constant = 45
            }
            else {
                viewNote.isHidden = true
                noteRightConstraint.constant = 0
                
            }
                
            viewType.isHidden = true
            viewAttachment.isHidden = false
            viewPriority.isHidden = false
            viewDate.isHidden = false
            
            if noteRightConstraint.constant == 45 {
                priorityRightConstraint.constant = 91
                attachmentRightConstraint.constant = 136
            }
            else {
                priorityRightConstraint.constant = 45
                attachmentRightConstraint.constant = 91
            }
            typeRightConstraint.constant = 0
            dateRightConstraint.constant = 0
            
        }
        
        let dateFormattr = DateFormatter()
        dateFormattr.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        let dateFormattr2 = DateFormatter()
        dateFormattr2.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
        
        if (objTask.tASKENDDATE != ""){
            if let dateObj = dateFormattr.date(from: objTask.tASKENDDATE){
                let dateFormatterM = DateFormatter()
                dateFormatterM.dateFormat = "MMM"
                self.lblMonth.text = dateFormatterM.string(from: dateObj)
                
                let dateFormatterM1 = DateFormatter()
                dateFormatterM1.dateFormat = "dd"
                self.lblDay.text = dateFormatterM1.string(from: dateObj)
                
                let dateFormatterM2 = DateFormatter()
                dateFormatterM2.dateFormat = "EEE"
                self.lblWeekDay.text = dateFormatterM2.string(from: dateObj)
            }
            else if let dateObj = dateFormattr2.date(from: objTask.tASKENDDATE){
                let dateFormatterM = DateFormatter()
                dateFormatterM.dateFormat = "MMM"
                self.lblMonth.text = dateFormatterM.string(from: dateObj)
                
                let dateFormatterM1 = DateFormatter()
                dateFormatterM1.dateFormat = "dd"
                self.lblDay.text = dateFormatterM1.string(from: dateObj)
                
                let dateFormatterM2 = DateFormatter()
                dateFormatterM2.dateFormat = "EEE"
                self.lblWeekDay.text = dateFormatterM2.string(from: dateObj)
            }
            else {
                self.lblMonth.text = ""
                self.lblDay.text = ""
                self.lblWeekDay.text = ""
            }
            //8
            lblMonth.font = lblMigratedRiskCount.font.withSize(8)
            lblDay.font = lblOpenRiskCount.font.withSize(8)
            lblWeekDay.font = lblGeneralNoteCount.font.withSize(8)
            lblMonth.adjustsFontSizeToFitWidth = true
            lblDay.adjustsFontSizeToFitWidth = true
            lblWeekDay.adjustsFontSizeToFitWidth = true
        }
        else {
            self.lblMonth.text = ""
            self.lblDay.text = ""
            self.lblWeekDay.text = ""
        }
    }
    func setNewView(objTask : MyTaskModel){
        
        btnDelete.setTitle(String.fontAwesomeIcon(name: .trashO), for: .normal)
        btnClose.setImage(#imageLiteral(resourceName: "close_Icon.png"), for: .normal)
        
        //Set corner radius
        self.setCornerRadius()
        
        if btnViews != nil && imgWorkItemType != nil && imgEllipse != nil {
            btnViews.borderColor = theme_selected_color!
            if (objTask.pROJECT_COLOR_CODE != ""){
                btnViews.borderColor = hexStringToUIColor(hex: objTask.pROJECT_COLOR_CODE)
                imgEllipse.image = UIImage.fontAwesomeIcon(name: .ellipsisH, textColor: hexStringToUIColor(hex: objTask.pROJECT_COLOR_CODE), size: CGSize(width: 24, height: 21))
            }
            else {
                imgEllipse.image = UIImage.fontAwesomeIcon(name: .ellipsisH, textColor: .darkGray, size: CGSize(width: 24, height: 21))
                btnViews.borderColor = .darkGray
            }
            
            
            if objTask.tASK_TYPE_ID == 1 {
                if (objTask.pROJECT_COLOR_CODE != ""){
                    imgWorkItemType.backgroundColor = hexStringToUIColor(hex: objTask.pROJECT_COLOR_CODE)
                }
                else {
                    imgWorkItemType.backgroundColor = .darkGray
                }
                imgWorkItemType.image = #imageLiteral(resourceName: "Task48x48.png")
            }
            else if objTask.tASK_TYPE_ID == 2 {
                
                if (objTask.pROJECT_COLOR_CODE != ""){
                    imgWorkItemType.backgroundColor = hexStringToUIColor(hex: objTask.pROJECT_COLOR_CODE)
                }
                else {
                    imgWorkItemType.backgroundColor = .darkGray
                }
                
                imgWorkItemType.image = #imageLiteral(resourceName: "Activity48x48.png")
            }
            else if objTask.tASK_TYPE_ID == 3 {
                imgWorkItemType.backgroundColor = .clear
                imgWorkItemType.image = UIImage.fontAwesomeIcon(name: .bug, textColor: .red, size: CGSize(width: imgWorkItemType.bounds.width, height: imgWorkItemType.bounds.height))
                
            }
                
            else if objTask.tASK_TYPE_ID == 4 {
                if (objTask.pROJECT_COLOR_CODE != ""){
                    imgWorkItemType.backgroundColor = hexStringToUIColor(hex: objTask.pROJECT_COLOR_CODE)
                }
                else {
                    imgWorkItemType.backgroundColor = .darkGray
                }
                imgWorkItemType.image = #imageLiteral(resourceName: "subtask  48.png")
            }
        }
        
        
        lblUserName.text = ""
        bgView.backgroundColor = UIColor.darkGray
        viewprogress.progressColor = UIColor.darkGray
        lblProjectName.textColor = UIColor.darkGray
        custompProgressBar.barFillColor = UIColor.lightGray
        
        setUserImage(objTask: objTask)
        setcolor(objTask: objTask)
        setTaskTypecolor(objTask: objTask)
        
        if btnTaskStatus != nil {
            if objTask.iSACTIVETASK == 1 {
                btnTaskStatus.setImage(UIImage.fontAwesomeIcon(name: .pauseCircleO, textColor: theme_selected_color!, size: CGSize(width: btnTaskStatus.bounds.width, height: btnTaskStatus.bounds.height)), for: .normal)
                btnTaskStatus.imageView?.contentMode = .scaleAspectFill
            }
            else {
                btnTaskStatus.setImage(UIImage.fontAwesomeIcon(name: .playCircleO, textColor: theme_selected_color!, size: CGSize(width: btnTaskStatus.bounds.width, height: btnTaskStatus.bounds.height)), for: .normal)
                btnTaskStatus.imageView?.contentMode = .scaleAspectFill
            }
        }
        
        self.lblProjectName.text = objTask.pROJECTNAME
        self.lblMilestone.text = objTask.sPRINTNAME
        setTaskName(objTask: objTask)
        setHourAndProgress(objTask: objTask)
        
        self.lblAttchmntCount.text = String(describing: (objTask.attachmentCount))
        self.lblAttchmntCount.adjustsFontSizeToFitWidth = true
        //self.lblOwnerPriority.isHidden = true
        self.lblTaskPriority.text = "\((objTask.oWNERPRIORITY))"
        //self.lblOwnerPriority.text = "\((objTask.tASKPRIORITY))"
        
        self.imgRoadBlockIcon.image = #imageLiteral(resourceName: "road block.png")
        self.lblRoadBlock.text = "\((objTask.rOADBLOCK_COUNT))"
        
        self.lblBugCount.text = "\((objTask.bUG_COUNT))"
        
        lblNoteTypeCount.textColor = .white
        if objTask.tASKOPENRISKCOUNT > 0 {
            lblNoteTypeCount.backgroundColor = .red
        }
        else {
            lblNoteTypeCount.backgroundColor = theme_orange_color
        }
        
        var avTypeNote = 0
        
        
        lblNoteTotalCount.text = "\((objTask.tASK_NOTE_TOTAL_COUNT))"
        
        if objTask.tASKMITIGATEDRISKCOUNT > 0 {
            avTypeNote += 1
        }
        if objTask.tASKOPENRISKCOUNT > 0 {
            avTypeNote += 1
        }
        if objTask.tASKNOTESCOUNT > 0 {
            avTypeNote += 1
        }
        
        lblNoteTypeCount.text = "\(String(describing: avTypeNote))"
        
//        self.lblMigratedRiskCount.text = "\((objTask.tASKMITIGATEDRISKCOUNT))"
//        self.lblOpenRiskCount.text = "\((objTask.tASKOPENRISKCOUNT))"
//        self.lblGeneralNoteCount.text = "\((objTask.tASKNOTESCOUNT))"
        
//        lblMigratedRiskCount.font = lblMigratedRiskCount.font.withSize(10)
//        lblOpenRiskCount.font = lblOpenRiskCount.font.withSize(10)
//        lblGeneralNoteCount.font = lblGeneralNoteCount.font.withSize(10)
//        lblMigratedRiskCount.adjustsFontSizeToFitWidth = true
//        lblOpenRiskCount.adjustsFontSizeToFitWidth = true
//        lblGeneralNoteCount.adjustsFontSizeToFitWidth = true
        
        
        let dateFormattr = DateFormatter()
        dateFormattr.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        let dateFormattr2 = DateFormatter()
        dateFormattr2.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
        
        self.lblPlDate.text = "-"
        self.lblEndDate.text = "-"
        
        if (objTask.pLANNED_START_DATE != ""){
            if let dateObj = dateFormattr.date(from: objTask.pLANNED_START_DATE){
                let dateFormatterM = DateFormatter()
                dateFormatterM.dateFormat = "dd MMM"
                self.lblPlDate.text = dateFormatterM.string(from: dateObj).uppercased()
            }
        }
        
        if (objTask.tASKENDDATE != ""){
            if let dateObj = dateFormattr.date(from: objTask.tASKENDDATE){
                let dateFormatterM = DateFormatter()
                dateFormatterM.dateFormat = "MMM"
                //self.lblMonth.text = dateFormatterM.string(from: dateObj)
                
                dateFormatterM.dateFormat = "dd MMM"
                self.lblEndDate.text = dateFormatterM.string(from: dateObj).uppercased()
                
            }
            else if let dateObj = dateFormattr2.date(from: objTask.tASKENDDATE){
                let dateFormatterM = DateFormatter()
                dateFormatterM.dateFormat = "MMM"
                //self.lblMonth.text = dateFormatterM.string(from: dateObj)
                
                dateFormatterM.dateFormat = "dd MMM"
                self.lblEndDate.text = dateFormatterM.string(from: dateObj).uppercased()
            }
        }
           
        //MARK: ICON SIDE AND SHOW
        if objTask.tASK_TYPE_ID == 3 || objTask.tASK_TYPE_ID == 4 {
            self.lblSubTaskCount.text = "1"
            imgSubTaskIcon.image = #imageLiteral(resourceName: "User Story")
            imgSubTaskIcon.backgroundColor = hexStringToUIColor(hex: "#3C5994")
            self.setviewsforsubtask(objTask: objTask)
            //self.lblSubTaskCount.text = "\((objTask.sUBTASK_COUNT))"
        }
        else {
            self.lblSubTaskCount.text = "\((objTask.sUBTASK_COUNT))"
            imgSubTaskIcon.image = #imageLiteral(resourceName: "subtask.png")
            self.setviewsforStory(objTask: objTask)
        }
    }
    
    func setviewsforStory(objTask : MyTaskModel) {

         //MARK: 240 193 146 99 52 3
        var dt = 0
        if objTask.pLANNED_START_DATE != "" || objTask.tASKENDDATE != "" {
            dt = 1
        }
         //attachment
         if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 3
             roadblockRightConstraint.constant = 141
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 0
             BugRightConstraint.constant = 0
         }
         
         //rollback
         else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
         {
             viewAttachment.isHidden = true
             viewroadblock.isHidden = false
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 3
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
         
         //notes
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
             && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
         {
             
             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = false
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 3
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
                        
         }
         
         //subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
         {
             

             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = false
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 3
             BugRightConstraint.constant = 0
         }
          //bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
             
         {
             
             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = false
             viewDate.isHidden = true
            
             dateRightConstraint.constant = 3
             prioritygRightConstraint.constant = 235
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 3
         }
            
        //Date
        
        if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewDate.isHidden = false
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            
            attachRightConstraint.constant = 188
            roadblockRightConstraint.constant = 141
            notecountRightConstraint.constant = 94
            subtaskRightConstraint.constant = 47
            BugRightConstraint.constant = 0
            dateRightConstraint.constant = 3
                       
        }
        //roadblock attachment
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 52
             roadblockRightConstraint.constant = 3
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
                        
         }
         
         //note attachment
         else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
              && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
          {
              
              viewAttachment.isHidden = false
              viewroadblock.isHidden = true
              viewNote.isHidden = false
              viewSubtask.isHidden = true
              viewBug.isHidden = true
              viewDate.isHidden = true
            
              dateRightConstraint.constant = 3
              attachRightConstraint.constant = 52
              roadblockRightConstraint.constant = 3
              notecountRightConstraint.constant = 3
              subtaskRightConstraint.constant = 47
              BugRightConstraint.constant = 0
                         
          }
         
        // attachment subtask
          else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
               && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
           {
               
               viewAttachment.isHidden = false
               viewroadblock.isHidden = true
               viewNote.isHidden = true
               viewSubtask.isHidden = false
               viewBug.isHidden = true
               viewDate.isHidden = true
             
               dateRightConstraint.constant = 3
               attachRightConstraint.constant = 52
               roadblockRightConstraint.constant = 3
               notecountRightConstraint.constant = 3
               subtaskRightConstraint.constant = 3
               BugRightConstraint.constant = 0
                          
           }
            
        //attachment bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = false
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 52
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 0
             BugRightConstraint.constant = 3
                        
         }
         
        //attachment date
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = false
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 52
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
         
        //rollback notes
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 47
            BugRightConstraint.constant = 0
        }
        //rollback subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
        //rollback bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
            
        // rollback calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
            
        // notes subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
        
        // notes bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
        //notes calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
         // subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
            
        //subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
            
        //bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 52
        }
        //attachment rollback note
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
             && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
         {
             viewAttachment.isHidden = false
             viewroadblock.isHidden = false
             viewNote.isHidden = false
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 99
             roadblockRightConstraint.constant = 52
             notecountRightConstraint.constant = 3
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
        //attachment rollback subtask

        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         
         //attachment rollback bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         //attachment rollback calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         //attachment notes subtask
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         
         //attachment notes bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         
         //attachment notes calendar
         else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
             && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
         {
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = false
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = false
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 99
             roadblockRightConstraint.constant = 52
             notecountRightConstraint.constant = 52
             subtaskRightConstraint.constant = 3
             BugRightConstraint.constant = 0
         }
         //attachment subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
         //attachment subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
          //attachment bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
         {
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = false
             viewDate.isHidden = false
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 99
             roadblockRightConstraint.constant = 52
             notecountRightConstraint.constant = 52
             subtaskRightConstraint.constant = 52
             BugRightConstraint.constant = 52
         }
         
          //rollback notes subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 52
        }
         
         //rollback notes bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
         //rollback notes calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
        
         //rollback subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
         //rollback subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
        //rollback bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 52
        }
        
        //notes subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
         //notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
        //notes bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        //subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 99
            BugRightConstraint.constant = 52
        }
        
         // attachment rollback notes subtask
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 146
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 52
        }
        //attachment rollback notes bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 3
           BugRightConstraint.constant = 3
        }
        //attachment rollback bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
                   && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 3
           BugRightConstraint.constant = 52
        }
        
         //attachment rollback notes calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 3
           BugRightConstraint.constant = 52
        }
            
         //attachment rollback subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
                   && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
         //attachment rollback subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
                   && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
        
         //attachment notes subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
        
        //attachment notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
         //attachment notes bug calendar
            
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
            
        //rollback notes subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
         
        //rollback notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
            
        //rollback note bug calendar
            
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
            
        //notes subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
            
        // attachment rollback notes subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
      
        // attachment rollback notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
         //attachment rollback notes bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT == 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
            
        //attachment notes subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
        
        //rollback notes subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 193
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
            
        // attachment rollback notes subtask bug calendar all greater
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 240
           roadblockRightConstraint.constant = 193
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
        
        //priority attachment rollback notes subtask bug all zero
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.sUBTASK_COUNT != 0 && objTask.bUG_COUNT != 0 )
         {
             viewDate.isHidden = true
             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             
             dateRightConstraint.constant = 235
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
    }
    
    func setviewsforsubtask(objTask : MyTaskModel) {

         //MARK: 240 193 146 99 52 3
        var dt = 0
        if objTask.pLANNED_START_DATE != "" || objTask.tASKENDDATE != "" {
            dt = 1
        }
         //attachment
         if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 3
             roadblockRightConstraint.constant = 141
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 0
             BugRightConstraint.constant = 0
         }
         
         //rollback
         else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
         {
             viewAttachment.isHidden = true
             viewroadblock.isHidden = false
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 3
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
         
         //notes
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
             && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
         {
             
             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = false
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 3
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
                        
         }
         
         //subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
         {
             

             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = false
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 3
             BugRightConstraint.constant = 0
         }
          //bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
             
         {
             
             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = false
             viewDate.isHidden = true
            
             dateRightConstraint.constant = 3
             prioritygRightConstraint.constant = 235
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 3
         }
            
        //Date
        
        if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewDate.isHidden = false
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            
            attachRightConstraint.constant = 188
            roadblockRightConstraint.constant = 141
            notecountRightConstraint.constant = 94
            subtaskRightConstraint.constant = 47
            BugRightConstraint.constant = 0
            dateRightConstraint.constant = 3
                       
        }
        //roadblock attachment
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 52
             roadblockRightConstraint.constant = 3
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
                        
         }
         
         //note attachment
         else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
              && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
          {
              
              viewAttachment.isHidden = false
              viewroadblock.isHidden = true
              viewNote.isHidden = false
              viewSubtask.isHidden = true
              viewBug.isHidden = true
              viewDate.isHidden = true
            
              dateRightConstraint.constant = 3
              attachRightConstraint.constant = 52
              roadblockRightConstraint.constant = 3
              notecountRightConstraint.constant = 3
              subtaskRightConstraint.constant = 47
              BugRightConstraint.constant = 0
                         
          }
         
        // attachment subtask
          else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
               && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
           {
               
               viewAttachment.isHidden = false
               viewroadblock.isHidden = true
               viewNote.isHidden = true
               viewSubtask.isHidden = false
               viewBug.isHidden = true
               viewDate.isHidden = true
             
               dateRightConstraint.constant = 3
               attachRightConstraint.constant = 52
               roadblockRightConstraint.constant = 3
               notecountRightConstraint.constant = 3
               subtaskRightConstraint.constant = 3
               BugRightConstraint.constant = 0
                          
           }
            
        //attachment bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = false
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 52
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 0
             BugRightConstraint.constant = 3
                        
         }
         
        //attachment date
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = false
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 52
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
         
        //rollback notes
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 47
            BugRightConstraint.constant = 0
        }
        //rollback subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
        //rollback bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
            
        // rollback calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
            
        // notes subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
        
        // notes bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
        //notes calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
         // subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
            
        //subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
            
        //bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 52
        }
        //attachment rollback note
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
             && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
         {
             viewAttachment.isHidden = false
             viewroadblock.isHidden = false
             viewNote.isHidden = false
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 99
             roadblockRightConstraint.constant = 52
             notecountRightConstraint.constant = 3
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
        //attachment rollback subtask

        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         
         //attachment rollback bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         //attachment rollback calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         //attachment notes subtask
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         
         //attachment notes bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         
         //attachment notes calendar
         else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
             && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
         {
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = false
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = false
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 99
             roadblockRightConstraint.constant = 52
             notecountRightConstraint.constant = 52
             subtaskRightConstraint.constant = 3
             BugRightConstraint.constant = 0
         }
         //attachment subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
         //attachment subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
          //attachment bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
             && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
         {
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = false
             viewDate.isHidden = false
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 99
             roadblockRightConstraint.constant = 52
             notecountRightConstraint.constant = 52
             subtaskRightConstraint.constant = 52
             BugRightConstraint.constant = 52
         }
         
          //rollback notes subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 52
        }
         
         //rollback notes bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
         //rollback notes calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
        
         //rollback subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
         //rollback subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
        //rollback bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 52
        }
        
        //notes subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
         //notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
        //notes bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        //subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 99
            BugRightConstraint.constant = 52
        }
        
         // attachment rollback notes subtask
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 146
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 52
        }
        //attachment rollback notes bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 3
           BugRightConstraint.constant = 3
        }
        //attachment rollback bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
                   && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 3
           BugRightConstraint.constant = 52
        }
        
         //attachment rollback notes calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 3
           BugRightConstraint.constant = 52
        }
            
         //attachment rollback subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
                   && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
         //attachment rollback subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT == 0
                   && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
        
         //attachment notes subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
        
        //attachment notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
         //attachment notes bug calendar
            
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
            
        //rollback notes subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
         
        //rollback notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
            
        //rollback note bug calendar
            
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
            
        //notes subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
            
        // attachment rollback notes subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
      
        // attachment rollback notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
         //attachment rollback notes bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
            
        //attachment notes subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT == 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID == 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
        
        //rollback notes subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 193
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
            
        // attachment rollback notes subtask bug calendar all greater
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
                   && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 240
           roadblockRightConstraint.constant = 193
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
        
        //priority attachment rollback notes subtask bug all zero
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCK_COUNT != 0 && objTask.tASK_NOTE_TOTAL_COUNT != 0
            && objTask.pARENT_TASK_ID != 0 && objTask.bUG_COUNT != 0 )
         {
             viewDate.isHidden = true
             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             
             dateRightConstraint.constant = 235
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
    }
    
    //---
    func setviewsforStory(objTask : SearchTaskModel) {

         //MARK: 240 193 146 99 52 3
        var dt = 0
        if objTask.pLANNEDSTARTDATE != "" || objTask.tASKENDDATE != "" {
            dt = 1
        }
         //attachment
         if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 3
             roadblockRightConstraint.constant = 141
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 0
             BugRightConstraint.constant = 0
         }
         
         //rollback
         else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
         {
             viewAttachment.isHidden = true
             viewroadblock.isHidden = false
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 3
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
         
         //notes
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
             && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
         {
             
             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = false
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 3
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
                        
         }
         
         //subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
         {
             

             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = false
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 3
             BugRightConstraint.constant = 0
         }
          //bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
             
         {
             
             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = false
             viewDate.isHidden = true
            
             dateRightConstraint.constant = 3
             prioritygRightConstraint.constant = 235
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 3
         }
            
        //Date
        
        if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewDate.isHidden = false
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            
            attachRightConstraint.constant = 188
            roadblockRightConstraint.constant = 141
            notecountRightConstraint.constant = 94
            subtaskRightConstraint.constant = 47
            BugRightConstraint.constant = 0
            dateRightConstraint.constant = 3
                       
        }
        //roadblock attachment
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 52
             roadblockRightConstraint.constant = 3
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
                        
         }
         
         //note attachment
         else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
              && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
          {
              
              viewAttachment.isHidden = false
              viewroadblock.isHidden = true
              viewNote.isHidden = false
              viewSubtask.isHidden = true
              viewBug.isHidden = true
              viewDate.isHidden = true
            
              dateRightConstraint.constant = 3
              attachRightConstraint.constant = 52
              roadblockRightConstraint.constant = 3
              notecountRightConstraint.constant = 3
              subtaskRightConstraint.constant = 47
              BugRightConstraint.constant = 0
                         
          }
         
        // attachment subtask
          else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
               && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
           {
               
               viewAttachment.isHidden = false
               viewroadblock.isHidden = true
               viewNote.isHidden = true
               viewSubtask.isHidden = false
               viewBug.isHidden = true
               viewDate.isHidden = true
             
               dateRightConstraint.constant = 3
               attachRightConstraint.constant = 52
               roadblockRightConstraint.constant = 3
               notecountRightConstraint.constant = 3
               subtaskRightConstraint.constant = 3
               BugRightConstraint.constant = 0
                          
           }
            
        //attachment bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = false
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 52
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 0
             BugRightConstraint.constant = 3
                        
         }
         
        //attachment date
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = false
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 52
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
         
        //rollback notes
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 47
            BugRightConstraint.constant = 0
        }
        //rollback subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
        //rollback bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
            
        // rollback calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
            
        // notes subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
        
        // notes bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
        //notes calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
         // subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
            
        //subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
            
        //bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 52
        }
        //attachment rollback note
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
             && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
         {
             viewAttachment.isHidden = false
             viewroadblock.isHidden = false
             viewNote.isHidden = false
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 99
             roadblockRightConstraint.constant = 52
             notecountRightConstraint.constant = 3
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
        //attachment rollback subtask

        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         
         //attachment rollback bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         //attachment rollback calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         //attachment notes subtask
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         
         //attachment notes bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         
         //attachment notes calendar
         else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
             && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
         {
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = false
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = false
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 99
             roadblockRightConstraint.constant = 52
             notecountRightConstraint.constant = 52
             subtaskRightConstraint.constant = 3
             BugRightConstraint.constant = 0
         }
         //attachment subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
         //attachment subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
          //attachment bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
         {
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = false
             viewDate.isHidden = false
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 99
             roadblockRightConstraint.constant = 52
             notecountRightConstraint.constant = 52
             subtaskRightConstraint.constant = 52
             BugRightConstraint.constant = 52
         }
         
          //rollback notes subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 52
        }
         
         //rollback notes bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
         //rollback notes calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
        
         //rollback subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
         //rollback subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
        //rollback bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 52
        }
        
        //notes subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
         //notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
        //notes bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        //subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 99
            BugRightConstraint.constant = 52
        }
        
         // attachment rollback notes subtask
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 146
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 52
        }
        //attachment rollback notes bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 3
           BugRightConstraint.constant = 3
        }
        //attachment rollback bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
                   && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 3
           BugRightConstraint.constant = 52
        }
        
         //attachment rollback notes calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 3
           BugRightConstraint.constant = 52
        }
            
         //attachment rollback subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
                   && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
         //attachment rollback subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
                   && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
        
         //attachment notes subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
        
        //attachment notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
         //attachment notes bug calendar
            
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
            
        //rollback notes subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
         
        //rollback notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
            
        //rollback note bug calendar
            
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
            
        //notes subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
            
        // attachment rollback notes subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
      
        // attachment rollback notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
         //attachment rollback notes bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
            
        //attachment notes subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT == 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
        
        //rollback notes subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 193
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
            
        // attachment rollback notes subtask bug calendar all greater
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 240
           roadblockRightConstraint.constant = 193
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
        
        //priority attachment rollback notes subtask bug all zero
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.sUBTASKCOUNT != 0 && objTask.bUGCOUNT != 0 )
         {
             viewDate.isHidden = true
             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             
             dateRightConstraint.constant = 235
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
    }
    
    func setviewsforsubtask(objTask : SearchTaskModel) {

         //MARK: 240 193 146 99 52 3
        var dt = 0
        if objTask.pLANNEDSTARTDATE != "" || objTask.tASKENDDATE != "" {
            dt = 1
        }
         //attachment
         if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 3
             roadblockRightConstraint.constant = 141
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 0
             BugRightConstraint.constant = 0
         }
         
         //rollback
         else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
         {
             viewAttachment.isHidden = true
             viewroadblock.isHidden = false
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 3
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
         
         //notes
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
             && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
         {
             
             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = false
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 3
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
                        
         }
         
         //subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
         {
             

             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = false
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 3
             BugRightConstraint.constant = 0
         }
          //bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
             
         {
             
             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = false
             viewDate.isHidden = true
            
             dateRightConstraint.constant = 3
             prioritygRightConstraint.constant = 235
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 3
         }
            
        //Date
        
        if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewDate.isHidden = false
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            
            attachRightConstraint.constant = 188
            roadblockRightConstraint.constant = 141
            notecountRightConstraint.constant = 94
            subtaskRightConstraint.constant = 47
            BugRightConstraint.constant = 0
            dateRightConstraint.constant = 3
                       
        }
        //roadblock attachment
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 52
             roadblockRightConstraint.constant = 3
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
                        
         }
         
         //note attachment
         else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
              && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
          {
              
              viewAttachment.isHidden = false
              viewroadblock.isHidden = true
              viewNote.isHidden = false
              viewSubtask.isHidden = true
              viewBug.isHidden = true
              viewDate.isHidden = true
            
              dateRightConstraint.constant = 3
              attachRightConstraint.constant = 52
              roadblockRightConstraint.constant = 3
              notecountRightConstraint.constant = 3
              subtaskRightConstraint.constant = 47
              BugRightConstraint.constant = 0
                         
          }
         
        // attachment subtask
          else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
               && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
           {
               
               viewAttachment.isHidden = false
               viewroadblock.isHidden = true
               viewNote.isHidden = true
               viewSubtask.isHidden = false
               viewBug.isHidden = true
               viewDate.isHidden = true
             
               dateRightConstraint.constant = 3
               attachRightConstraint.constant = 52
               roadblockRightConstraint.constant = 3
               notecountRightConstraint.constant = 3
               subtaskRightConstraint.constant = 3
               BugRightConstraint.constant = 0
                          
           }
            
        //attachment bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = false
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 52
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 0
             BugRightConstraint.constant = 3
                        
         }
         
        //attachment date
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
         {
             
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = false
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 52
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
         
        //rollback notes
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 47
            BugRightConstraint.constant = 0
        }
        //rollback subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
        //rollback bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
            
        // rollback calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
            
        // notes subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
        
        // notes bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
        //notes calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
         // subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
            
        //subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
            
        //bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
        {
            
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 52
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 52
        }
        //attachment rollback note
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
             && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
         {
             viewAttachment.isHidden = false
             viewroadblock.isHidden = false
             viewNote.isHidden = false
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = true
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 99
             roadblockRightConstraint.constant = 52
             notecountRightConstraint.constant = 3
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
        //attachment rollback subtask

        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         
         //attachment rollback bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         //attachment rollback calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 3
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         //attachment notes subtask
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         
         //attachment notes bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 0
        }
         
         //attachment notes calendar
         else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
             && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
         {
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = false
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             viewDate.isHidden = false
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 99
             roadblockRightConstraint.constant = 52
             notecountRightConstraint.constant = 52
             subtaskRightConstraint.constant = 3
             BugRightConstraint.constant = 0
         }
         //attachment subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
         //attachment subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 52
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
          //attachment bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
             && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
         {
             viewAttachment.isHidden = false
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = false
             viewDate.isHidden = false
             
             dateRightConstraint.constant = 3
             attachRightConstraint.constant = 99
             roadblockRightConstraint.constant = 52
             notecountRightConstraint.constant = 52
             subtaskRightConstraint.constant = 52
             BugRightConstraint.constant = 52
         }
         
          //rollback notes subtask
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 52
        }
         
         //rollback notes bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
         //rollback notes calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = true
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 3
        }
        
         //rollback subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
         //rollback subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
        //rollback bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = false
            viewNote.isHidden = true
            viewSubtask.isHidden = true
            viewBug.isHidden = false
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 52
        }
        
        //notes subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
         //notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        
        //notes bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 52
            BugRightConstraint.constant = 3
        }
        //subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT == 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT != 0 )
        {
            viewAttachment.isHidden = true
            viewroadblock.isHidden = true
            viewNote.isHidden = true
            viewSubtask.isHidden = false
            viewBug.isHidden = false
            viewDate.isHidden = false
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 99
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 99
            subtaskRightConstraint.constant = 99
            BugRightConstraint.constant = 52
        }
        
         // attachment rollback notes subtask
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
            viewAttachment.isHidden = false
            viewroadblock.isHidden = false
            viewNote.isHidden = false
            viewSubtask.isHidden = false
            viewBug.isHidden = true
            viewDate.isHidden = true
            
            dateRightConstraint.constant = 3
            attachRightConstraint.constant = 146
            roadblockRightConstraint.constant = 99
            notecountRightConstraint.constant = 52
            subtaskRightConstraint.constant = 3
            BugRightConstraint.constant = 52
        }
        //attachment rollback notes bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 3
           BugRightConstraint.constant = 3
        }
        //attachment rollback bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
                   && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 3
           BugRightConstraint.constant = 52
        }
        
         //attachment rollback notes calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 3
           BugRightConstraint.constant = 52
        }
            
         //attachment rollback subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
                   && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
         //attachment rollback subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT == 0
                   && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = true
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 52
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
        
         //attachment notes subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
        
        //attachment notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
         //attachment notes bug calendar
            
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 99
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
            
        //rollback notes subtask bug
        else if (dt == 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
         
        //rollback notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
            
        //rollback note bug calendar
            
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
            
        //notes subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 146
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
            
        // attachment rollback notes subtask bug
        else if (dt == 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = true
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
      
        // attachment rollback notes subtask calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT == 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = true
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 3
        }
         //attachment rollback notes bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = true
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 99
           subtaskRightConstraint.constant = 52
           BugRightConstraint.constant = 52
        }
            
        //attachment notes subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT == 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID == 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = true
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 146
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
        
        //rollback notes subtask bug calendar
        else if (dt != 0 && objTask.attachmentCount == 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = true
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 193
           roadblockRightConstraint.constant = 193
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
            
        // attachment rollback notes subtask bug calendar all greater
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
                   && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT != 0 )
        {
           viewAttachment.isHidden = false
           viewroadblock.isHidden = false
           viewNote.isHidden = false
           viewSubtask.isHidden = false
           viewBug.isHidden = false
           viewDate.isHidden = false
           
           dateRightConstraint.constant = 3
           attachRightConstraint.constant = 240
           roadblockRightConstraint.constant = 193
           notecountRightConstraint.constant = 146
           subtaskRightConstraint.constant = 99
           BugRightConstraint.constant = 52
        }
        
        //priority attachment rollback notes subtask bug all zero
        else if (dt != 0 && objTask.attachmentCount != 0 && objTask.rOADBLOCKCOUNT != 0 && objTask.tASKNOTETOTALCOUNT != 0
            && objTask.pARENTTASKID != 0 && objTask.bUGCOUNT != 0 )
         {
             viewDate.isHidden = true
             viewAttachment.isHidden = true
             viewroadblock.isHidden = true
             viewNote.isHidden = true
             viewSubtask.isHidden = true
             viewBug.isHidden = true
             
             dateRightConstraint.constant = 235
             attachRightConstraint.constant = 188
             roadblockRightConstraint.constant = 0
             notecountRightConstraint.constant = 94
             subtaskRightConstraint.constant = 47
             BugRightConstraint.constant = 0
         }
    }
    
    func setCornerRadius() {
        self.layoutIfNeeded()
        
        self.lblUserName.layoutIfNeeded()
        self.imgUser.layoutIfNeeded()
        
        lblUserName.layer.masksToBounds = true
        imgUser.layer.masksToBounds = true
        lblTaskPercentage.layer.masksToBounds = true
        
        lblUserName.layer.cornerRadius = self.lblUserName.frame.height / 2
        imgUser.layer.cornerRadius = self.imgUser.frame.height / 2
        lblTaskPercentage.layer.cornerRadius = self.lblTaskPercentage.frame.height / 2
        
    }
    
    func setWorkBoardTask(objTask : MyTaskModel) {
        bgView.backgroundColor = theme_selected_color
        imgClock.backgroundColor = theme_selected_color
        lblTaskStartTime.text = objTask.strActiveTaskStartTime
        lblUserName.text = ""
        setUserImage(objTask: objTask)
        setcolor(objTask: objTask)
        setTaskName(objTask: objTask)
        setHourAndProgress(objTask: objTask)
        
        btnProgress.backgroundColor = theme_selected_color
        btnProgress.setTitle(String.fontAwesomeIcon(name: .hourglassHalf), for: .normal)
        btnProgress.setTitleColor(UIColor.white, for: .normal)
        
        btnProgressTaskDescription.backgroundColor = theme_selected_color
        btnProgressTaskDescription.setTitleColor(UIColor.white, for: .normal)
        btnProgressTaskDescription.isHidden = true
        if objTask.pROGRESSTASKDESCRIPTION != "" {
            btnProgressTaskDescription.isHidden = false
            btnProgressTaskDescription.setTitle(String.fontAwesomeIcon(name: .fileTextO), for: .normal)
        }
    }
    
    func setUserImage(objTask : MyTaskModel) {
        if (objTask.iMAGENAME == ""){
            imgUser.isHidden = true
            lblUserName.isHidden = false
            lblUserName.backgroundColor = UIColor.darkGray
            
            let userInitial : String = CommonFunctions().generateInitial(username: objTask.cONTACTNAME)
            
            lblUserName.text = userInitial
            
        }
        else{
            lblUserName.isHidden = true
            imgUser.isHidden = false
            imgUser.sd_setImage(with: URL(string: baseContactImageURL + "\(String(describing: (objTask.cONTACTID)))" + "/image?filename=" + objTask.iMAGENAME), placeholderImage: UIImage(named: "person_icon"))
        }
    }
    
    func setcolor(objTask : MyTaskModel) {
        if self.lblTaskType != nil {
            self.lblTaskType.borderColor = .darkGray
        }
        if (objTask.pROJECT_COLOR_CODE != ""){
            if lblProjectName != nil {
                lblProjectName.textColor = hexStringToUIColor(hex: objTask.pROJECT_COLOR_CODE)
            }
            if self.lblTaskType != nil {
                self.lblTaskType.borderColor = hexStringToUIColor(hex: objTask.pROJECT_COLOR_CODE)
            }
            bgView.backgroundColor = hexStringToUIColor(hex: objTask.pROJECT_COLOR_CODE)
            viewprogress.progressColor = hexStringToUIColor(hex: objTask.pROJECT_COLOR_CODE)
            lblTaskPercentage.backgroundColor = hexStringToUIColor(hex: objTask.pROJECT_COLOR_CODE)
        }
        
        if objTask.cONTACTCOLORCODE != ""{
            lblUserName.backgroundColor = hexStringToUIColor(hex: objTask.cONTACTCOLORCODE)
        }
    }
    
    func setTaskTypecolor(objTask : MyTaskModel) {
        if lblTaskType != nil {
            self.lblTaskType.cornerRadius = 3
            
            self.lblTaskType.backgroundColor = UIColor.darkGray
            self.lblTaskType.textColor = UIColor.white
            self.lblTaskType.isHidden = true
            if (objTask.WORKTYPE_CODE_SHORT_FORM != ""){
                self.lblTaskType.isHidden = false
                if (objTask.WORKTYPE_COLOR_CODE != ""){
                    self.lblTaskType.backgroundColor = hexStringToUIColor(hex: objTask.WORKTYPE_COLOR_CODE)
                }
                self.lblTaskType.text = objTask.WORKTYPE_CODE_SHORT_FORM
            }
        }
    }
    //--------------------------
    func setUserImage(objTask : SearchTaskModel) {
        if (objTask.iMAGENAME == ""){
            imgUser.isHidden = true
            lblUserName.isHidden = false
            lblUserName.backgroundColor = UIColor.darkGray
            
            let userInitial : String = CommonFunctions().generateInitial(username: objTask.tASKPERSON)
            
            lblUserName.text = userInitial
            
        }
        else{
            lblUserName.isHidden = true
            imgUser.isHidden = false
            imgUser.sd_setImage(with: URL(string: baseContactImageURL + "\(String(describing: (objTask.cONTACTID)))" + "/image?filename=" + objTask.iMAGENAME), placeholderImage: UIImage(named: "person_icon"))
        }
    }
    
    func setcolor(objTask : SearchTaskModel) {
        if self.lblTaskType != nil {
            self.lblTaskType.borderColor = .darkGray
        }
        if (objTask.pROJECTCOLORCODE != ""){
            if lblProjectName != nil {
                lblProjectName.textColor = hexStringToUIColor(hex: objTask.pROJECTCOLORCODE)
            }
            if self.lblTaskType != nil {
                self.lblTaskType.borderColor = hexStringToUIColor(hex: objTask.pROJECTCOLORCODE)
            }
            bgView.backgroundColor = hexStringToUIColor(hex: objTask.pROJECTCOLORCODE)
            viewprogress.progressColor = hexStringToUIColor(hex: objTask.pROJECTCOLORCODE)
            lblTaskPercentage.backgroundColor = hexStringToUIColor(hex: objTask.pROJECTCOLORCODE)
        }
        
        if objTask.cOLORCODE != ""{
            lblUserName.backgroundColor = hexStringToUIColor(hex: objTask.cOLORCODE)
        }
    }
    
    func setTaskTypecolor(objTask : SearchTaskModel) {
        if lblTaskType != nil {
            self.lblTaskType.cornerRadius = 3
            
            self.lblTaskType.backgroundColor = UIColor.darkGray
            self.lblTaskType.textColor = UIColor.white
            self.lblTaskType.isHidden = true
            if (objTask.wORKTYPECODESHORTFORM != ""){
                self.lblTaskType.isHidden = false
                if (objTask.wORKTYPECOLORCODE != ""){
                    self.lblTaskType.backgroundColor = hexStringToUIColor(hex: objTask.wORKTYPECOLORCODE)
                }
                self.lblTaskType.text = objTask.wORKTYPECODESHORTFORM
            }
        }
    }
    //--------------------------
    func setTaskName(objTask : MyTaskModel) {
        self.lblTaskName.text = String(describing: (objTask.tASKID)) + " - " + objTask.tASKDESCRIPTION
        if objTask.tASKFULLDESCRIPTION != "" {
            self.lblTaskName.text = String(describing: (objTask.tASKID)) + " - " + objTask.tASKFULLDESCRIPTION
        }
    }
    
    func setHourAndProgress(objTask : MyTaskModel) {
        
        self.lblHours.text = "\(String(describing: (objTask.cOMPLETEDHOURS.roundTo(places: 2)))) of \(String(describing: (objTask.aLLOCATEDHOURS.roundTo(places: 2)))) Hrs."
        
        custompProgressBar.progress = 0
        custompProgressBar.barFillColor = UIColor.lightGray
        
        if Int(objTask.aLLOCATEDHOURS) > 0{
            
            custompProgressBar.progress = CGFloat(CGFloat(objTask.cOMPLETEDHOURS) / CGFloat(objTask.aLLOCATEDHOURS))
            
            if Int(custompProgressBar.progress * 100) > 0 && Int(custompProgressBar.progress * 100) <= 30 {
                custompProgressBar.barFillColor = UIColor.red
            }
            else if Int(custompProgressBar.progress * 100) > 30 && Int(custompProgressBar.progress * 100) <= 70 {
                custompProgressBar.barFillColor = UIColor.orange
            }
            else{
                custompProgressBar.barFillColor = theme_color
            }
        }
        
        viewprogress.value = CGFloat(Float(objTask.sPRINTSPENTPERCENTAGE.rounded()))
        
        let str = String(Int(viewprogress.value))
        
        
        let yourAttributes = [convertFromNSAttributedStringKey(NSAttributedString.Key.foregroundColor): UIColor.white, convertFromNSAttributedStringKey(NSAttributedString.Key.font): UIFont.init(name: "Gotham-Medium", size: 14)]
        
        let yourOtherAttributes = [convertFromNSAttributedStringKey(NSAttributedString.Key.foregroundColor): UIColor.white, convertFromNSAttributedStringKey(NSAttributedString.Key.font): UIFont.init(name: "Gotham-Medium", size: 8)]
        
        let partOne = NSMutableAttributedString(string: str, attributes: convertToOptionalNSAttributedStringKeyDictionary(yourAttributes as [String : Any]))
        let partTwo = NSMutableAttributedString(string: "%", attributes: convertToOptionalNSAttributedStringKeyDictionary(yourOtherAttributes as [String : Any]))
        
        let combination = NSMutableAttributedString()
        
        combination.append(partOne)
        combination.append(partTwo)
        
        lblTaskPercentage.attributedText = combination
        lblTaskPercentage.adjustsFontSizeToFitWidth = true
    }
    //----
    func setTaskName(objTask : SearchTaskModel) {
        self.lblTaskName.text = String(describing: (objTask.iD)) + " - " + objTask.tITLE
//        if objTask.tASKDESC != "" {
//            self.lblTaskName.text = String(describing: (objTask.iD)) + " - " + objTask.tASKDESC
//        }
    }
    
    func setHourAndProgress(objTask : SearchTaskModel) {
        
        self.lblHours.text = "\(String(describing: (objTask.cOMPLETEDHOURS.roundTo(places: 2)))) of \(String(describing: (objTask.aLLOCATEDHOURS.roundTo(places: 2)))) Hrs."
        
        custompProgressBar.progress = 0
        custompProgressBar.barFillColor = UIColor.lightGray
        
        if Int(objTask.aLLOCATEDHOURS) > 0{
            
            custompProgressBar.progress = CGFloat(CGFloat(objTask.cOMPLETEDHOURS) / CGFloat(objTask.aLLOCATEDHOURS))
            
            if Int(custompProgressBar.progress * 100) > 0 && Int(custompProgressBar.progress * 100) <= 30 {
                custompProgressBar.barFillColor = UIColor.red
            }
            else if Int(custompProgressBar.progress * 100) > 30 && Int(custompProgressBar.progress * 100) <= 70 {
                custompProgressBar.barFillColor = UIColor.orange
            }
            else{
                custompProgressBar.barFillColor = theme_color
            }
        }
        
        viewprogress.value = CGFloat(Float(objTask.sPRINTSPENTPERCENTAGE.rounded()))
        
        let str = String(Int(viewprogress.value))
        
        
        let yourAttributes = [convertFromNSAttributedStringKey(NSAttributedString.Key.foregroundColor): UIColor.white, convertFromNSAttributedStringKey(NSAttributedString.Key.font): UIFont.init(name: "Gotham-Medium", size: 14)]
        
        let yourOtherAttributes = [convertFromNSAttributedStringKey(NSAttributedString.Key.foregroundColor): UIColor.white, convertFromNSAttributedStringKey(NSAttributedString.Key.font): UIFont.init(name: "Gotham-Medium", size: 8)]
        
        let partOne = NSMutableAttributedString(string: str, attributes: convertToOptionalNSAttributedStringKeyDictionary(yourAttributes as [String : Any]))
        let partTwo = NSMutableAttributedString(string: "%", attributes: convertToOptionalNSAttributedStringKeyDictionary(yourOtherAttributes as [String : Any]))
        
        let combination = NSMutableAttributedString()
        
        combination.append(partOne)
        combination.append(partTwo)
        
        lblTaskPercentage.attributedText = combination
        lblTaskPercentage.adjustsFontSizeToFitWidth = true
    }
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromNSAttributedStringKey(_ input: NSAttributedString.Key) -> String {
	return input.rawValue
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToOptionalNSAttributedStringKeyDictionary(_ input: [String: Any]?) -> [NSAttributedString.Key: Any]? {
	guard let input = input else { return nil }
	return Dictionary(uniqueKeysWithValues: input.map { key, value in (NSAttributedString.Key(rawValue: key), value)})
}
